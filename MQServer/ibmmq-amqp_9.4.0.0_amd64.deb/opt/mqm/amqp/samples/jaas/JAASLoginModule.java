package samples.jaas;

/* @start_prolog@
 * -----------------------------------------------------------------
 * IBM MQ MQTT Sample JAAS LoginModume
 * Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.mq.mqxr.listener/listenerSamplesSource/samples/jaas/JAASLoginModule.java  
 *
 *   <copyright 
 *   notice="lm-source-program" 
 *   pids="5724-H72," 
 *   years="2009,2021" 
 *   crc="1623246244" > 
 *   Licensed Materials - Property of IBM  
 *    
 *   5724-H72, 
 *    
 *   (C) Copyright IBM Corp. 2009, 2021 All Rights Reserved.  
 *    
 *   US Government Users Restricted Rights - Use, duplication or  
 *   disclosure restricted by GSA ADP Schedule Contract with  
 *   IBM Corp.  
 *   </copyright> 
 * -----------------------------------------------------------------
 */

/**
 * Requires .../SDK/MQServer/MQXR.jar on the classpath to build.
 */
public class JAASLoginModule implements javax.security.auth.spi.LoginModule {
 
  private javax.security.auth.Subject subject;
  private javax.security.auth.callback.CallbackHandler callbackHandler;
  private java.util.Map<String, ?> sharedState;
  private java.util.Map<String, ?> options;
  
  JAASPrincipal principal;
  boolean loggedIn = false;
   
  /* (non-Javadoc)
   * @see javax.security.auth.spi.LoginModule#initialize(javax.security.auth.Subject, javax.security.auth.callback.CallbackHandler, java.util.Map, java.util.Map)
   */
  public void initialize(javax.security.auth.Subject subject,
                         javax.security.auth.callback.CallbackHandler callbackHandler,
                         java.util.Map<String, ?> sharedState,
                         java.util.Map<String, ?> options) {
    this.subject = subject;
    this.callbackHandler = callbackHandler;
    this.sharedState = sharedState;
    this.options = options;   
  }
  
  /* (non-Javadoc)
   * @see javax.security.auth.spi.LoginModule#login()
   */
  public boolean login()
      throws javax.security.auth.login.LoginException {

    javax.security.auth.callback.NameCallback nameCallback = new javax.security.auth.callback.NameCallback("NameCallback");
    javax.security.auth.callback.PasswordCallback passwordCallback = new javax.security.auth.callback.PasswordCallback("PasswordCallback", false);
    javax.security.auth.callback.TextInputCallback validPromptsCallback = new javax.security.auth.callback.TextInputCallback("ValidPrompts");
    javax.security.auth.callback.TextInputCallback clientIdentifierCallback = new javax.security.auth.callback.TextInputCallback("ClientIdentifier");
    javax.security.auth.callback.TextInputCallback networkAddressCallback = new javax.security.auth.callback.TextInputCallback("NetworkAddress");
    javax.security.auth.callback.TextInputCallback channelNameCallback = new javax.security.auth.callback.TextInputCallback("ChannelName");
    javax.security.auth.callback.TextInputCallback qmNameCallback = new javax.security.auth.callback.TextInputCallback("QMName");
    javax.security.auth.callback.TextInputCallback mcaUserCallback = new javax.security.auth.callback.TextInputCallback("MCAUSER");
    com.ibm.mq.mqxr.AuthCallback xrCallback = new com.ibm.mq.mqxr.AuthCallback();

    try {
      callbackHandler.handle(new javax.security.auth.callback.Callback[] 
          {nameCallback, passwordCallback, validPromptsCallback,clientIdentifierCallback,networkAddressCallback,channelNameCallback,qmNameCallback,mcaUserCallback,xrCallback});
      String username = nameCallback.getName();
      char[] password = passwordCallback.getPassword();
      String validPrompts = validPromptsCallback.getText();
      String clientId = clientIdentifierCallback.getText();
      String networkAddress = networkAddressCallback.getText();
      String channelName = channelNameCallback.getText();
      String qmName = qmNameCallback.getText();
      String mcaUser = mcaUserCallback.getText();
      System.out.println("Login username: " + username);
      System.out.println("Login QM name: " + qmName);
      System.out.println("Login client ID: " + clientId);
      System.out.println("Login channel name: " + channelName);
      System.out.println("Login channel MCAUSER: " + mcaUser);
      System.out.println("Login IP address: " + networkAddress);

      /* Optionally override MCAUSER value on the channel */
      // mcaUserCallback.setText("bob");

      javax.net.ssl.SSLSession sslSession = xrCallback.getSSLSession(); 
      // Note that if multiple nameCallBack or clientIdentifierCallback callback's 
      // are used callbackHandler.handle will throw UnsupportedCallbackException.
       
      if ( sslSession != null ) {
        // Assuming the clients certificate was created with a distinguished name of the form:
        // "CN=ClientId:userName, OU=MQ, O=IBM, C=UK"
        javax.security.auth.x500.X500Principal peerPrincipal = (javax.security.auth.x500.X500Principal)sslSession.getPeerPrincipal();
        String[] dnFields = peerPrincipal.getName().split(",");
        String[] cn = dnFields[0].substring(3,dnFields[0].length()).split(":");
        // ClientIdentifier used by the connecting client.
        clientIdentifierCallback.setText(cn[0]);  
        // User name to be used by the connecting client. 
        nameCallback.setName(cn[1]);
        // The channel definitions, MCAUSER( ) and USECLTID(NO) are applied using the new clientIdentifier and userName.
        principal = new JAASPrincipal(cn[1]);
      } else {
        principal = new JAASPrincipal(username);
      }
      
           
      // Accept everything.
      if (true)
        loggedIn = true;
      else 
        throw new javax.security.auth.login.FailedLoginException("Login failed");
      
      principal = new JAASPrincipal(username);
      
    } catch (java.io.IOException exception) {
      throw new javax.security.auth.login.LoginException(exception.toString());
    } catch (javax.security.auth.callback.UnsupportedCallbackException exception) {
      throw new javax.security.auth.login.LoginException(exception.toString());
    }
    
    return loggedIn;
  }
  
  /* (non-Javadoc)
   * @see javax.security.auth.spi.LoginModule#abort()
   */
  public boolean abort()
      throws javax.security.auth.login.LoginException {
    logout();
    return true;
  }
  
  /* (non-Javadoc)
   * @see javax.security.auth.spi.LoginModule#commit()
   */
  public boolean commit()
      throws javax.security.auth.login.LoginException {
    if (loggedIn) {
      if (!subject.getPrincipals().contains(principal))
        subject.getPrincipals().add(principal);
    }
 
    return true;
  }

  /* (non-Javadoc)
   * @see javax.security.auth.spi.LoginModule#logout()
   */
  public boolean logout()
      throws javax.security.auth.login.LoginException {
    
    subject.getPrincipals().remove(principal);
    principal = null;
    loggedIn = false;
    
    final javax.security.auth.callback.NameCallback nameCallback = new javax.security.auth.callback.NameCallback("NameCallback");
    System.out.println("Logged out username: "+nameCallback.getName());
    
    return true;
  }
}
