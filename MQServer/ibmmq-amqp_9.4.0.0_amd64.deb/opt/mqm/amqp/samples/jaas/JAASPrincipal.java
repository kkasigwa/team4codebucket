package samples.jaas;
/* @start_prolog@
 * -----------------------------------------------------------------
 * IBM MQ MQTT Run MQTTV5 Sample Utility - Run script
 * Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.mq.mqxr.listener/listenerSamplesSource/samples/jaas/JAASPrincipal.java  
 *
 *   <copyright 
 *   notice="lm-source-program" 
 *   pids="5724-H72," 
 *   years="2009,2021" 
 *   crc="317364299" > 
 *   Licensed Materials - Property of IBM  
 *    
 *   5724-H72, 
 *    
 *   (C) Copyright IBM Corp. 2009, 2021 All Rights Reserved.  
 *    
 *   US Government Users Restricted Rights - Use, duplication or  
 *   disclosure restricted by GSA ADP Schedule Contract with  
 *   IBM Corp.  
 *   </copyright> 
 * -----------------------------------------------------------------
 */

public class JAASPrincipal implements java.security.Principal, java.io.Serializable {
  private static final long serialVersionUID = 1L;
  
  String name;
  public JAASPrincipal(String name) {
    this.name = name;
  }
  
  /* (non-Javadoc)
   * @see java.security.Principal#getName()
   */
  public String getName() {
    return name;
  }
  public String toString() {
    return(name);
  }
  
  public boolean equals(Object object) {
    final String otherName = ((JAASPrincipal)object).getName();
    if (   object  != null 
        && object instanceof JAASPrincipal
        && ((name == null && otherName == null) || name.equals(otherName)))
      return true;
    else
      return false;
  }
 
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((name == null) ? 0 : name.hashCode());
    return result;
  }
}
