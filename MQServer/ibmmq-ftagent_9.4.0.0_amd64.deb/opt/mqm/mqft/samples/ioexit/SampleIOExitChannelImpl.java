/*
 * 
 * Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.exitroutines.api/samples/ioexit/SampleIOExitChannelImpl.java
 * 
 * Licensed Materials - Property of IBM
 * 
 * 5655-MFT, 5724-H72
 * 
 * Copyright IBM Corp. 2011 All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp. 
 * 
 */

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.LinkedList;

import com.ibm.wmqfte.exitroutine.api.IOExitChannel;
import com.ibm.wmqfte.exitroutine.api.IOExitLock;
import com.ibm.wmqfte.exitroutine.api.IOExitResourcePath;
import com.ibm.wmqfte.exitroutine.api.RecoverableIOException;

/**
 * Sample {@link IOExitChannel} implementation that enables data to be read from
 * or written to an {@link IOExitResourcePath} resource.
 */
public class SampleIOExitChannelImpl implements IOExitChannel {
	private final static LinkedList<File> lockedShared = new LinkedList<File>();
	private final static LinkedList<File> lockedExclusive = new LinkedList<File>();

	private final LinkedList<SampleIOExitLockImpl> locks = new LinkedList<SampleIOExitLockImpl>();

	private final File file;
	private final FileChannel fileChannel;

	/**
	 * Create a new {@link SampleIOExitChannelImpl} for the given underlying
	 * {@link File} and {@link FileChannel} objects.
	 * 
	 * @param file
	 *            the underlying {@link File} to read/write to.
	 * @param fileChannel
	 *            the underlying {@link FileChannel} to use for reading/writing.
	 */
	protected SampleIOExitChannelImpl(final File file, final FileChannel fileChannel) {
		Log.enter(SampleIOExitChannelImpl.class, this, "<init>", file, fileChannel);
		this.file = file;
		this.fileChannel = fileChannel;
		Log.exit(SampleIOExitChannelImpl.class, this, "<init>");
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitChannel#size()
	 */
	public long size() throws IOException {
		Log.enter(SampleIOExitChannelImpl.class, this, "size");
		final long result = fileChannel.size();
		Log.exit(SampleIOExitChannelImpl.class, this, "size", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitChannel#close()
	 */
	public void close() throws RecoverableIOException, IOException {
		Log.enter(SampleIOExitChannelImpl.class, this, "close");
		synchronized (SampleIOExitChannelImpl.class) {
			/*
			 * Clone the locks LinkedList as releasing a lock modifies the list
			 * (and doing this while iterating over the list causes a concurrent
			 * modification exception)
			 */
			final LinkedList<SampleIOExitLockImpl> tmpLocks = (LinkedList<SampleIOExitLockImpl>) locks.clone();
			for (final SampleIOExitLockImpl lock : tmpLocks) {
				lock.release();
			}
		}
		fileChannel.close();
		Log.exit(SampleIOExitChannelImpl.class, this, "close");
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitChannel#read(java.nio.ByteBuffer)
	 */
	public int read(ByteBuffer buffer) throws RecoverableIOException, IOException {
		Log.enter(SampleIOExitChannelImpl.class, this, "read", buffer);
		final int result = fileChannel.read(buffer);
		Log.exit(SampleIOExitChannelImpl.class, this, "read", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitChannel#write(java.nio.ByteBuffer)
	 */
	public int write(ByteBuffer buffer) throws RecoverableIOException, IOException {
		Log.enter(SampleIOExitChannelImpl.class, this, "write", buffer);
		final int result = fileChannel.write(buffer);
		Log.exit(SampleIOExitChannelImpl.class, this, "write", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitChannel#force()
	 */
	public void force() throws RecoverableIOException, IOException {
		Log.enter(SampleIOExitChannelImpl.class, this, "force");
		fileChannel.force(true);
		Log.exit(SampleIOExitChannelImpl.class, this, "force");
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitChannel#tryLock(boolean)
	 */
	public IOExitLock tryLock(boolean shared) throws IOException {
		Log.enter(SampleIOExitChannelImpl.class, this, "tryLock", shared);
		final SampleIOExitLockImpl result;
		synchronized (SampleIOExitChannelImpl.class) {
			if (shared && lockedExclusive.contains(file))
				return null;
			else if (lockedShared.contains(file) || lockedExclusive.contains(file)) return null;
			final FileLock fileLock = fileChannel.tryLock(0, 0L, shared);
			if (fileLock != null) {
				if (shared)
					lockedShared.add(file);
				else
					lockedExclusive.add(file);
				result = new SampleIOExitLockImpl(file, this, fileLock);
				locks.add(result);
			} else {
				result = null;
			}
		}
		Log.exit(SampleIOExitChannelImpl.class, this, "tryLock", result);
		return result;
	}

	/**
	 * Releases the given lock.
	 * 
	 * @param file
	 *            the {@link File} object to release the lock for.
	 * @param lock
	 *            the {@link SampleIOExitLockImpl to release.
	 */
	protected void releaseLock(final File file, SampleIOExitLockImpl lock) {
		Log.enter(SampleIOExitChannelImpl.class, this, "releaseLock", file, lock);
		synchronized (SampleIOExitChannelImpl.class) {
			locks.remove(lock);
			if (lock.isShared()) {
				lockedShared.remove(file);
			} else {
				lockedExclusive.remove(file);
			}
		}
		Log.exit(SampleIOExitChannelImpl.class, this, "releaseLock");
	}

	/**
	 * Sets this channel's file position.
	 * 
	 * @param position
	 *            The new position, a non-negative integer counting the number
	 *            of bytes from the beginning of the file.
	 * @throws IOException
	 */
	protected void position(long position) throws IOException {
		Log.enter(SampleIOExitChannelImpl.class, this, "position", position);
		fileChannel.position(position);
		Log.exit(SampleIOExitChannelImpl.class, this, "position");
	}

	/**
	 * Tests if a lock exists on the given resource either for shared or
	 * exclusive access.
	 * 
	 * @param file
	 *            the {@link File} resource to check.
	 * @return {@code true} if a lock exists for this resource, {@code false}
	 *         otherwise.
	 */
	protected static boolean isLocked(final File file) {
		Log.enter(SampleIOExitChannelImpl.class, null, "isLocked", file);
		final boolean result;
		synchronized (SampleIOExitChannelImpl.class) {
			result = lockedShared.contains(file) || lockedExclusive.contains(file);
		}
		Log.exit(SampleIOExitChannelImpl.class, null, "isLocked", result);
		return result;
	}
}
