/*
 * 
 * Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.exitroutines.api/samples/ioexit/SampleIOExitLockImpl.java
 * 
 * Licensed Materials - Property of IBM
 * 
 * 5655-MFT, 5724-H72
 * 
 * Copyright IBM Corp. 2011 All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp. 
 * 
 */

import java.io.File;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;

import com.ibm.wmqfte.exitroutine.api.IOExitLock;

/**
 * Sample {@link IOExitLock} implementation that represents a lock on a resource
 * for either shared or exclusive access.
 */
public class SampleIOExitLockImpl implements IOExitLock {
	private final File file;
	private final SampleIOExitChannelImpl channel;
	private final FileLock fileLock;

	/**
	 * Create a new {@link SampleIOExitLockImpl} for the given underlying
	 * {@link File}, {@link SampleIOExitChannelImpl} and {@link FileLock} objects.
	 * 
	 * @param file
	 *            the underlying {@link File} to read/write to.
	 * @param channel
	 *            the underlying {@link FileChannel} to use for reading/writing.
	 * @param fileLock
	 *            the underlying {@link FileLock}.
	 */
	protected SampleIOExitLockImpl(final File file, final SampleIOExitChannelImpl channel, final FileLock fileLock) {
		Log.enter(SampleIOExitLockImpl.class, this, "<init>", file, channel, fileLock);
		this.file = file;
		this.channel = channel;
		this.fileLock = fileLock;
		Log.exit(SampleIOExitLockImpl.class, this, "<init>");
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitLock#release()
	 */
	public void release() throws IOException {
		Log.enter(SampleIOExitLockImpl.class, this, "release");
		if (isValid()) {
			channel.releaseLock(file, this);
		}
		fileLock.release();
		Log.exit(SampleIOExitLockImpl.class, this, "release");
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitLock#isValid()
	 */
	public boolean isValid() {
		Log.enter(SampleIOExitLockImpl.class, this, "isValid");
		final boolean result = fileLock.isValid();
		Log.exit(SampleIOExitLockImpl.class, this, "isValid", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitLock#isShared()
	 */
	public boolean isShared() {
		Log.enter(SampleIOExitLockImpl.class, this, "isShared");
		final boolean result = fileLock.isShared();
		Log.exit(SampleIOExitLockImpl.class, this, "isShared", result);
		return result;
	}

}
