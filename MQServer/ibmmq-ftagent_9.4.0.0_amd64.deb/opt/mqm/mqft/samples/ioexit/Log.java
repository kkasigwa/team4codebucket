/*
 * 
 * Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.exitroutines.api/samples/ioexit/Log.java
 * 
 * Licensed Materials - Property of IBM
 * 
 * 5655-MFT, 5724-H72
 * 
 * Copyright IBM Corp. 2011 All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp. 
 * 
 */

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Sample class for logging IOExit program flow.
 */
class Log {
	private static FileOutputStream logFile = null;

	protected static synchronized void enable(final File file, final boolean append) {
		if (logFile == null) {
			try {
				logFile = new FileOutputStream(file, append);
			} catch (IOException ioException) {
				System.err.println("Could not open log file.  Exception stack follows:");
				ioException.printStackTrace();
			}
		}
	}

	protected static synchronized void disable() {
		if (logFile != null) {
			try {
				logFile.close();
			} catch (IOException ioException) {
				System.err.println("Could not close log file.  Exception stack follows:");
				ioException.printStackTrace();
			}
			logFile = null;
		}
	}

	protected static synchronized void enter(final Class<?> clazz, final Object instance, final String method, final Object... parms) {
		if (logFile != null) log(clazz, instance, '>', method, parms);
	}

	protected static synchronized void exit(final Class<?> clazz, final Object instance, final String method, final Object... parms) {
		if (logFile != null) log(clazz, instance, '<', method, parms);
	}

	protected static synchronized void throwing(final Class<?> clazz, final Object instance, final String method, final Throwable throwable) {
		if (logFile != null) log(clazz, instance, '!', method, throwable);
	}

	private static void log(final Class<?> clazz, final Object instance, final char token, final String method, final Object... parms) {
		StringBuilder sb = new StringBuilder("" + Thread.currentThread().getId());
		sb.append(" ");
		sb.append(clazz.getSimpleName());
		sb.append("@");
		if (instance == null) {
			sb.append("<static>");
		} else {
			sb.append(Integer.toHexString(System.identityHashCode(instance)));
		}
		sb.append(" ");
		sb.append(token);
		sb.append(" ");
		sb.append(method);
		if (parms.length > 0) {
			sb.append(" [");
			for (int i = 0; i < parms.length; ++i) {
				if (parms[i] == null) {
					sb.append("null");
				} else {
					sb.append(parms[i].toString());
				}
				if (i != (parms.length - 1)) sb.append(", ");
			}
			sb.append("]");
		}
		sb.append("\r\n");
		try {
			logFile.write(sb.toString().getBytes());
			logFile.flush();
		} catch (IOException e) {
			// Ignore.
		}
	}
}
