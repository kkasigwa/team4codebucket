/*
 * 
 * Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.exitroutines.api/samples/ioexit/SampleIOExitResourcePathImpl.java
 * 
 * Licensed Materials - Property of IBM
 * 
 * 5655-MFT, 5724-H72
 * 
 * Copyright IBM Corp. 2011 All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp. 
 * 
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

import com.ibm.wmqfte.exitroutine.api.IOExitChannel;
import com.ibm.wmqfte.exitroutine.api.IOExitProperties;
import com.ibm.wmqfte.exitroutine.api.IOExitResourcePath;
import com.ibm.wmqfte.exitroutine.api.RecoverableIOException;

/**
 * Sample {@link IOExitResourcePath} implementation that represents a path that
 * denotes a data resource (for example, a file, directory, or group of database
 * records). It allows the data to be located and {@link IOExitChannel}
 * instances to be created for read or write operations.
 */
public class SampleIOExitResourcePathImpl implements IOExitResourcePath {
	private final File file;
	
	/**
	 * Create a new {@link SampleIOExitResourcePathImpl} for the given
	 * underlying {@link File} object.
	 * 
	 * @param file
	 *            the underlying {@link File} path to represent.
	 */
	protected SampleIOExitResourcePathImpl(final File file) {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "<init>", file);
		this.file = file;
		Log.exit(SampleIOExitResourcePathImpl.class, this, "<init>");
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#newPath(java.lang.String)
	 */
	public IOExitResourcePath newPath(String child) {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "newPath", child);
		final IOExitResourcePath result = new SampleIOExitResourcePathImpl(new File(file, child));
		Log.exit(SampleIOExitResourcePathImpl.class, this, "<init>", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#makePath()
	 */
	public void makePath() throws IOException {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "makePath");
		if ((file != null) && !file.exists()) {
			if (file.mkdirs()) {
				final IOException exception = new IOException("couldn't makePath!");
				Log.throwing(SampleIOExitResourcePathImpl.class, this, "makePath", exception);
				throw exception;
			}
		}
		Log.exit(SampleIOExitResourcePathImpl.class, this, "makePath");
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#exists()
	 */
	public boolean exists() throws IOException {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "exists");
		final boolean result = file.exists();
		Log.exit(SampleIOExitResourcePathImpl.class, this, "exists", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#canRead()
	 */
	public boolean canRead() throws IOException {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "canRead");
		final boolean result = file.canRead();
		Log.exit(SampleIOExitResourcePathImpl.class, this, "canRead", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#canWrite()
	 */
	public boolean canWrite() throws IOException {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "canWrite");
		final boolean result = file.canWrite();
		Log.exit(SampleIOExitResourcePathImpl.class, this, "canWrite", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#readPermitted(java.lang.String)
	 */
	public boolean readPermitted(String userId) throws IOException {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "readPermitted", userId);
		Log.exit(SampleIOExitResourcePathImpl.class, this, "readPermitted", true);
		return true;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#writePermitted(java.lang.String)
	 */
	public boolean writePermitted(String userId) throws IOException {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "writePermitted", userId);
		Log.exit(SampleIOExitResourcePathImpl.class, this, "writePermitted", true);
		return true;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#isDirectory()
	 */
	public boolean isDirectory() {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "isDirectory");
		final boolean result = file.isDirectory();
		Log.exit(SampleIOExitResourcePathImpl.class, this, "isDirectory", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#createNewPath()
	 */
	public boolean createNewPath() throws RecoverableIOException, IOException {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "createNewPath");
		final boolean result = file.createNewFile();
		Log.exit(SampleIOExitResourcePathImpl.class, this, "createNewPath", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#isFile()
	 */
	public boolean isFile() {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "isFile");
		final boolean result = file.isFile();
		Log.exit(SampleIOExitResourcePathImpl.class, this, "isFile", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#lastModified()
	 */
	public long lastModified() {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "lastModified");
		final long result = file.lastModified();
		Log.exit(SampleIOExitResourcePathImpl.class, this, "lastModified", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#delete()
	 */
	public void delete() throws IOException {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "delete");
		if (!file.delete()) {
			final IOException exception = new IOException("Can't delete file!");
			Log.throwing(SampleIOExitResourcePathImpl.class, this, "delete", exception);
			throw exception;
		}
		Log.exit(SampleIOExitResourcePathImpl.class, this, "delete");
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#renameTo(com.ibm.wmqfte.exitroutine.api.IOExitResourcePath)
	 */
	public void renameTo(IOExitResourcePath destination) throws IOException {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "renameTo", destination);
		if (!file.renameTo(new File(destination.getPath()))) {
			final IOException exception = new IOException("Couldn't rename file!");
			Log.throwing(SampleIOExitResourcePathImpl.class, this, "renameTo", exception);
			throw exception;
		}
		Log.exit(SampleIOExitResourcePathImpl.class, this, "renameTo");
	}	
	
	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#inUse()
	 */
	public boolean inUse() {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "inUse");
		boolean result = false;
		if (SampleIOExitChannelImpl.isLocked(file)) {
			result = true;
		} else {
			FileOutputStream out = null;
			try {
				out = new FileOutputStream(file, true);
				final FileChannel channel = out.getChannel();
				result = channel.tryLock(0L, Long.MAX_VALUE, false) == null;
			}
			catch(IOException e) {
			}
			if (out != null) {
				try {
					out.close();
				}
				catch(IOException e) {
					// Ignore.
				}
			}
		}
		Log.exit(SampleIOExitResourcePathImpl.class, this, "inUse", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitPath#getPath()
	 */
	public String getPath() {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "getPath");
		final String result = file.getPath();
		Log.exit(SampleIOExitResourcePathImpl.class, this, "getPath", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#getCanonicalPath()
	 */
	public String getCanonicalPath() throws IOException {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "getCannonicalPath");
		final String result = file.getCanonicalPath();
		Log.exit(SampleIOExitResourcePathImpl.class, this, "getCannonicalPath", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitPath#getName()
	 */
	public String getName() {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "getName");
		final String result = file.getName();
		Log.exit(SampleIOExitResourcePathImpl.class, this, "getName", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitPath#getParent()
	 */
	public String getParent() {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "getParent");
		final String result = file.getParent();
		Log.exit(SampleIOExitResourcePathImpl.class, this, "getParent", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#isAbsolute()
	 */
	public boolean isAbsolute() {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "isAbsolute");
		final boolean result = file.isAbsolute();
		Log.exit(SampleIOExitResourcePathImpl.class, this, "isAbsolute", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#getProperties()
	 */
	public IOExitProperties getProperties() {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "getProperties");
		final IOExitProperties result = new IOExitProperties();
		Log.exit(SampleIOExitResourcePathImpl.class, this, "getProperties", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitPath#listPaths()
	 */
	public IOExitResourcePath[] listPaths() {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "listPaths");
		final String[] paths = file.list();
		IOExitResourcePath[] result = null;
		if (paths != null) {
			result = new IOExitResourcePath[paths.length];
			for (int i=0; i < paths.length; ++i) {
				result[i] = new SampleIOExitResourcePathImpl(new File(file, paths[i]));
			}
		}
		Log.exit(SampleIOExitResourcePathImpl.class, this, "listPaths", (Object[])result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#openForRead(long)
	 */
	public IOExitChannel openForRead(long position)
			throws RecoverableIOException, IOException {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "openForRead", position);
		final SampleIOExitChannelImpl result = new SampleIOExitChannelImpl(file, new FileInputStream(file).getChannel());
		Log.exit(SampleIOExitResourcePathImpl.class, this, "openForRead", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#openForWrite(boolean)
	 */
	public IOExitChannel openForWrite(boolean append)
			throws RecoverableIOException, IOException {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "openForWrite", append);
		final SampleIOExitChannelImpl result = new SampleIOExitChannelImpl(file, new FileOutputStream(file, append).getChannel());
		Log.exit(SampleIOExitResourcePathImpl.class, this, "openForWrite", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitResourcePath#createTempPath(java.lang.String)
	 */
	public IOExitResourcePath createTempPath(String suffix) throws RecoverableIOException, IOException {
		Log.enter(SampleIOExitResourcePathImpl.class, this, "createTempPath", suffix);
		IOExitResourcePath result = new SampleIOExitResourcePathImpl(new File(file.getPath()+suffix));
		int count = 2;
		while(result.exists()) {
			result = new SampleIOExitResourcePathImpl(new File(file.getPath()+suffix+count));
			++count;
		}
		Log.exit(SampleIOExitResourcePathImpl.class, this, "createTempPath", result);
		return result;
	}
}
