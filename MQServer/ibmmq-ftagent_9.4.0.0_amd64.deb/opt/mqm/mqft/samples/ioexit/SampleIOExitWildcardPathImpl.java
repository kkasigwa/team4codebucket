/*
 * 
 * Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.exitroutines.api/samples/ioexit/SampleIOExitWildcardPathImpl.java
 * 
 * Licensed Materials - Property of IBM
 * 
 * 5655-MFT, 5724-H72
 * 
 * Copyright IBM Corp. 2011 All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp. 
 * 
 */

import java.io.File;
import java.io.FilenameFilter;
import java.util.regex.Pattern;

import com.ibm.wmqfte.exitroutine.api.IOExitResourcePath;
import com.ibm.wmqfte.exitroutine.api.IOExitWildcardPath;

/**
 * Sample {@link IOExitWildcardPath} implementation that represents a path that
 * denotes a wildcard. This can be used to match multiple resource paths.
 */
public class SampleIOExitWildcardPathImpl implements IOExitWildcardPath {
	private final String path;

	private final String separator = File.separator;

	/**
	 * Create a new {@link SampleIOExitWildcardPathImpl} for the given
	 * underlying path object that denotes a wildcard.
	 * 
	 * @param path
	 *            the underlying path to represent.
	 */
	protected SampleIOExitWildcardPathImpl(final String path) {
		Log.enter(SampleIOExitWildcardPathImpl.class, this, "<init>", path);

		// Strip any trailing path separator characters from the path.
		String tmpPath = path;
		while (tmpPath.endsWith(separator)) {
			tmpPath = tmpPath.substring(0, tmpPath.length() - 1);
		}
		if (tmpPath.equals("")) tmpPath = separator;
		this.path = tmpPath;

		Log.exit(SampleIOExitWildcardPathImpl.class, this, "<init>");
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitPath#getName()
	 */
	public String getName() {
		Log.enter(SampleIOExitWildcardPathImpl.class, this, "getName");
		final int index = path.lastIndexOf(separator);
		if (index < 1) return path.substring(1);
		final String result = path.substring(index + 1);
		Log.exit(SampleIOExitWildcardPathImpl.class, this, "getName", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitPath#getParent()
	 */
	public String getParent() {
		Log.enter(SampleIOExitWildcardPathImpl.class, this, "getParent");
		final int index = path.lastIndexOf(separator);
		if (index < 1) {
			if (path.length() > 1) return path.substring(0, 1);
			return null;
		}
		final String result = path.substring(0, index);
		Log.exit(SampleIOExitWildcardPathImpl.class, this, "getParent", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitPath#getPath()
	 */
	public String getPath() {
		Log.enter(SampleIOExitWildcardPathImpl.class, this, "getPath");
		Log.exit(SampleIOExitWildcardPathImpl.class, this, "getPath", path);
		return path;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExitPath#listPaths()
	 */
	public IOExitResourcePath[] listPaths() {
		Log.enter(SampleIOExitWildcardPathImpl.class, this, "listPaths");
		final IOExitResourcePath[] result;
		if (getParent() == null) {
			result = new IOExitResourcePath[0];
		} else {
			final String name = getName();
			final StringBuilder patternString = new StringBuilder();
			for (int i = 0; i < name.length(); ++i) {
				final char ch = name.charAt(i);
				if (Character.isLetter(ch) || Character.isDigit(ch)) {
					patternString.append(ch);
				} else if (ch == '?') {
					patternString.append('.');
				} else if (ch == '*') {
					patternString.append(".*");
				} else {
					patternString.append('\\');
					patternString.append(ch);
				}
			}

			final Pattern pattern = Pattern.compile(patternString.toString());
			final File parent = new File(getParent());
			final String[] filenames = parent.list(new FilenameFilter() {
				public boolean accept(File dir, String name) {
					return pattern.matcher(name).matches();
				}
			});

			result = new IOExitResourcePath[filenames.length];
			for (int i = 0; i < result.length; ++i) {
				result[i] = new SampleIOExitResourcePathImpl(new File(parent, filenames[i]));
			}
		}
		Log.exit(SampleIOExitWildcardPathImpl.class, this, "listPaths", (Object[]) result);
		return result;
	}
}
