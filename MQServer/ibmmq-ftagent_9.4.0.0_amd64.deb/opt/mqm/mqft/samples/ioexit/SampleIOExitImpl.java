/*
 * 
 * Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.exitroutines.api/samples/ioexit/SampleIOExitImpl.java
 * 
 * Licensed Materials - Property of IBM
 * 
 * 5655-MFT, 5724-H72
 * 
 * Copyright IBM Corp. 2011, 2012 All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with
 * IBM Corp. 
 * 
 */

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.ibm.wmqfte.exitroutine.api.IOExit;
import com.ibm.wmqfte.exitroutine.api.IOExitPath;
import com.ibm.wmqfte.exitroutine.api.IOExitRecordResourcePath.RecordFormat;

/**
 * Sample {@link IOExit} implementation that will be invoked during transfers to
 * perform the underlying file system I/O work for MQMFT transfers.
 */
public class SampleIOExitImpl implements IOExit {
	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExit#isSupported(java.lang.String)
	 */
	public boolean isSupported(String path) {
		Log.enter(SampleIOExitImpl.class, this, "isSupported", path);
		Log.exit(SampleIOExitImpl.class, this, "isSupported", true);
		return true;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExit#newPath(java.lang.String)
	 */
	public IOExitPath newPath(String path) {
		Log.enter(SampleIOExitImpl.class, this, "newPath", path);

		final IOExitPath result;
		if (path.contains("*") || path.contains("?")) {
			result = new SampleIOExitWildcardPathImpl(path);
		} else {
			result = new SampleIOExitResourcePathImpl(new File(path));
		}

		Log.exit(SampleIOExitImpl.class, this, "newPath", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExit#newPath(java.lang.String, com.ibm.wmqfte.exitroutine.api.IOExitRecordResourcePath.RecordFormat, int)
	 */
	public IOExitPath newPath(String path, RecordFormat recordFormat, int recordLength) throws IOException {
		Log.enter(SampleIOExitImpl.class, this, "newPath", path, recordFormat, recordLength);
		
		final IOExitPath result = newPath(path);
		
		Log.exit(SampleIOExitImpl.class, this, "newPath", result);
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.IOExit#initialize(java.util.Map)
	 */
	public boolean initialize(Map<String, String> parameters) {
		Log.enable(new File("c:\\tmp\\ioexit-log.txt"), false);
		Log.enter(SampleIOExitImpl.class, this, "initialize", parameters);
		Log.exit(SampleIOExitImpl.class, this, "initialize", true);
		return true;
	}
}