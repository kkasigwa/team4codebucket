-- ===============================================================
-- @start_non_restricted_prolog@
-- Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.databaseloader/sql/oracle_nvarchar_migration_step1.sql
-- 
-- <copyright
-- notice="lm-source-program"
-- pids="5724-H72"
-- years="2017,2018"
-- crc="3374478728" >
-- Licensed Materials - Property of IBM  
--
-- 5724-H72 
-- 
-- (C) Copyright IBM Corp. 2018  All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with    
-- IBM Corp. 
-- </copyright>
-- 
-- @end_non_restricted_prolog@
-- ===============================================================
--
-- SQL schema migration file for IBM MQ Managed File Transfer Database
-- Logger (Oracle)
-- ----------------------------------------------------
-- This file also assumes a default schema name of "FTELOG". If required, this
-- can be changed by replacing all instances of FTELOG with your preferred
-- schema name (use a text editor with search/replace function). 
-- ----------------------------------------------------


alter table "FTELOG"."SCHEDULE_ACTION" 	add	("STATUS_TEXT1" nvarchar2(2000) null); 
alter table "FTELOG"."TRANSFER_ITEM"		add	("SOURCE_FILENAME1" nvarchar2(2000) null); 
alter table "FTELOG"."TRANSFER_ITEM"		add	("SOURCE_CHECKSUM_VALUE1" nvarchar2(2000) null); 
alter table "FTELOG"."TRANSFER_ITEM"		add	("DESTINATION_FILENAME1" nvarchar2(2000) null); 
alter table "FTELOG"."TRANSFER_ITEM"		add	("DESTINATION_CHECKSUM_VALUE1" nvarchar2(2000) null); 
alter table "FTELOG"."TRANSFER_ITEM"		add	("RESULT_TEXT1" nvarchar2(2000) null); 
alter table "FTELOG"."SCHEDULE_ITEM"		add	("SOURCE_FILENAME1" nvarchar2(2000) null); 
alter table "FTELOG"."SCHEDULE_ITEM"		add	("DESTINATION_FILENAME1" nvarchar2(2000) null); 
alter table "FTELOG"."SCHEDULE_ITEM"		add	("SOURCE_QUEUE1" nvarchar2(2000) null); 
alter table "FTELOG"."SCHEDULE_ITEM"		add	("DESTINATION_QUEUE1" nvarchar2(2000) null); 
alter table "FTELOG"."TRIGGER_CONDITION"	add	("FILENAME1" nvarchar2(2000) not null); 
alter table "FTELOG"."CALL_ARGUMENT"		add	("VALUE1" nvarchar2(2000) not null); 
alter table "FTELOG"."CALL"				add	("EXECUTED_COMMAND1" nvarchar2(2000) null); 
alter table "FTELOG"."CALL_REQUEST"		add	("RESULTTEXT1" nvarchar2(2000) null); 
alter table "FTELOG"."TRANSFER"			add	("RESULTTEXT1" nvarchar2(2000) null); 
alter table "FTELOG"."CALL_RESULT"			add	("ERROR1" nvarchar2(2000) null); 
alter table "FTELOG"."MONITOR_METADATA"	add	("VALUE1" nvarchar2(2000) null); 
alter table "FTELOG"."MONITOR_EXIT_RESULT"	add	("RESULTTEXT1" nvarchar2(2000) null); 
alter table "FTELOG"."MONITOR_ACTION"		add	("ORIGINAL_XML_REQUEST1" nvarchar2(2000) null); 
alter table "FTELOG"."MONITOR_ACTION"		add	("UPDATED_XML_REQUEST1" nvarchar2(2000) null); 
alter table "FTELOG"."AUTH_EVENT"			add	("RESULT_TEXT1" nvarchar2(2000) null); 
alter table "FTELOG"."FILE_SPACE_ENTRY"	add	("ALIAS1" nvarchar2(2000) not null); 
