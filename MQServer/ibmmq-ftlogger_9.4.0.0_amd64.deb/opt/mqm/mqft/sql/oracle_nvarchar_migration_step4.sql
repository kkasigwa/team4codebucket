-- ===============================================================
-- @start_non_restricted_prolog@
-- Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.databaseloader/sql/oracle_nvarchar_migration_step4.sql
-- 
-- <copyright
-- notice="lm-source-program"
-- pids="5724-H72"
-- years="2017,2018"
-- crc="3374478728" >
-- Licensed Materials - Property of IBM  
--
-- 5724-H72 
-- 
-- (C) Copyright IBM Corp. 2018  All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with    
-- IBM Corp. 
-- </copyright>
-- 
-- @end_non_restricted_prolog@
-- ===============================================================
--
-- SQL schema migration file for IBM MQ Managed File Transfer Database 
-- Logger (Oracle)
-- ----------------------------------------------------
-- This file also assumes a default schema name of "FTELOG". If required, this
-- can be changed by replacing all instances of FTELOG with your preferred
-- schema name (use a text editor with search/replace function). 

-- Important Note : Before executing this script file , oracle_nvarchar_migration_step3.sql must be executed
-- ----------------------------------------------------


alter table "FTELOG"."SCHEDULE_ACTION"	  rename  column  "STATUS_TEXT1" to "STATUS_TEXT";
alter table "FTELOG"."TRANSFER_ITEM"	  rename  column  "SOURCE_FILENAME1" to "SOURCE_FILENAME";
alter table "FTELOG"."TRANSFER_ITEM"	  rename  column  "SOURCE_CHECKSUM_VALUE1" to "SOURCE_CHECKSUM_VALUE";
alter table "FTELOG"."TRANSFER_ITEM"	  rename  column  "DESTINATION_FILENAME1" to "DESTINATION_FILENAME";
alter table "FTELOG"."TRANSFER_ITEM"	  rename  column  "DESTINATION_CHECKSUM_VALUE1" to "DESTINATION_CHECKSUM_VALUE";
alter table "FTELOG"."TRANSFER_ITEM"	  rename  column  "RESULT_TEXT1" to "RESULT_TEXT";
alter table "FTELOG"."SCHEDULE_ITEM"	  rename  column  "SOURCE_FILENAME1" to "SOURCE_FILENAME";
alter table "FTELOG"."SCHEDULE_ITEM"	  rename  column  "DESTINATION_FILENAME1" to "DESTINATION_FILENAME";
alter table "FTELOG"."SCHEDULE_ITEM"	  rename  column  "SOURCE_QUEUE1" to "SOURCE_QUEUE";
alter table "FTELOG"."SCHEDULE_ITEM"	  rename  column  "DESTINATION_QUEUE1" to "DESTINATION_QUEUE";
alter table "FTELOG"."TRIGGER_CONDITION"	  rename  column  "FILENAME1" to "FILENAME";
alter table "FTELOG"."CALL_ARGUMENT"	  rename  column  "VALUE1" to "VALUE";
alter table "FTELOG"."CALL"	  rename  column  "EXECUTED_COMMAND1" to "EXECUTED_COMMAND";
alter table "FTELOG"."CALL_REQUEST"	  rename  column  "RESULTTEXT1" to "RESULTTEXT";
alter table "FTELOG"."TRANSFER"	  rename  column  "RESULTTEXT1" to "RESULTTEXT";
alter table "FTELOG"."CALL_RESULT"	  rename  column  "ERROR1" to "ERROR";
alter table "FTELOG"."MONITOR_METADATA"	  rename  column  "VALUE1" to "VALUE";
alter table "FTELOG"."MONITOR_EXIT_RESULT"	  rename  column  "RESULTTEXT1" to "RESULTTEXT";
alter table "FTELOG"."MONITOR_ACTION"	  rename  column  "ORIGINAL_XML_REQUEST1" to "ORIGINAL_XML_REQUEST";
alter table "FTELOG"."MONITOR_ACTION"	  rename  column  "UPDATED_XML_REQUEST1" to "UPDATED_XML_REQUEST";
alter table "FTELOG"."AUTH_EVENT"	  rename  column  "RESULT_TEXT1" to "RESULT_TEXT";
alter table "FTELOG"."FILE_SPACE_ENTRY"	  rename  column  "ALIAS1" to "ALIAS";
