-- 
-- Licensed Materials - Property of IBM
-- 
-- <copyright
-- notice="lm-source-program"
-- pids="5724-H72"
-- years="2010,2019"
-- crc="3374478728" >
-- Licensed Materials - Property of IBM  
--
-- 5724-H72 
-- 
-- (C) Copyright IBM Corp. 2010, 2019  All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with    
-- IBM Corp. 
-- </copyright>
--
-- @end_non_restricted_prolog@
-- ===============================================================
-- 
-- SQL schema migration file for WMQFTE Database Logger, FTE 7.0.2 - 7.0.3 (Oracle)
-- --------------------------------------------------------------------------------
--
-- ** Use this file if you have an existing FTE version 7.0.2 database which **
-- ** you wish to keep and use with FTE version 7.0.3. If you wish to create **
-- ** a new database for use with FTE version 7.0.3, use the file            **
-- ** ftelog_tables_oracle.sql instead.                                      **
-- 
-- This file contains SQL Data Definition Language statements that define the
-- schema changes necessary for FTE version 7.0.3. Before running a version 
-- 7.0.3 database logger, you must run this file against your existing database
-- to upgrade it. You can use any appropriate database tool to do this, such as
-- "@<filename>" inside SQL*Plus or a graphical tool which can import SQL DDL 
-- files.
-- 
-- Because site-specific requirements may vary greatly, this file only 
-- specifies the basic structures of the tables. Attributes such as 
-- table-spaces, LOB locations, etc are not specified. An experienced database 
-- administrator may wish to modify a copy of this file to define these 
-- performance-related attributes.
-- 
-- This file also assumes a default schema name of "FTELOG". If required, this
-- can be changed by replacing all instances of FTELOG with your preferred
-- schema name (use a text editor with search/replace function). 

-- Add new columns to the TRANSFER_ITEM table
ALTER TABLE "FTELOG"."TRANSFER_ITEM" ADD ("SOURCE_MESSAGE_QUEUE_NAME" CHAR(128));
ALTER TABLE "FTELOG"."TRANSFER_ITEM" ADD ("SOURCE_MESSAGE_GROUP_ID" CHAR(48));
ALTER TABLE "FTELOG"."TRANSFER_ITEM" ADD ("SOURCE_MESSAGE_COUNT" INTEGER);
ALTER TABLE "FTELOG"."TRANSFER_ITEM" ADD ("DESTINATION_MESSAGE_QUEUE_NAME" CHAR(128));
ALTER TABLE "FTELOG"."TRANSFER_ITEM" ADD ("DESTINATION_MESSAGE_MESSAGE_ID" CHAR(48));
ALTER TABLE "FTELOG"."TRANSFER_ITEM" ADD ("DESTINATION_MESSAGE_GROUP_ID" CHAR(48));
ALTER TABLE "FTELOG"."TRANSFER_ITEM" ADD ("DESTINATION_MESSAGE_COUNT" INTEGER);
ALTER TABLE "FTELOG"."TRANSFER_ITEM" ADD ("DESTINATION_MESSAGE_LENGTH" INTEGER);
ALTER TABLE "FTELOG"."TRANSFER_ITEM" ADD ("SEQUENCE" SMALLINT);

-- Add comments for new columns    
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SOURCE_MESSAGE_QUEUE_NAME" IS 'The source queue for the message(s) to be included in the destination file.';

COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SOURCE_MESSAGE_GROUP_ID" IS 'The group ID of the message(s) to be included in the destination file.';

COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SOURCE_MESSAGE_COUNT" IS 'The number of messages to be included in the destination file.';

COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_MESSAGE_QUEUE_NAME" IS 'The destination queue for the message(s) produced from the source file.';

COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_MESSAGE_MESSAGE_ID" IS 'The message ID of the message produced from the source file. May be null if the transfer resulted in multiple messages.';

COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_MESSAGE_GROUP_ID" IS 'The group ID of the message(s) produced from the source file. May be null if the transfer resulted in only a single message.';

COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_MESSAGE_COUNT" IS 'The number of messages that the source file was split into.';

COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_MESSAGE_LENGTH" IS 'The length of the message produced from the source file.';

COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SEQUENCE" IS 'The sequence number within the transfer of this transfer item.';

-- Modify existing TRANSFER_ITEM columns
ALTER TABLE "FTELOG"."TRANSFER_ITEM" 
	MODIFY("SOURCE_FILENAME" NULL)
    MODIFY("DESTINATION_FILENAME" NULL);
    
    
-- Add new columns to the TRANSFER Table
ALTER TABLE "FTELOG"."TRANSFER" ADD ("STATUS" CHAR(20));
ALTER TABLE "FTELOG"."TRANSFER" ADD ("RELATED_TRANSFER_ID" CHAR(48));

 
COMMENT ON COLUMN "FTELOG"."TRANSFER"."STATUS" IS 'The status of a transfer (started, success, partial success, failure, cancelled)';      

COMMENT ON COLUMN "FTELOG"."TRANSFER"."RELATED_TRANSFER_ID" IS 'A previous transfer related to this specific transfer e.g. A Web Gateway download transfer will refer to the upload transfer for the file that is downloaded.';

-- Calculate the new status column for existing transfers
-- in the database.

UPDATE "FTELOG"."TRANSFER" SET STATUS= 'started' WHERE COMPLETE_ID IS NULL AND START_ID IS NOT NULL;
UPDATE "FTELOG"."TRANSFER" SET STATUS= 'success' WHERE COMPLETE_ID IS NOT NULL AND RESULTCODE = 0;
UPDATE "FTELOG"."TRANSFER" SET STATUS= 'partial success' WHERE COMPLETE_ID IS NOT NULL AND RESULTCODE = 20;
UPDATE "FTELOG"."TRANSFER" SET STATUS= 'failure' WHERE COMPLETE_ID IS NOT NULL AND RESULTCODE NOT IN (0,20);


-- Add new columns to the TRANSFER_EVENT table
ALTER TABLE "FTELOG"."TRANSFER_EVENT" ADD ("SOURCE_WEB_GATEWAY" CHAR(28));
ALTER TABLE "FTELOG"."TRANSFER_EVENT" ADD ("DESTINATION_WEB_GATEWAY" CHAR(28));
ALTER TABLE "FTELOG"."TRANSFER_EVENT" ADD ("ORIGINATOR_WEB_USER" VARCHAR(256));

COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."SOURCE_WEB_GATEWAY" IS 'The name of the web gateway from which the files are transferred.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."DESTINATION_WEB_GATEWAY" IS 'The name of the web gateway to which the files are transferred.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."ORIGINATOR_WEB_USER" IS 'The name of the web user who submitted the request.';

-- Modify existing TRANSFER_EVENT columns
ALTER TABLE "FTELOG"."TRANSFER_EVENT"
	MODIFY("SOURCE_AGENT" NULL) 
	MODIFY("SOURCE_QM" NULL)
	MODIFY("SOURCE_ARCHITECTURE" NULL) 
	MODIFY("SOURCE_OS_NAME" NULL)
	MODIFY("SOURCE_OS_VERSION" NULL)
	MODIFY("DESTINATION_AGENT" NULL) 
	MODIFY("DESTINATION_QM" NULL)
	MODIFY("ORIGINATOR_MQ_USER" NULL);


-- Modify existing TRANSFER_STATS columns
ALTER TABLE "FTELOG"."TRANSFER_STATS" 
    MODIFY("START_TIME" NULL);

------------------------------------------------
-- DDL Statements for table "FTELOG"."FILE_SPACE_ENTRY"
------------------------------------------------

CREATE TABLE "FTELOG"."FILE_SPACE_ENTRY"  (
		  "ID" INTEGER NOT NULL ,
		  "FILE_SPACE_NAME" VARCHAR(256) NOT NULL ,
		  "TRANSFER_ITEM_ID" INTEGER NOT NULL , 
		  "ALIAS" NCLOB NOT NULL ,
		  "DELETED" TIMESTAMP ); 

CREATE SEQUENCE FTELOG.FILE_SPACE_ENTRY_id_SEQ START WITH 1 INCREMENT
BY 1 NOMAXVALUE;

CREATE TRIGGER FTELOG.FILE_SPACE_ENTRY_id
BEFORE INSERT ON FTELOG.FILE_SPACE_ENTRY FOR EACH ROW
BEGIN
SELECT FTELOG.FILE_SPACE_ENTRY_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

COMMENT ON TABLE "FTELOG"."FILE_SPACE_ENTRY" IS 'Each row represents a file that has been sent to the named file space.';

COMMENT ON COLUMN "FTELOG"."FILE_SPACE_ENTRY"."FILE_SPACE_NAME" IS 'The name of the file space this entry relates to.';

COMMENT ON COLUMN "FTELOG"."FILE_SPACE_ENTRY"."TRANSFER_ITEM_ID" IS 'The transfer item this row relates to.';

COMMENT ON COLUMN "FTELOG"."FILE_SPACE_ENTRY"."ALIAS" IS 'The alias name for this entry. Typically will be the name of the source file for the transfer';

COMMENT ON COLUMN "FTELOG"."FILE_SPACE_ENTRY"."DELETED" IS 'When set is the time the file was deleted from the file space. Otherwise it is null.';

ALTER TABLE "FTELOG"."FILE_SPACE_ENTRY" 
	ADD CONSTRAINT "FILE_SPACE_ENTRY_ID" PRIMARY KEY
		("ID");
		
ALTER TABLE "FTELOG"."FILE_SPACE_ENTRY" 
	ADD CONSTRAINT "VALID_TRANSFER_ITEM_ID" FOREIGN KEY
		("TRANSFER_ITEM_ID")
	REFERENCES "FTELOG"."TRANSFER_ITEM"
		("ID");
		
CREATE TABLE "FTELOG"."TRANSFER_EXIT"  (
		  "ID" INTEGER NOT NULL ,
		  "EXIT_NAME" VARCHAR(256) NOT NULL ,
		  "TRANSFER_ID" CHAR(48) NOT NULL ,
		  "TYPE" CHAR(20) NOT NULL , 
		  "STATUS" CHAR(20) ,
		  "SUPPLEMENT" VARCHAR(2048) ); 		
		
CREATE SEQUENCE FTELOG.TRANSFER_EXIT_id_SEQ START WITH 1 INCREMENT
BY 1 NOMAXVALUE;

CREATE TRIGGER FTELOG.TRANSFER_EXIT_id
BEFORE INSERT ON FTELOG.TRANSFER_EXIT FOR EACH ROW
BEGIN
SELECT FTELOG.TRANSFER_EXIT_id_SEQ.nextval INTO :new.id FROM dual;
END;
/		
		
COMMENT ON TABLE "FTELOG"."TRANSFER_EXIT" IS 'Each row represents a transfer exit which was executed for the transfer.';		 

COMMENT ON COLUMN "FTELOG"."TRANSFER_EXIT"."EXIT_NAME" IS 'The name of the exit.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EXIT"."TRANSFER_ID" IS 'The completed or cancelled transfer that this exit applies to.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EXIT"."TYPE" IS 'The type of Exit, either source or destination and start or end.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EXIT"."STATUS" IS 'The value that the Exit returned, either cancel or proceed.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EXIT"."SUPPLEMENT" IS 'Any extra output that the Exit produced';		

ALTER TABLE "FTELOG"."TRANSFER_EXIT" 
	ADD CONSTRAINT "TRANSFER_EXIT_ID" PRIMARY KEY
		("ID");

ALTER TABLE "FTELOG"."TRANSFER_EXIT"
	ADD CONSTRAINT "EXIT_TRANSFER_ID" FOREIGN KEY
		("TRANSFER_ID")
	REFERENCES "FTELOG"."TRANSFER"
		("TRANSFER_ID")

------------------------------------------------
-- DDL Statements for sequence changes
------------------------------------------------

COL wmqfte_current_val new_value wmqfte_current_val;

SELECT FTELOG.AUTH_EVENT_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.AUTH_EVENT_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.AUTH_EVENT_id
BEFORE INSERT ON FTELOG.AUTH_EVENT FOR EACH ROW
BEGIN
SELECT FTELOG.AUTH_EVENT_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.AUTH_EVENT_id;

SELECT FTELOG.CALL_ARG_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.CALL_ARGUMENT_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

DROP TRIGGER FTELOG.CALL_ARG_id;

CREATE TRIGGER FTELOG.CALL_ARGUMENT_id
BEFORE INSERT ON FTELOG.CALL_ARGUMENT FOR EACH ROW
BEGIN
SELECT FTELOG.CALL_ARGUMENT_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.CALL_ARG_id;

SELECT FTELOG.CALL_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.CALL_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.CALL_id
BEFORE INSERT ON FTELOG.CALL FOR EACH ROW
BEGIN
SELECT FTELOG.CALL_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.CALL_id;

SELECT FTELOG.CALL_RESULT_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.CALL_RESULT_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.CALL_RESULT_id
BEFORE INSERT ON FTELOG.CALL_RESULT FOR EACH ROW
BEGIN
SELECT FTELOG.CALL_RESULT_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.CALL_RESULT_id;

SELECT FTELOG.METADATA_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.METADATA_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.METADATA_id
BEFORE INSERT ON FTELOG.METADATA FOR EACH ROW
BEGIN
SELECT FTELOG.METADATA_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.METADATA_id;

SELECT FTELOG.MONITOR_ACTION_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.MONITOR_ACTION_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.MONITOR_ACTION_id
BEFORE INSERT ON FTELOG.MONITOR_ACTION FOR EACH ROW
BEGIN
SELECT FTELOG.MONITOR_ACTION_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.MONITOR_ACTION_id;

SELECT FTELOG.MONITOR_EXIT_RESULT_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.MONITOR_EXIT_RESULT_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.MONITOR_EXIT_RESULT_id
BEFORE INSERT ON FTELOG.MONITOR_EXIT_RESULT FOR EACH ROW
BEGIN
SELECT FTELOG.MONITOR_EXIT_RESULT_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.MONITOR_EXIT_RESULT_id;

SELECT FTELOG.MONITOR_METADATA_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.MONITOR_METADATA_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.MONITOR_METADATA_id
BEFORE INSERT ON FTELOG.MONITOR_METADATA FOR EACH ROW
BEGIN
SELECT FTELOG.MONITOR_METADATA_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.MONITOR_METADATA_id;

SELECT FTELOG.SCHEDULE_ACTION_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.SCHEDULE_ACTION_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.SCHEDULE_ACTION_id
BEFORE INSERT ON FTELOG.SCHEDULE_ACTION FOR EACH ROW
BEGIN
SELECT FTELOG.SCHEDULE_ACTION_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.SCHEDULE_ACTION_id;

SELECT FTELOG.SCHEDULE_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.SCHEDULE_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.SCHEDULE_id
BEFORE INSERT ON FTELOG.SCHEDULE FOR EACH ROW
BEGIN
SELECT FTELOG.SCHEDULE_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.SCHEDULE_id;

SELECT FTELOG.SCHEDULE_ITEM_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.SCHEDULE_ITEM_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.SCHEDULE_ITEM_id
BEFORE INSERT ON FTELOG.SCHEDULE_ITEM FOR EACH ROW
BEGIN
SELECT FTELOG.SCHEDULE_ITEM_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.SCHEDULE_ITEM_id;

SELECT FTELOG.SCHEDULE_SPEC_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.SCHEDULE_SPEC_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.SCHEDULE_SPEC_id
BEFORE INSERT ON FTELOG.SCHEDULE_SPEC FOR EACH ROW
BEGIN
SELECT FTELOG.SCHEDULE_SPEC_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.SCHEDULE_SPEC_id;

SELECT FTELOG.XFR_CALL_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.TRANSFER_CALLS_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

DROP TRIGGER FTELOG.XFR_CALL_id;

CREATE TRIGGER FTELOG.TRANSFER_CALLS_id
BEFORE INSERT ON FTELOG.TRANSFER_CALLS FOR EACH ROW
BEGIN
SELECT FTELOG.TRANSFER_CALLS_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.XFR_CALL_id;

SELECT FTELOG.TRANSFER_EVENT_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.TRANSFER_EVENT_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.TRANSFER_EVENT_id
BEFORE INSERT ON FTELOG.TRANSFER_EVENT FOR EACH ROW
BEGIN
SELECT FTELOG.TRANSFER_EVENT_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.TRANSFER_EVENT_id;

SELECT FTELOG.TRANSFER_ITEM_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.TRANSFER_ITEM_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.TRANSFER_ITEM_id
BEFORE INSERT ON FTELOG.TRANSFER_ITEM FOR EACH ROW
BEGIN
SELECT FTELOG.TRANSFER_ITEM_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.TRANSFER_ITEM_id;

SELECT FTELOG.TRANSFER_STATS_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.TRANSFER_STATS_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.TRANSFER_STATS_id
BEFORE INSERT ON FTELOG.TRANSFER_STATS FOR EACH ROW
BEGIN
SELECT FTELOG.TRANSFER_STATS_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.TRANSFER_STATS_id;

SELECT FTELOG.TRIGGER_CONDITION_id.nextval wmqfte_current_val FROM dual;

CREATE SEQUENCE FTELOG.TRIGGER_CONDITION_id_SEQ START WITH &wmqfte_current_val INCREMENT
BY 1 NOMAXVALUE;

CREATE OR REPLACE TRIGGER FTELOG.TRIGGER_CONDITION_id
BEFORE INSERT ON FTELOG.TRIGGER_CONDITION FOR EACH ROW
BEGIN
SELECT FTELOG.TRIGGER_CONDITION_id_SEQ.nextval INTO :new.id FROM dual;
END;
/

-- DROP SEQUENCE FTELOG.TRIGGER_CONDITION_id;
