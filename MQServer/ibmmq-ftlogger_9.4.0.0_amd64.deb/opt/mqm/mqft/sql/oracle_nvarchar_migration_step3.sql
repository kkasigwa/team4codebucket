-- ===============================================================
-- @start_non_restricted_prolog@
-- Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.databaseloader/sql/oracle_nvarchar_migration_step3.sql
-- 
-- <copyright
-- notice="lm-source-program"
-- pids="5724-H72"
-- years="2017,2018"
-- crc="3374478728" >
-- Licensed Materials - Property of IBM  
--
-- 5724-H72 
-- 
-- (C) Copyright IBM Corp. 2018  All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with    
-- IBM Corp. 
-- </copyright>
-- 
-- @end_non_restricted_prolog@
-- ===============================================================
--
-- SQL schema migration file for IBM MQ Managed File Transfer Database
-- Logger (Oracle)
-- ----------------------------------------------------
-- This file also assumes a default schema name of "FTELOG". If required, this
-- can be changed by replacing all instances of FTELOG with your preferred
-- schema name (use a text editor with search/replace function). 

-- Important Note : Before executing this script file , oracle_nvarchar_migration_step2.sql must be executed
-- ----------------------------------------------------


alter table "FTELOG"."SCHEDULE_ACTION" drop column "STATUS_TEXT";
alter table "FTELOG"."TRANSFER_ITEM" drop column "SOURCE_FILENAME";
alter table "FTELOG"."TRANSFER_ITEM" drop column "SOURCE_CHECKSUM_VALUE";
alter table "FTELOG"."TRANSFER_ITEM" drop column "DESTINATION_FILENAME";
alter table "FTELOG"."TRANSFER_ITEM" drop column "DESTINATION_CHECKSUM_VALUE";
alter table "FTELOG"."TRANSFER_ITEM" drop column "RESULT_TEXT";
alter table "FTELOG"."SCHEDULE_ITEM" drop column "SOURCE_FILENAME";
alter table "FTELOG"."SCHEDULE_ITEM" drop column "DESTINATION_FILENAME";
alter table "FTELOG"."SCHEDULE_ITEM" drop column "SOURCE_QUEUE";
alter table "FTELOG"."SCHEDULE_ITEM" drop column "DESTINATION_QUEUE";
alter table "FTELOG"."TRIGGER_CONDITION" drop column "FILENAME";
alter table "FTELOG"."CALL_ARGUMENT" drop column "VALUE";
alter table "FTELOG"."CALL" drop column "EXECUTED_COMMAND";
alter table "FTELOG"."CALL_REQUEST" drop column "RESULTTEXT";
alter table "FTELOG"."TRANSFER" drop column "RESULTTEXT";
alter table "FTELOG"."CALL_RESULT" drop column "ERROR";
alter table "FTELOG"."MONITOR_METADATA" drop column "VALUE";
alter table "FTELOG"."MONITOR_EXIT_RESULT" drop column "RESULTTEXT";
alter table "FTELOG"."MONITOR_ACTION" drop column "ORIGINAL_XML_REQUEST";
alter table "FTELOG"."MONITOR_ACTION" drop column "UPDATED_XML_REQUEST";
alter table "FTELOG"."AUTH_EVENT" drop column "RESULT_TEXT";
alter table "FTELOG"."FILE_SPACE_ENTRY" drop column "ALIAS";
