-- ===============================================================
-- @start_non_restricted_prolog@
-- Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.databaseloader/sql/ftelog_tables_oracle_701-702.sql
-- 
-- <copyright
-- notice="lm-source-program"
-- pids="5724-H72"
-- years="2009,2019"
-- crc="3374478728" >
-- Licensed Materials - Property of IBM  
--
-- 5724-H72 
-- 
-- (C) Copyright IBM Corp. 2009, 2019  All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with    
-- IBM Corp. 
-- </copyright>
--
-- @end_non_restricted_prolog@
-- ===============================================================
-- 
-- SQL schema migration file for WMQFTE Database Logger, FTE 7.0.1 - 7.0.2 (Oracle)
-- --------------------------------------------------------------------------------
--
-- ** Use this file if you have an existing FTE version 7.0.1 database which **
-- ** you wish to keep and use with FTE version 7.0.2. If you wish to create **
-- ** a new database for use with FTE version 7.0.2, use the file            **
-- ** ftelog_tables_oracle.sql instead.                                      **
-- 
-- This file contains SQL Data Definition Language statements that define the
-- schema changes necessary for FTE version 7.0.2. Before running a version 
-- 7.0.2 database logger, you must run this file against your existing database
-- to upgrade it. You can use any appropriate database tool to do this, such as
-- "@<filename>" inside SQL*Plus or a graphical tool which can import SQL DDL 
-- files.
-- 
-- Because site-specific requirements may vary greatly, this file only 
-- specifies the basic structures of the tables. Attributes such as 
-- table-spaces, LOB locations, etc are not specified. An experienced database 
-- administrator may wish to modify a copy of this file to define these 
-- performance-related attributes.
-- 
-- This file also assumes a default schema name of "FTELOG". If required, this
-- can be changed by replacing all instances of FTELOG with your preferred
-- schema name (use a text editor with search/replace function). 

-- Reduce transfer ids to 48 characters. Actual data is always 48, and different
-- column width makes some comparisons awkward.
ALTER TABLE "FTELOG"."TRANSFER_ITEM" MODIFY "TRANSFER_ID" CHAR(48);
ALTER TABLE "FTELOG"."METADATA" MODIFY "STANDALONE_CALL_ID" CHAR(48);
ALTER TABLE "FTELOG"."TRANSFER_CALLS" MODIFY "TRANSFER_ID" CHAR(48);
ALTER TABLE "FTELOG"."CALL_REQUEST" MODIFY "ID" CHAR(48);

-- Add URL records for new protocol bridge feature.
ALTER TABLE "FTELOG  "."TRANSFER_EVENT" ADD (
    "SOURCE_BRIDGE_URL" VARCHAR(2083), 
    "DESTINATION_BRIDGE_URL" VARCHAR(2083));
    
-- Add new file-size and last-modified info
ALTER TABLE "FTELOG"."TRANSFER_ITEM" ADD(
	"SOURCE_FILE_SIZE" INTEGER,
	"SOURCE_LAST_MODIFIED" TIMESTAMP,
	"DESTINATION_FILE_SIZE" INTEGER,
	"DESTINATION_LAST_MODIFIED" TIMESTAMP);

ALTER TABLE "FTELOG"."TRANSFER" ADD(
	"BYTES_TRANSFERRED" INTEGER);
	
-- Add missing comments from TRANSFER_EVENT
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."ACTION_TIME" IS 'The time that the transfer action took place.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."SOURCE_AGENT" IS 'The name of the agent from which the files are transferred.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."SOURCE_QM" IS 'The queue manager used by the source agent.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."SOURCE_BRIDGE_URL" IS 'If the source agent is a bridge agent, the URL of the data source to which it forms a bridge.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."SOURCE_ARCHITECTURE" IS 'The machine architecture of the system hosting the the source agent.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."SOURCE_OS_NAME" IS 'The operating system of the source agent machine.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."SOURCE_OS_VERSION" IS 'The version of operating system of the source agent machine.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."DESTINATION_AGENT" IS 'The name of the agent to which the files are transferred.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."DESTINATION_QM" IS 'The queue manager used by the destination agent.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."DESTINATION_BRIDGE_URL" IS 'If the destination agent is a bridge agent, the URL of the data source to which it forms a bridge.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."ORIGINATOR_HOST" IS 'The hostname of the machine from which the transfer request was submitted.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."ORIGINATOR_USER" IS 'The name of the user who submitted the transfer request, as reported by the fteCreateTransfer command.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."ORIGINATOR_MQ_USER" IS 'The name of the user who submitted the transfer request, as contained in the MQ message descriptor of the request.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."TRANSFERSET_TIME" IS 'The time at which the transferset was created.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."TRANSFERSET_SIZE" IS 'The number of items being transferred.';

    
-- Drop DB2CC exception table included in error in 7.0.1.
DROP TABLE "FTELOG  "."T20090508_113036_EXCEPTION";

-- Add the ID nature to the ID in MONITOR_ACTION
CREATE SEQUENCE MONITOR_id START WITH 1 INCREMENT
BY 1 NOMAXVALUE;

CREATE TRIGGER MONITOR_id
BEFORE INSERT ON FTELOG.MONITOR FOR EACH ROW
BEGIN
SELECT MONITOR_id.nextval INTO :new.id FROM dual;
END;
/

-- Add ID uniqueness to METADATA
ALTER TABLE "FTELOG  "."METADATA" 
	ADD CONSTRAINT "METADATA_ID" PRIMARY KEY
		("ID");

	
-- Add IDs to TRANSFER_CALLS and CALL_ARGUMENT to support REST supportPac
ALTER TABLE "FTELOG"."TRANSFER_CALLS"
	ADD ("ID" INTEGER NOT NULL );

CREATE SEQUENCE XFR_CALL_id START WITH 1 INCREMENT
BY 1 NOMAXVALUE;

CREATE TRIGGER XFR_CALL_id
BEFORE INSERT ON FTELOG.TRANSFER_CALLS FOR EACH ROW
BEGIN
SELECT XFR_CALL_id.nextval INTO :new.id FROM dual;
END;
/

ALTER TABLE "FTELOG  "."TRANSFER_CALLS" 
	ADD CONSTRAINT "XFR_CALL_ID" PRIMARY KEY
		("ID");
		    
ALTER TABLE "FTELOG"."CALL_ARGUMENT"
	ADD ("ID" INTEGER NOT NULL );	    
	
CREATE SEQUENCE CALL_ARG_id START WITH 1 INCREMENT
BY 1 NOMAXVALUE;

CREATE TRIGGER CALL_ARG_id
BEFORE INSERT ON FTELOG.TRANSFER_CALLS FOR EACH ROW
BEGIN
SELECT CALL_ARG_id.nextval INTO :new.id FROM dual;
END;
/	
	
ALTER TABLE "FTELOG  "."CALL_ARGUMENT" 
	ADD CONSTRAINT "CALL_ARG_ID" PRIMARY KEY
		("ID");		    		
		
-- Add new tables for authorisation events and queuing statistics (new features)
CREATE TABLE "FTELOG  "."AUTH_EVENT"  (
		  "ID" INTEGER NOT NULL , 
		  "ACTION" CHAR(32) NOT NULL , 
		  "COMMAND_ID" CHAR(48) NOT NULL , 
		  "TIME" TIMESTAMP NOT NULL ,
		  "ORIGINATOR_MQ_USER" CHAR(12) NOT NULL , 
		  "AUTHORITY" CHAR(64) NOT NULL ,
		  "ORIGINAL_XML_REQUEST" LONG VARCHAR , 
		  "RESULTCODE" SMALLINT NOT NULL ,
		  "RESULT_TEXT" NCLOB ,
		 IN "USERSPACE1" ; 
		 
CREATE SEQUENCE AUTH_EVENT_id START WITH 1 INCREMENT
BY 1 NOMAXVALUE;

CREATE TRIGGER AUTH_EVENT_id
BEFORE INSERT ON FTELOG.AUTH_EVENT FOR EACH ROW
BEGIN
SELECT AUTH_EVENT_id.nextval INTO :new.id FROM dual;
END;
/

COMMENT ON TABLE "FTELOG  "."AUTH_EVENT" IS 'Each row represents an authority-related event, typically the rejection of a request due to insufficient privileges.';
COMMENT ON COLUMN "FTELOG  "."AUTH_EVENT"."ACTION" IS 'The type of event that took place';
COMMENT ON COLUMN "FTELOG  "."AUTH_EVENT"."COMMAND_ID" IS 'The MQ message ID of the original message that triggered the event. In the case of a transfer request, this will also be the transfer ID.';
COMMENT ON COLUMN "FTELOG  "."AUTH_EVENT"."TIME" IS 'The time at which the event occurred';
COMMENT ON COLUMN "FTELOG  "."AUTH_EVENT"."ORIGINATOR_MQ_USER" IS 'The MQ user ID of the command message, against which the authority check was performed.';
COMMENT ON COLUMN "FTELOG  "."AUTH_EVENT"."AUTHORITY" IS 'The authority that was required for the requested action.';
COMMENT ON COLUMN "FTELOG  "."AUTH_EVENT"."ORIGINAL_XML_REQUEST" IS 'The payload of the command message, indicating precisely what action was refused.';
COMMENT ON COLUMN "FTELOG  "."AUTH_EVENT"."RESULTCODE" IS 'The numeric code identifying the result';
COMMENT ON COLUMN "FTELOG  "."AUTH_EVENT"."RESULT_TEXT" IS 'A text message explaining the authority event.';


ALTER TABLE "FTELOG  "."AUTH_EVENT" 
	ADD CONSTRAINT "AUTH_EVENT_ID" PRIMARY KEY
		("ID");

		
CREATE TABLE "FTELOG  "."TRANSFER_STATS"  (
		  "ID" INTEGER NOT NULL , 
		  "TRANSFER_ID" CHAR(48) NOT NULL , 
		  "START_TIME" TIMESTAMP NOT NULL , 
		  "RETRY_COUNT" INTEGER NOT NULL , 
		  "FILE_FAILURES" INTEGER NOT NULL, 
		  "FILE_WARNINGS" INTEGER NOT NULL )
		 IN "USERSPACE1" ; 

CREATE SEQUENCE TRANSFER_STATS_id START WITH 1 INCREMENT
BY 1 NOMAXVALUE;

CREATE TRIGGER TRANSFER_STATS_id
BEFORE INSERT ON FTELOG.TRANSFER_STATS FOR EACH ROW
BEGIN
SELECT TRANSFER_STATS_id.nextval INTO :new.id FROM dual;
END;
/

COMMENT ON TABLE "FTELOG  "."TRANSFER_STATS" IS 'Each row represents a set of statistics generated at the end of a transfer.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_STATS"."TRANSFER_ID" IS 'The transfer to which the stats refer.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_STATS"."START_TIME" IS 'The time at which the transfer actually started. In a system that is busy or has intermittent connectivity, this may be later than the time reported in the Started message, as that time represents the point at which initial processing began rather than successful transfer of data.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_STATS"."RETRY_COUNT" IS 'The number of times that the transfer had to be retried due to load or availability issues.';

ALTER TABLE "FTELOG  "."TRANSFER_STATS" 
	ADD CONSTRAINT "TRANSFER_STATS_ID" PRIMARY KEY
		("ID");
		
		
ALTER TABLE "FTELOG  "."TRANSFER_STATS" 
	ADD CONSTRAINT "STATS_TRANSFER_ID" FOREIGN KEY
		("TRANSFER_ID")
	REFERENCES "FTELOG  "."TRANSFER"
		("TRANSFER_ID");
		
