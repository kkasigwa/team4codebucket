-- ===============================================================
-- @start_non_restricted_prolog@
-- Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.databaseloader/sql/ftelog_tables_db2_702-703.sql
-- 
-- 
-- <copyright
-- notice="lm-source-program"
-- pids="5724-H72"
-- years="2010,2019"
-- crc="3374478728" >
-- Licensed Materials - Property of IBM  
--
-- 5724-H72 
-- 
-- (C) Copyright IBM Corp. 2010, 2019  All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with    
-- IBM Corp. 
-- </copyright>
--
-- @end_non_restricted_prolog@
-- ===============================================================
-- 
-- SQL schema migration file for WMQFTE Database Logger, FTE 7.0.2 - 7.0.3 (DB2)
-- -----------------------------------------------------------------------------
--
-- ** Use this file if you have an existing FTE version 7.0.2 database which **
-- ** you wish to keep and use with FTE version 7.0.3. If you wish to create **
-- ** a new database for use with FTE version 7.0.3, use the file            **
-- ** ftelog_tables_db2.sql instead.                                         **
-- 
-- This file contains SQL Data Definition Language statements that define the
-- schema changes necessary for FTE version 7.0.3. Before running a version 
-- 7.0.3 database logger, you must run this file against your existing database
-- to upgrade it. You can use any appropriate database tool to do this, such as 
-- "db2 -t -f <filename>" or the DB2 graphical Control Center.
-- 
-- Because site-specific requirements may vary greatly, this file only 
-- specifies the basic structures of the tables. Attributes such as 
-- table-spaces, LOB locations, etc are not specified. An experienced database 
-- administrator may wish to modify a copy of this file to define these 
-- performance-related attributes.
-- 
-- This file also assumes a default schema name of "FTELOG". If required, this
-- can be changed by replacing all instances of FTELOG with your preferred
-- schema name (use a text editor with search/replace function). 

-- Add new columns to the TRANSFER_ITEM table
ALTER TABLE "FTELOG  "."TRANSFER_ITEM" ADD COLUMN "SOURCE_MESSAGE_QUEUE_NAME" CHAR(128);
ALTER TABLE "FTELOG  "."TRANSFER_ITEM" ADD COLUMN "SOURCE_MESSAGE_GROUP_ID" CHAR(48);
ALTER TABLE "FTELOG  "."TRANSFER_ITEM" ADD COLUMN "SOURCE_MESSAGE_COUNT" INTEGER;
ALTER TABLE "FTELOG  "."TRANSFER_ITEM" ADD COLUMN "DESTINATION_MESSAGE_QUEUE_NAME" CHAR(128);
ALTER TABLE "FTELOG  "."TRANSFER_ITEM" ADD COLUMN "DESTINATION_MESSAGE_MESSAGE_ID" CHAR(48);
ALTER TABLE "FTELOG  "."TRANSFER_ITEM" ADD COLUMN "DESTINATION_MESSAGE_GROUP_ID" CHAR(48);
ALTER TABLE "FTELOG  "."TRANSFER_ITEM" ADD COLUMN "DESTINATION_MESSAGE_COUNT" INTEGER;
ALTER TABLE "FTELOG  "."TRANSFER_ITEM" ADD COLUMN "DESTINATION_MESSAGE_LENGTH" BIGINT;
ALTER TABLE "FTELOG  "."TRANSFER_ITEM" ADD COLUMN "SEQUENCE" SMALLINT;

-- Add comments for new columns    
COMMENT ON COLUMN "FTELOG  "."TRANSFER_ITEM"."SOURCE_MESSAGE_QUEUE_NAME" IS 'The source queue for the message(s) to be included in the destination file.';

COMMENT ON COLUMN "FTELOG  "."TRANSFER_ITEM"."SOURCE_MESSAGE_GROUP_ID" IS 'The group ID of the message(s) to be included in the destination file.';

COMMENT ON COLUMN "FTELOG  "."TRANSFER_ITEM"."SOURCE_MESSAGE_COUNT" IS 'The number of messages to be included in the destination file.';

COMMENT ON COLUMN "FTELOG  "."TRANSFER_ITEM"."DESTINATION_MESSAGE_QUEUE_NAME" IS 'The destination queue for the message(s) produced from the source file.';

COMMENT ON COLUMN "FTELOG  "."TRANSFER_ITEM"."DESTINATION_MESSAGE_MESSAGE_ID" IS 'The message ID of the message produced from the source file. May be null if the transfer resulted in multiple messages.';

COMMENT ON COLUMN "FTELOG  "."TRANSFER_ITEM"."DESTINATION_MESSAGE_GROUP_ID" IS 'The group ID of the message(s) produced from the source file. May be null if the transfer resulted in only a single message.';

COMMENT ON COLUMN "FTELOG  "."TRANSFER_ITEM"."DESTINATION_MESSAGE_COUNT" IS 'The number of messages that the source file was split into.';

COMMENT ON COLUMN "FTELOG  "."TRANSFER_ITEM"."DESTINATION_MESSAGE_LENGTH" IS 'The length of the message produced from the source file.';

COMMENT ON COLUMN "FTELOG  "."TRANSFER_ITEM"."SEQUENCE" IS 'The sequence number within the transfer of this transfer item.';

-- Modify existing TRANSFER_ITEM columns
ALTER TABLE "FTELOG  "."TRANSFER_ITEM"
    ALTER COLUMN "SOURCE_FILENAME" DROP NOT NULL
    ALTER COLUMN "DESTINATION_FILENAME" DROP NOT NULL;
REORG TABLE FTELOG.TRANSFER_ITEM ALLOW READ ACCESS ;
    
-- Add new columns to the TRANSFER Table
ALTER TABLE "FTELOG  "."TRANSFER" ADD COLUMN "STATUS" CHAR(20);
ALTER TABLE "FTELOG  "."TRANSFER" ADD COLUMN "RELATED_TRANSFER_ID" CHAR(48);

 
COMMENT ON COLUMN "FTELOG  "."TRANSFER"."STATUS" IS 'The status of a transfer (started, success, partial success, failure, cancelled)';
COMMENT ON COLUMN "FTELOG  "."TRANSFER"."RELATED_TRANSFER_ID" IS 'A previous transfer related to this specific transfer e.g. A Web Gateway download transfer will refer to the upload transfer for the file that is downloaded.';

-- Calculate the new status column for existing transfers
-- in the database.
UPDATE "FTELOG  "."TRANSFER" SET STATUS= 'started' WHERE  START_ID IS NOT NULL AND COMPLETE_ID IS NULL;
UPDATE "FTELOG  "."TRANSFER" SET STATUS= 'success' WHERE COMPLETE_ID IS NOT NULL AND RESULTCODE = 0;
UPDATE "FTELOG  "."TRANSFER" SET STATUS= 'partial success' WHERE COMPLETE_ID IS NOT NULL AND RESULTCODE = 20;
UPDATE "FTELOG  "."TRANSFER" SET STATUS= 'failure' WHERE COMPLETE_ID IS NOT NULL AND RESULTCODE NOT IN (20,0);
REORG TABLE FTELOG.TRANSFER ALLOW READ ACCESS ;


-- Add new columns to the TRANSFER_EVENT table
ALTER TABLE "FTELOG  "."TRANSFER_EVENT" ADD COLUMN "SOURCE_WEB_GATEWAY" CHAR(28);
ALTER TABLE "FTELOG  "."TRANSFER_EVENT" ADD COLUMN "DESTINATION_WEB_GATEWAY" CHAR(28);
ALTER TABLE "FTELOG  "."TRANSFER_EVENT" ADD COLUMN "ORIGINATOR_WEB_USER" VARCHAR(256);

COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."SOURCE_WEB_GATEWAY" IS 'The name of the web gateway from which the files are transferred.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."DESTINATION_WEB_GATEWAY" IS 'The name of the web gateway to which the files are transferred.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EVENT"."ORIGINATOR_WEB_USER" IS 'The name of the web user who submitted the request.';

-- Modify existing TRANSFER_EVENT columns
ALTER TABLE "FTELOG  "."TRANSFER_EVENT"
	ALTER COLUMN "SOURCE_AGENT" DROP NOT NULL 
	ALTER COLUMN "SOURCE_QM" DROP NOT NULL
	ALTER COLUMN "SOURCE_ARCHITECTURE" DROP NOT NULL 
	ALTER COLUMN "SOURCE_OS_NAME" DROP NOT NULL
	ALTER COLUMN "SOURCE_OS_VERSION" DROP NOT NULL
	ALTER COLUMN "DESTINATION_AGENT" DROP NOT NULL 
	ALTER COLUMN "DESTINATION_QM" DROP NOT NULL
	ALTER COLUMN "ORIGINATOR_MQ_USER" DROP NOT NULL;
REORG TABLE FTELOG.TRANSFER_EVENT ALLOW READ ACCESS ;



-- Modify existing TRANSFER_STATS columns
ALTER TABLE "FTELOG  "."TRANSFER_STATS"
    ALTER COLUMN "START_TIME" DROP NOT NULL;
REORG TABLE FTELOG.TRANSFER_STATS ALLOW READ ACCESS ;

------------------------------------------------
-- DDL Statements for table "FTELOG  "."FILE_SPACE_ENTRY"
------------------------------------------------

CREATE TABLE "FTELOG  "."FILE_SPACE_ENTRY"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "FILE_SPACE_NAME" VARCHAR(256) NOT NULL , 
		  "TRANSFER_ITEM_ID" BIGINT NOT NULL ,
		  "ALIAS" LONG VARCHAR ,
		  "DELETED" TIMESTAMP )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG  "."FILE_SPACE_ENTRY" IS 'Each row represents a file that has been sent to the named file space.';

COMMENT ON COLUMN "FTELOG  "."FILE_SPACE_ENTRY"."FILE_SPACE_NAME" IS 'The name of the file space this entry relates to.';

COMMENT ON COLUMN "FTELOG  "."FILE_SPACE_ENTRY"."TRANSFER_ITEM_ID" IS 'The transfer item this row relates to.';

COMMENT ON COLUMN "FTELOG  "."FILE_SPACE_ENTRY"."ALIAS" IS 'The alias name for this entry. Typically will be the name of the source file for the transfer';

COMMENT ON COLUMN "FTELOG  "."FILE_SPACE_ENTRY"."DELETED" IS 'When set is the time the file was deleted from the file space. Otherwise it is null.';

-- DDL Statements for primary key on Table "FTELOG  "."FILE_SPACE_ENTRY"

ALTER TABLE "FTELOG  "."FILE_SPACE_ENTRY" 
	ADD CONSTRAINT "FILE_SPACE_ENTRYID" PRIMARY KEY
		("ID");

------------------------------------------------
-- DDL Statements for table "FTELOG  "."TRANSFER_EXIT"
------------------------------------------------
		
CREATE TABLE "FTELOG  "."TRANSFER_EXIT"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "EXIT_NAME" VARCHAR(256) NOT NULL , 
		  "TRANSFER_ID" CHAR(48) NOT NULL ,
		  "TYPE" CHAR(20) NOT NULL,
		  "STATUS" CHAR(20),
		  "SUPPLEMENT" VARCHAR(2048) )  
		 IN "USERSPACE1" ; 		

COMMENT ON TABLE "FTELOG  "."TRANSFER_EXIT" IS 'Each row represents a transfer exit which was executed for the transfer.';		 

COMMENT ON COLUMN "FTELOG  "."TRANSFER_EXIT" . "EXIT_NAME" IS 'The name of the exit.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EXIT" . "TRANSFER_ID" IS 'The completed or cancelled transfer that this exit applies to.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EXIT" . "TYPE" IS 'The type of Exit, either source or destination and start or end.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EXIT" . "STATUS" IS 'The value that the Exit returned, either cancel or proceed.';
COMMENT ON COLUMN "FTELOG  "."TRANSFER_EXIT" . "SUPPLEMENT" IS 'Any extra output that the Exit produced';

ALTER TABLE "FTELOG  "."TRANSFER_EXIT" 
	ADD CONSTRAINT "TRANSFER_EXIT_ID" PRIMARY KEY
		("ID");
		
		
-- DDL Statements for foreign keys on Table "FTELOG  "."FILE_SPACE_ENTRY"

ALTER TABLE "FTELOG  "."FILE_SPACE_ENTRY" 
	ADD CONSTRAINT "VALID_TFER_ITEM_ID" FOREIGN KEY
		("TRANSFER_ITEM_ID")
	REFERENCES "FTELOG  "."TRANSFER_ITEM"
		("ID")
	ON DELETE RESTRICT
	ON UPDATE RESTRICT
	ENFORCED
	ENABLE QUERY OPTIMIZATION;
		
-- DDL Statements for foreign keys on Table "FTELOG  "."TRANSFER_EXIT"

ALTER TABLE "FTELOG  "."TRANSFER_EXIT" 
	ADD CONSTRAINT "VALID_TRANSFER_ID" FOREIGN KEY
		("TRANSFER_ID")
	REFERENCES "FTELOG  "."TRANSFER"
		("TRANSFER_ID")
	ON DELETE RESTRICT
	ON UPDATE RESTRICT
	ENFORCED
	ENABLE QUERY OPTIMIZATION;			
	
COMMIT WORK;
		