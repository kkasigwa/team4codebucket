-- ===============================================================
-- @start_non_restricted_prolog@
-- Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.databaseloader/sql/ftelog_tables_zos_7502-800.sql 
--          %I% 
--          %W% 
--          %E% 
--          %U% 
--          [%H% %T%]
--
-- <copyright
-- notice="lm-source-program"
-- pids="5724-H72"
-- years="2013,2019"
-- crc="3374478728" >
-- Licensed Materials - Property of IBM  
--
-- 5724-H72 
-- 
-- (C) Copyright IBM Corp. 2013, 2019  All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with    
-- IBM Corp. 
-- </copyright>
--
-- @end_non_restricted_prolog@
-- ===============================================================
--
-- SQL data migration file for WMQFTE Database Logger 7.5.0.2 - 8.0.0
-- (DB2 for zOS)
-- -----------------------------------------------------------
--
-- Before running the database logger, you must carry out the data 
-- migration steps as defined in the migration section in the 8.0.0 
-- infocenter.
-- This file contains SQL that will transfer the existing data in 
-- your 7.5.0.2 tables into a set of tables created using the 
-- ftelog_tables_zos.sql script supplied as part of your 8.0.0 
-- installation. You can use any appropriate database tool to do 
-- this, such as SPUFI or an appropriately configured DB2 Command 
-- Center GUI.
--
-- Because site-specific requirements may vary greatly, this file only
-- specifies the basic structures of the tables. Attributes such as
-- table-spaces, LOB locations, etc are not specified. An experienced
-- database administrator may wish to modify a copy of this file to
-- define these performance-related attributes.
--
-- ********************************************************************
-- ** In order to use this file you must first replace all           **
-- ** occurences of FTESRC with your source (7.5.0.2) schema name and  **
-- ** all occurences of FTEDEST with your destination (8.0.0)      **
-- ** schema name.                                                   **
-- ********************************************************************

INSERT INTO "FTEDEST"."AUTH_EVENT"
  SELECT * FROM "FTESRC"."AUTH_EVENT";

INSERT INTO "FTEDEST"."CALL"
  SELECT * FROM "FTESRC"."CALL";
  
INSERT INTO "FTEDEST"."CALL_ARGUMENT"
  SELECT * FROM "FTESRC"."CALL_ARGUMENT";
  
INSERT INTO "FTEDEST"."CALL_REQUEST"
  SELECT * FROM "FTESRC"."CALL_REQUEST";
  
INSERT INTO "FTEDEST"."CALL_RESULT"
  SELECT * FROM "FTESRC"."CALL_RESULT";
  
INSERT INTO "FTEDEST"."FILE_SPACE_ENTRY"
  SELECT * FROM "FTESRC"."FILE_SPACE_ENTRY";
  
INSERT INTO "FTEDEST"."METADATA"
  SELECT * FROM "FTESRC"."METADATA";
  
INSERT INTO "FTEDEST"."MONITOR"
  SELECT * FROM "FTESRC"."MONITOR";
  
INSERT INTO "FTEDEST"."MONITOR_ACTION"
  SELECT * FROM "FTESRC"."MONITOR_ACTION";
  
INSERT INTO "FTEDEST"."MONITOR_EXIT_RESULT"
  SELECT * FROM "FTESRC"."MONITOR_EXIT_RESULT";
  
INSERT INTO "FTEDEST"."MONITOR_METADATA"
  SELECT * FROM "FTESRC"."MONITOR_METADATA";
  
INSERT INTO "FTEDEST"."SCHEDULE_ACTION"
  SELECT * FROM "FTESRC"."SCHEDULE_ACTION";

INSERT INTO "FTEDEST"."SCHEDULE"
  SELECT * FROM "FTESRC"."SCHEDULE";
  
INSERT INTO "FTEDEST"."SCHEDULE_SPEC"
  SELECT * FROM "FTESRC"."SCHEDULE_SPEC";
  
INSERT INTO "FTEDEST"."SCHEDULE_ITEM"
  SELECT (ID, SCHEDULE_SPEC_ID, SOURCE_FILENAME, FILE_MODE,
          CHECKSUM_METHOD, RECURSIVE, SOURCE_DISPOSITION,
          DESTINATION_FILENAME, DESTINATION_TYPE, 
          DESTINATION_EXISTS_ACTION)
  FROM "FTESRC"."SCHEDULE_ITEM";

INSERT INTO "FTEDEST"."TRANSFER"
  SELECT * FROM "FTESRC"."TRANSFER";
  
INSERT INTO "FTEDEST"."TRANSFER_CALLS"
  SELECT * FROM "FTESRC"."TRANSFER_CALLS";
  
INSERT INTO "FTEDEST"."TRANSFER_CD_NODE"
  SELECT * FROM "FTESRC"."TRANSFER_CD_NODE";
  
INSERT INTO "FTEDEST"."TRANSFER_EVENT"
  SELECT * FROM "FTESRC"."TRANSFER_EVENT";
  
INSERT INTO "FTEDEST"."TRANSFER_EXIT"
  SELECT * FROM "FTESRC"."TRANSFER_EXIT";  
  
INSERT INTO "FTEDEST"."TRANSFER_CORRELATOR"
  SELECT * FROM "FTESRC"."TRANSFER_CORRELATOR";
  
INSERT INTO "FTEDEST"."TRANSFER_ITEM"
  SELECT (ID, TRANSFER_ID, FILE_MODE, SOURCE_FILENAME,
	      SOURCE_LINEEND, SOURCE_ENCODING, 
	      SOURCE_CHECKSUM_METHOD, SOURCE_CHECKSUM_VALUE,
		  SOURCE_DISPOSITION, SOURCE_FILE_SIZE,
		  SOURCE_LAST_MODIFIED, SOURCE_MESSAGE_QUEUE_NAME,
		  SOURCE_MESSAGE_GROUP_ID, SOURCE_MESSAGE_COUNT,
		  SOURCE_CORRELATOR_ID, DESTINATION_FILENAME,
		  DESTINATION_LINEEND, DESTINATION_ENCODING,
		  DESTINATION_CHECKSUM_METHOD,
		  DESTINATION_CHECKSUM_VALUE,
		  DESTINATION_EXISTS_ACTION,
		  DESTINATION_FILE_SIZE,
		  DESTINATION_LAST_MODIFIED,
		  DESTINATION_MESSAGE_QUEUE_NAME,
		  DESTINATION_MESSAGE_MESSAGE_ID,
		  DESTINATION_MESSAGE_GROUP_ID,
		  DESTINATION_MESSAGE_COUNT,
		  DESTINATION_MESSAGE_LENGTH,
		  DESTINATION_CORRELATOR_ID, RESULTCODE ,
		  RESULT_TEXT, SEQUENCE) 
  FROM "FTESRC"."TRANSFER_ITEM";

INSERT INTO "FTEDEST"."TRANSFER_ITEM_ATTRIBUTES"
  SELECT * FROM "FTESRC"."TRANSFER_ITEM_ATTRIBUTES";

INSERT INTO "FTEDEST"."TRANSFER_STATS"
  SELECT * FROM "FTESRC"."TRANSFER_STATS";
  
INSERT INTO "FTEDEST"."TRIGGER_CONDITION"
  SELECT * FROM "FTESRC"."TRIGGER_CONDITION";
    
INSERT INTO "FTEDEST"."TRANSACTION_LOG"
  SELECT * FROM "FTESRC"."TRANSACTION_LOG";
  
COMMIT WORK;