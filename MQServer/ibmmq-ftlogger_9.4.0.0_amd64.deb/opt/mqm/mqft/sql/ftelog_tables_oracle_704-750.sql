-- 
-- Licensed Materials - Property of IBM
-- 
-- <copyright
-- notice="lm-source-program"
-- pids="5724-H72"
-- years="2012,2019"
-- crc="3374478728" >
-- Licensed Materials - Property of IBM  
--
-- 5724-H72 
-- 
-- (C) Copyright IBM Corp. 2012, 2019  All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with    
-- IBM Corp. 
-- </copyright>
--
-- @end_non_restricted_prolog@
-- ===============================================================
-- 
-- SQL schema migration file for MQMFT Database Logger, MFT 7.0.4 - 7.5.0 (Oracle)
-- --------------------------------------------------------------------------------
--
-- ** Use this file if you have an existing MFT version 7.0.4 database which **
-- ** you wish to keep and use with MFT version 7.5.0. If you wish to create **
-- ** a new database for use with MFT version 7.5.0, use the file            **
-- ** ftelog_tables_oracle.sql instead.                                      **
-- 
-- This file contains SQL Data Definition Language statements that define the
-- schema changes necessary for MFT version 7.5.0. Before running a version 
-- 7.5.0 database logger, you must run this file against your existing database
-- to upgrade it. You can use any appropriate database tool to do this, such as
-- "@<filename>" inside SQL*Plus or a graphical tool which can import SQL DDL 
-- files.
-- 
-- Because site-specific requirements may vary greatly, this file only 
-- specifies the basic structures of the tables. Attributes such as 
-- table-spaces, LOB locations, etc are not specified. An experienced database 
-- administrator may wish to modify a copy of this file to define these 
-- performance-related attributes.
-- 
-- This file also assumes a default schema name of "FTELOG". If required, this
-- can be changed by replacing all instances of FTELOG with your preferred
-- schema name (use a text editor with search/replace function). 

------------------------------------------------
-- DDL Statements for table "FTELOG"."TRANSACTION_LOG"
------------------------------------------------		
		
CREATE TABLE "FTELOG"."TRANSACTION_LOG" (
          "MESSAGE_ID" CHAR(48) NOT NULL);
         
COMMENT ON TABLE "FTELOG"."TRANSACTION_LOG" IS 'Each row represents the message ID of a log message that has been successfully processed.';

COMMENT ON COLUMN "FTELOG"."TRANSACTION_LOG"."MESSAGE_ID" IS 'The message ID successfully processed log message.';         
		
ALTER TABLE "FTELOG"."TRANSACTION_LOG" 
	ADD CONSTRAINT "TRANSACTION_LOG_ID" PRIMARY KEY
		("MESSAGE_ID");
