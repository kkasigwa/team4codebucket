-- ===============================================================
-- @start_non_restricted_prolog@
-- Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.databaseloader/sql/ftelog_tables_db2_750-7502.sql
-- 
-- <copyright
-- notice="lm-source-program"
-- pids="5724-H72"
-- years="2012,2019"
-- crc="3374478728" >
-- Licensed Materials - Property of IBM  
--
-- 5724-H72 
-- 
-- (C) Copyright IBM Corp. 2012, 2019  All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with    
-- IBM Corp. 
-- </copyright>
--
-- @end_non_restricted_prolog@
-- ===============================================================
-- 
-- SQL schema migration file for MQMFT Database Logger, MFT 7.5.0 - 7.5.0.2 (DB2)
-- -----------------------------------------------------------------------------
--
-- ** Use this file if you have an existing MFT version 7.5.0 database which   **
-- ** you wish to keep and use with MFT version 7.5.0.2. If you wish to create **
-- ** a new database for use with MFT version 7.5.0.2, use the file            **
-- ** ftelog_tables_db2.sql instead.                                           **
-- 
-- This file contains SQL Data Definition Language statements that define the
-- schema changes necessary for MFT version 7.5.0.2. Before running a version 
-- 7.5.0.2 database logger, you must run this file against your existing database
-- to upgrade it. You can use any appropriate database tool to do this, such as 
-- "db2 -t -f <filename>" or the DB2 graphical Control Center.
-- 
-- Because site-specific requirements may vary greatly, this file only 
-- specifies the basic structures of the tables. Attributes such as 
-- table-spaces, LOB locations, etc are not specified. An experienced database 
-- administrator may wish to modify a copy of this file to define these 
-- performance-related attributes.
-- 
-- This file also assumes a default schema name of "FTELOG". If required, this
-- can be changed by replacing all instances of FTELOG with your preferred
-- schema name (use a text editor with search/replace function). 

------------------------------------------------
-- DDL Statements for table "FTELOG"."TRANSFER_ITEM_ATTRIBUTES"
------------------------------------------------		
		
CREATE TABLE "FTELOG"."TRANSFER_ITEM_ATTRIBUTES" (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
          "TRANSFER_ITEM_ID" BIGINT NOT NULL,
          "ATTRIBUTE_NAME" VARCHAR(256) NOT NULL,
          "ATTRIBUTE_VALUE" VARCHAR(256))
         IN "USERSPACE1";
         
COMMENT ON TABLE "FTELOG"."TRANSFER_ITEM_ATTRIBUTES" IS 'Each row represents an attribute name/value pair associated with a row in the TRANSFER_ITEM table.';

COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM_ATTRIBUTES"."TRANSFER_ITEM_ID" IS 'The TRANSFER_ITEM row associated with this attribute name/value pair.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM_ATTRIBUTES"."ATTRIBUTE_NAME" IS 'The name of the attribute.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM_ATTRIBUTES"."ATTRIBUTE_VALUE" IS 'The value of the attribute, if any.';
		
ALTER TABLE "FTELOG"."TRANSFER_ITEM_ATTRIBUTES" 
	ADD CONSTRAINT "TRANSFER_ITEM_ATTRIBUTES_ID" PRIMARY KEY
		("ID");
		
------------------------------------------------
-- DDL Statements for table "FTELOG"."CALL"
------------------------------------------------		
		
ALTER TABLE "FTELOG"."CALL" ADD COLUMN "PRIORITY" INTEGER WITH DEFAULT 0;
ALTER TABLE "FTELOG"."CALL" ADD COLUMN "MESSAGE" VARCHAR(46);
		
COMMENT ON COLUMN "FTELOG"."CALL"."COMMAND" IS 'The command that was run. This field does not include any arguments passed to the command or the path where the command is located.';
COMMENT ON COLUMN "FTELOG"."CALL"."TYPE" IS 'The type of the call. Possible values: executable, antscript, jcl or os4690background.';
COMMENT ON COLUMN "FTELOG"."CALL"."RETRIES" IS 'The number of retries that were requested.';
COMMENT ON COLUMN "FTELOG"."CALL"."RETRY_WAIT" IS 'The interval to wait between retries as originally requested, in seconds.';
COMMENT ON COLUMN "FTELOG"."CALL"."SUCCESS_RC" IS 'The return code that indicates a successful completion of the command. If any other code is received, the run is reported to have failed. When the type for this call is os4690background this value is ignored.';
COMMENT ON COLUMN "FTELOG"."CALL"."EXECUTED_COMMAND" IS 'The full name of the command that was run, including path.';
COMMENT ON COLUMN "FTELOG"."CALL"."CAPPED_RETRIES" IS 'The number of retries available; this number might be less than requested if the retry limit of the agent is lower than the number of retries requested.';
COMMENT ON COLUMN "FTELOG"."CALL"."CAPPED_RETRY_WAIT" IS 'The interval between retries that is used; this number might be less than requested if the configured limit of the agent is lower than the retry wait requested.';
COMMENT ON COLUMN "FTELOG"."CALL"."OUTCOME" IS 'Whether the call was successful overall. If there were multiple tries the outcome of each one is recorded separately in the CALL_RESULT table.';
COMMENT ON COLUMN "FTELOG"."CALL"."PRIORITY" IS 'The application priority used to launch the background application when the type for this call is os4690background.';
COMMENT ON COLUMN "FTELOG"."CALL"."MESSAGE" IS 'The initial status message for the background application when the type for this call is os4690background. NULL if the type is not os4690background.';
		
------------------------------------------------
-- DDL Statements for foreign keys on Tables
------------------------------------------------

-- DDL Statements for foreign keys on Table "FTELOG"."TRANSFER_ITEM_ATTRIBUTES"

ALTER TABLE "FTELOG"."TRANSFER_ITEM_ATTRIBUTES" 
	ADD CONSTRAINT "VALID_TRANSFER_ITEM_ID" FOREIGN KEY
		("TRANSFER_ITEM_ID")
	REFERENCES "FTELOG"."TRANSFER_ITEM"
		("ID")
	ON DELETE RESTRICT
	ON UPDATE RESTRICT
	ENFORCED
	ENABLE QUERY OPTIMIZATION;	
