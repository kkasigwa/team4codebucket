-- ===============================================================
-- @start_non_restricted_prolog@
-- Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.databaseloader/sql/oracle_nvarchar_migration_step2.sql
-- 
-- <copyright
-- notice="lm-source-program"
-- pids="5724-H72"
-- years="2017,2018"
-- crc="3374478728" >
-- Licensed Materials - Property of IBM  
--
-- 5724-H72 
-- 
-- (C) Copyright IBM Corp. 2018  All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with    
-- IBM Corp. 
-- </copyright>
-- 
-- @end_non_restricted_prolog@
-- ===============================================================
--
-- SQL schema migration file for IBM MQ Managed File Transfer Database
-- Logger (Oracle)
-- ----------------------------------------------------
-- This file also assumes a default schema name of "FTELOG". If required, this
-- can be changed by replacing all instances of FTELOG with your preferred
-- schema name (use a text editor with search/replace function). 

-- Important Note : Before executing this script file , oracle_nvarchar_migration_step1.sql must be executed
-- ----------------------------------------------------


Update "FTELOG"."SCHEDULE_ACTION" 	 set "STATUS_TEXT1"  = dbms_lob.substr("STATUS_TEXT" ,2000,1);
Update "FTELOG"."TRANSFER_ITEM"	 set "SOURCE_FILENAME1"  = dbms_lob.substr("SOURCE_FILENAME",2000,1);
Update "FTELOG"."TRANSFER_ITEM"	 set "SOURCE_CHECKSUM_VALUE1"  = dbms_lob.substr("SOURCE_CHECKSUM_VALUE" ,2000,1);
Update "FTELOG"."TRANSFER_ITEM"	 set "DESTINATION_FILENAME1"  = dbms_lob.substr("DESTINATION_FILENAME",2000,1);
Update "FTELOG"."TRANSFER_ITEM"	 set "DESTINATION_CHECKSUM_VALUE1"  = dbms_lob.substr("DESTINATION_CHECKSUM_VALUE" ,2000,1);
Update "FTELOG"."TRANSFER_ITEM"	 set "RESULT_TEXT1"  = dbms_lob.substr("RESULT_TEXT" ,2000,1);
Update "FTELOG"."SCHEDULE_ITEM"	 set "SOURCE_FILENAME1"  = dbms_lob.substr("SOURCE_FILENAME" ,2000,1);
Update "FTELOG"."SCHEDULE_ITEM"	 set "DESTINATION_FILENAME1"  = dbms_lob.substr("DESTINATION_FILENAME" ,2000,1);
Update "FTELOG"."SCHEDULE_ITEM"	 set "SOURCE_QUEUE1"  = dbms_lob.substr("SOURCE_QUEUE" ,256,1);
Update "FTELOG"."SCHEDULE_ITEM"	 set "DESTINATION_QUEUE1"  = dbms_lob.substr("DESTINATION_QUEUE" ,256,1);
Update "FTELOG"."TRIGGER_CONDITION" set "FILENAME1"  = dbms_lob.substr("FILENAME" ,2000,1);
Update "FTELOG"."CALL_ARGUMENT"	 set "VALUE1"  = dbms_lob.substr("VALUE" ,2000,1);
Update "FTELOG"."CALL"				 set "EXECUTED_COMMAND1"  = dbms_lob.substr("EXECUTED_COMMAND" ,2000,1);
Update "FTELOG"."CALL_REQUEST"		 set "RESULTTEXT1"  = dbms_lob.substr("RESULTTEXT" ,2000,1);
Update "FTELOG"."TRANSFER"			 set "RESULTTEXT1"  = dbms_lob.substr("RESULTTEXT" ,2000,1);
Update "FTELOG"."CALL_RESULT"		 set "ERROR1"  = dbms_lob.substr("ERROR" ,2000,1);
Update "FTELOG"."MONITOR_METADATA"	 set "VALUE1"  = dbms_lob.substr("VALUE" ,2000,1);
Update "FTELOG"."MONITOR_EXIT_RESULT"	 set "RESULTTEXT1"  = dbms_lob.substr("RESULTTEXT" ,2000,1);
Update "FTELOG"."MONITOR_ACTION"	 set "ORIGINAL_XML_REQUEST1"  = dbms_lob.substr("ORIGINAL_XML_REQUEST" ,2000,1);
Update "FTELOG"."MONITOR_ACTION"	 set "UPDATED_XML_REQUEST1"  = dbms_lob.substr("UPDATED_XML_REQUEST" ,2000,1);
Update "FTELOG"."AUTH_EVENT"		 set "RESULT_TEXT1"  = dbms_lob.substr("RESULT_TEXT" ,2000,1);
Update "FTELOG"."FILE_SPACE_ENTRY"	 set "ALIAS1"  = dbms_lob.substr("ALIAS" ,2000,1);