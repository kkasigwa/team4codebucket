-- 
-- Licensed Materials - Property of IBM
-- 
-- <copyright
-- notice="lm-source-program"
-- pids="5724-H72"
-- years="2011,2019"
-- crc="3374478728" >
-- Licensed Materials - Property of IBM  
--
-- 5724-H72 
-- 
-- (C) Copyright IBM Corp. 2011, 2019  All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with    
-- IBM Corp. 
-- </copyright>
--
-- @end_non_restricted_prolog@
-- ===============================================================
-- 
-- SQL schema migration file for WMQFTE Database Logger, FTE 7.0.3 - 7.0.4 (Oracle)
-- --------------------------------------------------------------------------------
--
-- ** Use this file if you have an existing FTE version 7.0.3 database which **
-- ** you wish to keep and use with FTE version 7.0.4. If you wish to create **
-- ** a new database for use with FTE version 7.0.4, use the file            **
-- ** ftelog_tables_oracle.sql instead.                                      **
-- 
-- This file contains SQL Data Definition Language statements that define the
-- schema changes necessary for FTE version 7.0.4. Before running a version 
-- 7.0.4 database logger, you must run this file against your existing database
-- to upgrade it. You can use any appropriate database tool to do this, such as
-- "@<filename>" inside SQL*Plus or a graphical tool which can import SQL DDL 
-- files.
-- 
-- Because site-specific requirements may vary greatly, this file only 
-- specifies the basic structures of the tables. Attributes such as 
-- table-spaces, LOB locations, etc are not specified. An experienced database 
-- administrator may wish to modify a copy of this file to define these 
-- performance-related attributes.
-- 
-- This file also assumes a default schema name of "FTELOG". If required, this
-- can be changed by replacing all instances of FTELOG with your preferred
-- schema name (use a text editor with search/replace function). 

-- Changes to MONITOR_EXIT_RESULT table
ALTER TABLE "FTELOG"."MONITOR_EXIT_RESULT" MODIFY("RESULTCODE" CHAR(20));
COMMENT ON COLUMN "FTELOG"."MONITOR_EXIT_RESULT"."RESULTCODE" IS 'The value that the Exit returned, either cancel or proceed.';

-- Changes to SCHEDULE_ACTION table
ALTER TABLE "FTELOG"."SCHEDULE_ACTION" ADD ("ORIGINATOR_MQ_USER" CHAR(12));
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ACTION"."ORIGINATOR_MQ_USER" IS 'The user in whose name the request that caused the change was submitted, as contained in the MQ message descriptor of the request.';

-- Changes to TRANSFER_ITEM table
ALTER TABLE "FTELOG"."TRANSFER_ITEM" ADD ("SOURCE_CORRELATOR_ID" INTEGER);
ALTER TABLE "FTELOG"."TRANSFER_ITEM" ADD ("DESTINATION_CORRELATOR_ID" INTEGER);
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SOURCE_CORRELATOR_ID" IS 'The ID of the correlator information for the source file.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_CORRELATOR_ID" IS 'The ID of the correlator information for the destination file.';
 		
-- Changes to TRANSFER_EVENT table
ALTER TABLE "FTELOG"."TRANSFER_EVENT" ADD ("SOURCE_CD_NODE_ID" INTEGER);
ALTER TABLE "FTELOG"."TRANSFER_EVENT" ADD ("DESTINATION_CD_NODE_ID" INTEGER);
ALTER TABLE "FTELOG"."TRANSFER_EVENT" ADD ("SOURCE_AGENT_TYPE" INTEGER);
ALTER TABLE "FTELOG"."TRANSFER_EVENT" ADD ("DESTINATION_AGENT_TYPE" INTEGER);
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."SOURCE_CD_NODE_ID" IS 'The ID of the source Connect:Direct nodes for this transfer.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."DESTINATION_CD_NODE_ID" IS 'The ID of the destination Connect:Direct nodes for this transfer.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."SOURCE_AGENT_TYPE" IS 'The source agent type. Possible values are: 1=STANDARD, 2=BRIDGE, 3=WEB_GATEWAY, 4=EMBEDDED, 5=CD_BRIDGE, 6=SFG';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."DESTINATION_AGENT_TYPE" IS 'The destination agent type. Possible values are: 1=STANDARD, 2=BRIDGE, 3=WEB_GATEWAY, 4=EMBEDDED, 5=CD_BRIDGE, 6=SFG';


------------------------------------------------
-- DDL Statements for table "FTELOG"."TRANSFER_CD_NODE"
------------------------------------------------		
		
CREATE TABLE "FTELOG"."TRANSFER_CD_NODE"  (
		  "ID" INTEGER NOT NULL, 
		  "PNODE" CHAR(16) NOT NULL,
		  "SNODE" CHAR(16) NOT NULL,
		  "BRIDGE_IS_PNODE" CHAR(1) NOT NULL,
		  CONSTRAINT CD_NODE_ISBOOL CHECK(BRIDGE_IS_PNODE IN ('Y','N')));

CREATE SEQUENCE FTELOG.TRANSFER_CD_NODE_id_SEQ START WITH 1 INCREMENT
BY 1 NOMAXVALUE;

CREATE TRIGGER FTELOG.TRANSFER_CD_NODE_id
BEFORE INSERT ON FTELOG.TRANSFER_CD_NODE FOR EACH ROW
BEGIN
SELECT FTELOG.TRANSFER_CD_NODE_id_SEQ.nextval INTO :new.id FROM dual;
END;
/		

COMMENT ON TABLE "FTELOG"."TRANSFER_CD_NODE" IS 'Each row represents a pairing of PNODE and SNODE used when transferring to or from a Connect:Direct bridge agent.';		 

COMMENT ON COLUMN "FTELOG"."TRANSFER_CD_NODE" . "PNODE" IS 'The name of the PNODE.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_CD_NODE" . "SNODE" IS 'The name of the SNODE.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_CD_NODE" . "BRIDGE_IS_PNODE" IS 'Whether the Connect:Direct bridge agents node matches the PNODE or SNODE in this pairing. Possible values are Y or N.';

ALTER TABLE "FTELOG"."TRANSFER_CD_NODE" 
	ADD CONSTRAINT "TRANSFER_CD_NODE_ID" PRIMARY KEY
		("ID");

		
------------------------------------------------
-- DDL Statements for table "FTELOG"."TRANSFER_CORRELATOR"
------------------------------------------------		
		
CREATE TABLE "FTELOG"."TRANSFER_CORRELATOR"  (
		  "ID" INTEGER NOT NULL, 
		  "CORRELATION_STRING" VARCHAR(256) NOT NULL,
		  "CORRELATION_NUMBER" INT NOT NULL,
		  "CORRELATION_BOOLEAN" CHAR(1) NOT NULL,
		  CONSTRAINT CORREL_ISBOOL CHECK(CORRELATION_BOOLEAN IN ('Y','N')));

CREATE SEQUENCE FTELOG.TRANSFER_CORRELATOR_id_SEQ START WITH 1 INCREMENT
BY 1 NOMAXVALUE;

CREATE TRIGGER FTELOG.TRANSFER_CORRELATOR_id
BEFORE INSERT ON FTELOG.TRANSFER_CORRELATOR FOR EACH ROW
BEGIN
SELECT FTELOG.TRANSFER_CORRELATOR_id_SEQ.nextval INTO :new.id FROM dual;
END;
/		

COMMENT ON TABLE "FTELOG"."TRANSFER_CORRELATOR" IS 'Each row represents a correlation string and number associated with a transfer item.';		 

COMMENT ON COLUMN "FTELOG"."TRANSFER_CORRELATOR" . "CORRELATION_STRING" IS 'A string correlation value.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_CORRELATOR" . "CORRELATION_NUMBER" IS 'A number correlation value.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_CORRELATOR" . "CORRELATION_BOOLEAN" IS 'A boolean correlation value. Possible values are Y or N.';

ALTER TABLE "FTELOG"."TRANSFER_CORRELATOR" 
	ADD CONSTRAINT "TRANSFER_CORRELATOR_ID" PRIMARY KEY
		("ID");
		
		
------------------------------------------------
-- DDL Statements for foreign keys on Tables
------------------------------------------------

-- DDL Statements for foreign keys on Table "FTELOG"."TRANSFER_ITEM"
		
ALTER TABLE "FTELOG"."TRANSFER_ITEM" 
	ADD CONSTRAINT "VALID_SRC_CORREL" FOREIGN KEY
		("SOURCE_CORRELATOR_ID")
	REFERENCES "FTELOG"."TRANSFER_CORRELATOR"
		("ID");

ALTER TABLE "FTELOG"."TRANSFER_ITEM" 
	ADD CONSTRAINT "VALID_DEST_CORREL" FOREIGN KEY
		("DESTINATION_CORRELATOR_ID")
	REFERENCES "FTELOG"."TRANSFER_CORRELATOR"
		("ID");

-- DDL Statements for foreign keys on Table "FTELOG"."TRANSFER_EVENT"
		
ALTER TABLE "FTELOG"."TRANSFER_EVENT" 
	ADD CONSTRAINT "VALID_SRC_CD_NODE" FOREIGN KEY
		("SOURCE_CD_NODE_ID")
	REFERENCES "FTELOG"."TRANSFER_CD_NODE"
		("ID");	

ALTER TABLE "FTELOG"."TRANSFER_EVENT" 
	ADD CONSTRAINT "VALID_DEST_CD_NODE" FOREIGN KEY
		("DESTINATION_CD_NODE_ID")
	REFERENCES "FTELOG"."TRANSFER_CD_NODE"
		("ID");	

		