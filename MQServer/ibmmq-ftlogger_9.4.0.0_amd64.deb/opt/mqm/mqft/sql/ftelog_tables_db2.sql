-- ===============================================================
-- @start_non_restricted_prolog@
-- Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.databaseloader/sql/ftelog_tables_db2.sql
-- 
-- <copyright
-- notice="lm-source-program"
-- pids="5724-H72"
-- years="2015,2019"
-- crc="3374478728" >
-- Licensed Materials - Property of IBM  
--
-- 5724-H72 
-- 
-- (C) Copyright IBM Corp. 2015, 2019  All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with    
-- IBM Corp. 
-- </copyright>
-- 
-- @end_non_restricted_prolog@
-- ===============================================================
-- 
-- SQL schema file for IBM MQ Managed File Transfer Database Logger (DB2)
-- -------------------------------------------------
-- 
-- This file contains SQL Data Definition Language statements that define the
-- table structure used by the WMQFTE database logger component. Before 
-- running the database logger, you must import these structures into your
-- database. You can use any appropriate database tool to do this, such as 
-- "db2 -t -f <filename>" or the DB2 graphical Control Center.
-- 
-- Because site-specific requirements may vary greatly, this file only 
-- specifies the basic structures of the tables. Attributes such as 
-- table-spaces, LOB locations, etc are not specified. An experienced database 
-- administrator may wish to modify a copy of this file to define these 
-- performance-related attributes.
-- 
-- This file also assumes a default schema name of "FTELOG". If required, this
-- can be changed by replacing all instances of FTELOG with your preferred
-- schema name (use a text editor with search/replace function). 

------------------------------------------------
-- DDL Statements for Schemas
------------------------------------------------

CREATE SCHEMA "FTELOG";

COMMENT ON SCHEMA "FTELOG" IS 'Persisted log information from IBM MQ Managed File Transfer';

CREATE SCHEMA "FTEVIEW ";

COMMENT ON SCHEMA "FTEVIEW " IS 'Views providing access to FTE log data';


------------------------------------------------
-- DDL Statements for table "FTELOG"."SCHEDULE_ACTION"
------------------------------------------------

CREATE TABLE "FTELOG"."SCHEDULE_ACTION"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "SCHEDULE_ID" BIGINT NOT NULL , 
		  "ACTION_TYPE" CHAR(16) NOT NULL , 
		  "SPEC_AFTERWARDS" BIGINT , 
		  "TIME" TIMESTAMP NOT NULL , 
		  "ORIGINATOR_HOST" VARCHAR(1004) NOT NULL , 
		  "ORIGINATOR_USER" VARCHAR(256) NOT NULL ,
		  "ORIGINATOR_MQ_USER" CHAR(12) ,
		  "STATUS_CODE" BIGINT NOT NULL , 
		  "STATUS_TEXT" VARCHAR(2000) )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."SCHEDULE_ACTION" IS 'Whenever an event occurs which modifies the schedule state, an action is recorded.';

COMMENT ON COLUMN "FTELOG"."SCHEDULE_ACTION"."ACTION_TYPE" IS 'The action that occurred';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ACTION"."ID" IS 'Row ID';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ACTION"."ORIGINATOR_HOST" IS 'The machine from which the request that caused the change was submitted.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ACTION"."ORIGINATOR_USER" IS 'The user in whose name the request that caused the change was submitted.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ACTION"."ORIGINATOR_MQ_USER" IS 'The user in whose name the request that caused the change was submitted, as contained in the MQ message descriptor of the request.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ACTION"."SCHEDULE_ID" IS 'The schedule to which this action applies';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ACTION"."SPEC_AFTERWARDS" IS 'The schedule_spec that represents the state of this schedule after the action occurred.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ACTION"."STATUS_CODE" IS 'A numeric return code describing the outcome of the action';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ACTION"."STATUS_TEXT" IS 'A text description of the outcome of the action. Usually null if the action succeeded.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ACTION"."TIME" IS 'The point in time that the action occurred';

ALTER TABLE "FTELOG"."SCHEDULE_ACTION" 
	ADD CONSTRAINT "SCHEDULE_ACTION_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."TRANSFER_ITEM"
------------------------------------------------

CREATE TABLE "FTELOG"."TRANSFER_ITEM"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "TRANSFER_ID" CHAR(48) NOT NULL , 
		  "FILE_MODE" CHAR(16) NOT NULL , 
		  "SOURCE_FILENAME" VARCHAR(2000) , 
		  "SOURCE_LINEEND" CHAR(4) , 
		  "SOURCE_ENCODING" CHAR(16) , 
		  "SOURCE_CHECKSUM_METHOD" CHAR(32), 
		  "SOURCE_CHECKSUM_VALUE" VARCHAR(2000) , 
		  "SOURCE_DISPOSITION" CHAR(32) NOT NULL , 
		  "SOURCE_FILE_SIZE" BIGINT, 
		  "SOURCE_LAST_MODIFIED" TIMESTAMP,
		  "SOURCE_MESSAGE_QUEUE_NAME" CHAR(128),
		  "SOURCE_MESSAGE_GROUP_ID" CHAR(48),
		  "SOURCE_MESSAGE_COUNT" INTEGER,
		  "SOURCE_CORRELATOR_ID" BIGINT,
		  "DESTINATION_FILENAME" VARCHAR(2000), 
		  "DESTINATION_LINEEND" CHAR(4) , 
		  "DESTINATION_ENCODING" CHAR(16) ,
		  "DESTINATION_CHECKSUM_METHOD" CHAR(32) , 
		  "DESTINATION_CHECKSUM_VALUE" VARCHAR(2000) , 
		  "DESTINATION_EXISTS_ACTION" CHAR(32), 
		  "DESTINATION_FILE_SIZE" BIGINT, 
		  "DESTINATION_LAST_MODIFIED" TIMESTAMP,
		  "DESTINATION_MESSAGE_QUEUE_NAME" CHAR(128),
		  "DESTINATION_MESSAGE_MESSAGE_ID" CHAR(48),
		  "DESTINATION_MESSAGE_GROUP_ID" CHAR(48),
		  "DESTINATION_MESSAGE_COUNT" INTEGER,
		  "DESTINATION_MESSAGE_LENGTH" BIGINT,
		  "DESTINATION_CORRELATOR_ID" BIGINT,
		  "RESULTCODE" SMALLINT NOT NULL , 
		  "RESULT_TEXT" VARCHAR(2000),
		  "SEQUENCE" SMALLINT,
		  "TRUNCATE_RECORDS" CHAR(1) DEFAULT 'N' NOT NULL,
		  CONSTRAINT ISBOOL CHECK(TRUNCATE_RECORDS IN ('Y','N')))   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."TRANSFER_ITEM" IS 'Each row represents a file that is sent as part of the transfer.';

COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_CHECKSUM_METHOD" IS 'The algorithm used to calculate a checksum of the destination file. May be null if no checksum was calculated because the transfer did not complete successfully.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_CHECKSUM_VALUE" IS 'The checksum value of the destination file. May be null if checksumming was disabled.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_ENCODING" IS 'The character encoding used on the destination file, if it is transferred as text';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_EXISTS_ACTION" IS 'The action to perform if the destination file already exists';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_FILENAME" IS 'The file or dataset name to use at the destination.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_LINEEND" IS 'The line-end format used in the destination file, if it is transferred as text';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_MESSAGE_QUEUE_NAME" IS 'The destination queue for the message(s) produced from the source file.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_MESSAGE_MESSAGE_ID" IS 'The message ID of the message produced from the source file. May be null if the transfer resulted in multiple messages.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_MESSAGE_GROUP_ID" IS 'The group ID of the message(s) produced from the source file. May be null if the transfer resulted in only a single message.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_MESSAGE_COUNT" IS 'The number of messages that the source file was split into.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_MESSAGE_LENGTH" IS 'The length of the message produced from the source file.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."DESTINATION_CORRELATOR_ID" IS 'The ID of the correlator information for the destination file.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."FILE_MODE" IS 'The file transfer mode, eg text or binary';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."ID" IS 'Row ID';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."RESULTCODE" IS 'A numeric code indicating the outcome of the transfer of this item.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."RESULT_TEXT" IS 'A textual explanation of the result of the transfer. Usually null if the transfer was successful.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SOURCE_CHECKSUM_METHOD" IS 'The algorithm used to calculate a checksum of the source file';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SOURCE_CHECKSUM_VALUE" IS 'The checksum value of the source file. May be null if checksumming was disabled.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SOURCE_DISPOSITION" IS 'The action to perform on the source file when the transfer is complete.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SOURCE_ENCODING" IS 'The character encoding used on the source file, if it is transferred as text';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SOURCE_FILENAME" IS 'The source file or dataset name.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SOURCE_LINEEND" IS 'The line-end format used in the source file, if it is transferred as text';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SOURCE_MESSAGE_QUEUE_NAME" IS 'The source queue for the message(s) to be included in the destination file.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SOURCE_MESSAGE_GROUP_ID" IS 'The group ID of the message(s) to be included in the destination file.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SOURCE_MESSAGE_COUNT" IS 'The number of messages to be included in the destination file.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SOURCE_CORRELATOR_ID" IS 'The ID of the correlator information for the source file.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."TRANSFER_ID" IS 'The transfer that this item is part of';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."SEQUENCE" IS 'The sequence number within the transfer of this transfer item.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM"."TRUNCATE_RECORDS" IS 'Indicates whether over length data set records are to be truncated or wrapped.';

ALTER TABLE "FTELOG"."TRANSFER_ITEM" 
	ADD CONSTRAINT "TRANSFER_ITEM_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."SCHEDULE_SPEC"
------------------------------------------------

CREATE TABLE "FTELOG"."SCHEDULE_SPEC"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "START_TIMEBASE" CHAR(16) NOT NULL , 
		  "START_TIMEZONE" CHAR(64) NOT NULL , 
		  "START_TIME" TIMESTAMP NOT NULL , 
		  "REPEAT_INTERVAL" CHAR(16) , 
		  "REPEAT_FREQUENCY" INTEGER , 
		  "REPEAT_COUNT" INTEGER , 
		  "SOURCE_AGENT" CHAR(29) NOT NULL , 
		  "SOURCE_QM" CHAR(48) NOT NULL , 
		  "DESTINATION_AGENT" CHAR(29) NOT NULL , 
		  "DESTINATION_QM" CHAR(48) NOT NULL )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."SCHEDULE_SPEC" IS 'The details of an individual scheduled transfer';

COMMENT ON COLUMN "FTELOG"."SCHEDULE_SPEC"."DESTINATION_AGENT" IS 'The agent to which the files should be transferred.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_SPEC"."DESTINATION_QM" IS 'The queue manager used by the destination agent.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_SPEC"."REPEAT_COUNT" IS 'If the schedule repeats and is bound by the number of occurrences rather than an end time, how many times to repeat.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_SPEC"."REPEAT_FREQUENCY" IS 'How many repeat_intervals there are between scheduled transfers.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_SPEC"."REPEAT_INTERVAL" IS 'If the transfer repeats, what interval to repeat at (minutes, weeks, etc).';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_SPEC"."SOURCE_AGENT" IS 'The agent from which the files will be transferred.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_SPEC"."SOURCE_QM" IS 'The queue manager used by the source agent.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_SPEC"."START_TIME" IS 'The time at which the first transfer in the schedule will take place.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_SPEC"."START_TIMEBASE" IS 'The time basis for the transfer''s times, for example whether to operate from the agent''s timezone or the administrator''s timezone.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_SPEC"."START_TIMEZONE" IS 'The timezone to which the timebase corresponds and which will be used in operating the schedule.';


ALTER TABLE "FTELOG"."SCHEDULE_SPEC" 
	ADD CONSTRAINT "SCHEDULESPEC_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."SCHEDULE_ITEM"
------------------------------------------------

CREATE TABLE "FTELOG"."SCHEDULE_ITEM"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "SCHEDULE_SPEC_ID" BIGINT NOT NULL , 
		  "SOURCE_FILENAME" VARCHAR(2000) , 
		  "FILE_MODE" CHAR(16) NOT NULL , 
		  "CHECKSUM_METHOD" CHAR(32) NOT NULL , 
		  "RECURSIVE" CHAR(1) , 
		  "SOURCE_DISPOSITION" CHAR(32) , 
		  "DESTINATION_FILENAME" VARCHAR(2000) , 
		  "DESTINATION_TYPE" CHAR(16) NOT NULL , 
		  "DESTINATION_EXISTS_ACTION" CHAR(32) ,
          "SOURCE_QUEUE" VARCHAR(256),
          "DESTINATION_QUEUE" VARCHAR(256) )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."SCHEDULE_ITEM" IS 'Each file (or pattern to match at transfer time) is represented by a schedule_item.';

COMMENT ON COLUMN "FTELOG"."SCHEDULE_ITEM"."CHECKSUM_METHOD" IS 'How the checksum for the file should be calculated';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ITEM"."DESTINATION_EXISTS_ACTION" IS 'What action the destination agent should take if the file''s destination already exists.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ITEM"."DESTINATION_FILENAME" IS 'The file or directory into which the files are transferred';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ITEM"."DESTINATION_TYPE" IS 'Whether the destination_filename column refers to a file or a directory (or dataset)';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ITEM"."FILE_MODE" IS 'The mode (eg text or binary) in which the file should be transferred.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ITEM"."RECURSIVE" IS 'Whether, when it creates the transfer according to the schedule, the agent should recurse (''Y'') or not (''N'') the source directory.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ITEM"."SCHEDULE_SPEC_ID" IS 'The schedule_spec with which this item is associated';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ITEM"."SOURCE_DISPOSITION" IS 'What action to perform upon source files once the transfer completes';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ITEM"."SOURCE_FILENAME" IS 'The source file or directory name or pattern.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ITEM"."SOURCE_QUEUE" IS 'The source queue name for a message to file transfer';
COMMENT ON COLUMN "FTELOG"."SCHEDULE_ITEM"."DESTINATION_QUEUE" IS 'The destination queue name for a file to message transfer';

ALTER TABLE "FTELOG"."SCHEDULE_ITEM" 
	ADD CONSTRAINT "SCHEDULE_ITEM_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."SCHEDULE"
------------------------------------------------

CREATE TABLE "FTELOG"."SCHEDULE"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "AGENT" CHAR(29) NOT NULL , 
		  "ID_ON_AGENT" BIGINT NOT NULL , 
		  "CREATION_DATE" TIMESTAMP NOT NULL , 
		  "LATEST_ACTION" BIGINT )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."SCHEDULE" IS 'A transfer schedule registered with an agent.';

COMMENT ON COLUMN "FTELOG"."SCHEDULE"."AGENT" IS 'The name of the agent that has this schedule';
COMMENT ON COLUMN "FTELOG"."SCHEDULE"."CREATION_DATE" IS 'The point in time at which this schedule was created.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE"."ID" IS 'The unique database (not agent) ID for the schedule';
COMMENT ON COLUMN "FTELOG"."SCHEDULE"."ID_ON_AGENT" IS 'The ID that the agent uses for this ID. This is not unique across agents, and might not even be unique within an agent if its persistent state gets reset.';
COMMENT ON COLUMN "FTELOG"."SCHEDULE"."LATEST_ACTION" IS 'The most recent action that modified the state of this schedule.';

ALTER TABLE "FTELOG"."SCHEDULE" 
	ADD CONSTRAINT "SCHEDULE_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."TRANSFER_EVENT"
------------------------------------------------

CREATE TABLE "FTELOG"."TRANSFER_EVENT"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "ACTION_TIME" TIMESTAMP NOT NULL , 
		  "SOURCE_AGENT" CHAR(29) , 
		  "SOURCE_QM" CHAR(48) , 
		  "SOURCE_BRIDGE_URL" VARCHAR(2083) ,
		  "SOURCE_ARCHITECTURE" CHAR(32) , 
		  "SOURCE_OS_NAME" CHAR(64) , 
		  "SOURCE_OS_VERSION" VARCHAR(256) ,
		  "SOURCE_WEB_GATEWAY" CHAR(28) ,
		  "SOURCE_CD_NODE_ID" BIGINT ,
		  "SOURCE_AGENT_TYPE" INTEGER ,
		  "DESTINATION_AGENT" CHAR(29) , 
		  "DESTINATION_QM" CHAR(48) ,
		  "DESTINATION_BRIDGE_URL" VARCHAR(2083) ,
		  "DESTINATION_WEB_GATEWAY" CHAR(28) ,
		  "DESTINATION_CD_NODE_ID" BIGINT ,
		  "DESTINATION_AGENT_TYPE" INTEGER ,
		  "ORIGINATOR_HOST" VARCHAR(1004) NOT NULL , 
		  "ORIGINATOR_USER" VARCHAR(256) NOT NULL , 
		  "ORIGINATOR_MQ_USER" CHAR(12) ,
		  "ORIGINATOR_WEB_USER" VARCHAR(256) ,
		  "TRANSFERSET_TIME" TIMESTAMP NOT NULL , 
		  "TRANSFERSET_SIZE" INTEGER NOT NULL , 
		  "TRIGGER_LOG" CHAR(16) )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."TRANSFER_EVENT" IS 'An event (start/end) related to a transfer';

COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."ACTION_TIME" IS 'The time that the transfer action took place.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."SOURCE_AGENT" IS 'The name of the agent from which the files are transferred.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."SOURCE_QM" IS 'The queue manager used by the source agent.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."SOURCE_BRIDGE_URL" IS 'If the source agent is a bridge agent, the URL of the data source to which it forms a bridge.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."SOURCE_ARCHITECTURE" IS 'The machine architecture of the system hosting the the source agent.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."SOURCE_OS_NAME" IS 'The operating system of the source agent machine.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."SOURCE_OS_VERSION" IS 'The version of operating system of the source agent machine.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."SOURCE_WEB_GATEWAY" IS 'The name of the web gateway from which the files are transferred.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."SOURCE_CD_NODE_ID" IS 'The ID of the source Connect:Direct node for this transfer.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."SOURCE_AGENT_TYPE" IS 'The source agent type. Possible values are: 1=STANDARD, 2=BRIDGE, 3=WEB_GATEWAY, 4=EMBEDDED, 5=CD_BRIDGE, 6=SFG';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."DESTINATION_AGENT" IS 'The name of the agent to which the files are transferred.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."DESTINATION_QM" IS 'The queue manager used by the destination agent.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."DESTINATION_BRIDGE_URL" IS 'If the destination agent is a bridge agent, the URL of the data source to which it forms a bridge.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."DESTINATION_WEB_GATEWAY" IS 'The name of the web gateway to which the files are transferred.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."DESTINATION_CD_NODE_ID" IS 'The ID of the destination Connect:Direct node for this transfer.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."DESTINATION_AGENT_TYPE" IS 'The destination agent type. Possible values are: 1=STANDARD, 2=BRIDGE, 3=WEB_GATEWAY, 4=EMBEDDED, 5=CD_BRIDGE, 6=SFG';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."ORIGINATOR_HOST" IS 'The hostname of the machine from which the transfer request was submitted.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."ORIGINATOR_USER" IS 'The name of the user who submitted the transfer request, as reported by the fteCreateTransfer command.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."ORIGINATOR_MQ_USER" IS 'The name of the user who submitted the transfer request, as contained in the MQ message descriptor of the request.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."ORIGINATOR_WEB_USER" IS 'The name of the web user who submitted the request.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."TRANSFERSET_TIME" IS 'The time at which the transferset was created.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."TRANSFERSET_SIZE" IS 'The number of items being transferred.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EVENT"."TRIGGER_LOG" IS 'For transfer definitions involving a trigger, whether to log trigger evaluations that did not result in a transfer.';

ALTER TABLE "FTELOG"."TRANSFER_EVENT" 
	ADD CONSTRAINT "TRANSFER_EVENT_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."TRIGGER_CONDITION"
------------------------------------------------

CREATE TABLE "FTELOG"."TRIGGER_CONDITION"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "TRANSFER_EVENT_ID" BIGINT NOT NULL , 
		  "CONDITION_TYPE" CHAR(16) NOT NULL , 
		  "COMPARISON" CHAR(8) NOT NULL , 
		  "VALUE" CHAR(32) NOT NULL , 
		  "FILENAME" VARCHAR(2000) NOT NULL )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."TRIGGER_CONDITION" IS 'One condition (for example, ''file foo exists'') in a basic FTE conditional transfer';

ALTER TABLE "FTELOG"."TRIGGER_CONDITION" 
	ADD CONSTRAINT "TRIG_CONDITION_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."METADATA"
------------------------------------------------

CREATE TABLE "FTELOG"."METADATA"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "TRANSFER_EVENT_ID" BIGINT , 
		  "STANDALONE_CALL_ID" CHAR(48) , 
		  "KEY" VARCHAR(256) NOT NULL , 
		  "VALUE" CLOB(1048576) LOGGED NOT COMPACT )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."METADATA" IS 'Metadata associated with a transfer';

ALTER TABLE "FTELOG"."METADATA" 
	ADD CONSTRAINT "METADATA_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."CALL_ARGUMENT"
------------------------------------------------

CREATE TABLE "FTELOG"."CALL_ARGUMENT"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) ,
		  "CALL_ID" BIGINT NOT NULL , 
		  "TYPE" CHAR(16) NOT NULL , 
		  "KEY" VARCHAR(256) , 
		  "VALUE" VARCHAR(2000) NOT NULL )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."CALL_ARGUMENT" IS 'An argument or parameter supplied to a command that is called.';

COMMENT ON COLUMN "FTELOG"."CALL_ARGUMENT"."CALL_ID" IS 'The call with which the argument is associated';
COMMENT ON COLUMN "FTELOG"."CALL_ARGUMENT"."KEY" IS 'Where the argument is of a key-value-pair kind, the key or name.';
COMMENT ON COLUMN "FTELOG"."CALL_ARGUMENT"."TYPE" IS 'The kind of argument - some are position parameters to OS commands, others are named properties used with Ant.';
COMMENT ON COLUMN "FTELOG"."CALL_ARGUMENT"."VALUE" IS 'The value of the argument';

ALTER TABLE "FTELOG"."CALL_ARGUMENT" 
	ADD CONSTRAINT "CALL_ARG_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."TRANSFER_CALLS"
------------------------------------------------

CREATE TABLE "FTELOG"."TRANSFER_CALLS"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) ,
		  "TRANSFER_ID" CHAR(48) NOT NULL , 
		  "PRE_SOURCE_CALL" BIGINT , 
		  "PRE_DESTINATION_CALL" BIGINT , 
		  "POST_SOURCE_CALL" BIGINT , 
		  "POST_DESTINATION_CALL" BIGINT )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."TRANSFER_CALLS" IS 'Links executable command calls to transfers';

COMMENT ON COLUMN "FTELOG"."TRANSFER_CALLS"."POST_DESTINATION_CALL" IS 'The call made at the destination once the transfer is complete';
COMMENT ON COLUMN "FTELOG"."TRANSFER_CALLS"."POST_SOURCE_CALL" IS 'The call made at the source agent once the transfer is complete';
COMMENT ON COLUMN "FTELOG"."TRANSFER_CALLS"."PRE_DESTINATION_CALL" IS 'The call made at the destination agent before the transfer commences';
COMMENT ON COLUMN "FTELOG"."TRANSFER_CALLS"."PRE_SOURCE_CALL" IS 'The call made at the source agent before the transfer commences';
COMMENT ON COLUMN "FTELOG"."TRANSFER_CALLS"."TRANSFER_ID" IS 'The transfer with which the calls in this row are associated';

ALTER TABLE "FTELOG"."TRANSFER_CALLS" 
	ADD CONSTRAINT "XFR_CALL_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."CALL"
------------------------------------------------

CREATE TABLE "FTELOG"."CALL"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "COMMAND" VARCHAR(80) , 
		  "TYPE" CHAR(16) , 
		  "RETRIES" INTEGER WITH DEFAULT 0 , 
		  "RETRY_WAIT" INTEGER WITH DEFAULT 0 , 
		  "SUCCESS_RC" INTEGER WITH DEFAULT 0 , 
		  "EXECUTED_COMMAND" VARCHAR(2000) , 
		  "CAPPED_RETRIES" INTEGER WITH DEFAULT 0 , 
		  "CAPPED_RETRY_WAIT" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "OUTCOME" CHAR(16) ,
		  "PRIORITY" INTEGER WITH DEFAULT 0 ,
		  "MESSAGE" VARCHAR(46) )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."CALL" IS 'The FTE-managed remote execution of an operating system command, Ant script, zOS JCL job or 4690 background application. Calls may be embedded in transfers, or referred to by call_request rows.';
COMMENT ON COLUMN "FTELOG"."CALL"."COMMAND" IS 'The command, Ant script, zOS JCL job or 4690 background application being executed.';
COMMENT ON COLUMN "FTELOG"."CALL"."TYPE" IS 'The type of the call. Possible values: executable, antscript, jcl or os4690background.';
COMMENT ON COLUMN "FTELOG"."CALL"."RETRIES" IS 'The number of retries that were requested.';
COMMENT ON COLUMN "FTELOG"."CALL"."RETRY_WAIT" IS 'The interval to wait between retries as originally requested, in seconds.';
COMMENT ON COLUMN "FTELOG"."CALL"."SUCCESS_RC" IS 'The return code that indicates a successful completion of the command. If any other code is received, the run is reported to have failed. When type is os4690background this value is ignored.';
COMMENT ON COLUMN "FTELOG"."CALL"."EXECUTED_COMMAND" IS 'The full name of the command that was run, including path.';
COMMENT ON COLUMN "FTELOG"."CALL"."CAPPED_RETRIES" IS 'The number of retries available; this number might be less than requested if the retry limit of the agent is lower than the number of retries requested.';
COMMENT ON COLUMN "FTELOG"."CALL"."CAPPED_RETRY_WAIT" IS 'The interval between retries that is used; this number might be less than requested if the configured limit of the agent is lower than the retry wait requested.';
COMMENT ON COLUMN "FTELOG"."CALL"."OUTCOME" IS 'Whether the call was successful overall. If there were multiple tries the outcome of each one is recorded separately in the CALL_RESULT table.';
COMMENT ON COLUMN "FTELOG"."CALL"."PRIORITY" IS 'The application priority used to launch the background application when the type for this call is os4690background.';
COMMENT ON COLUMN "FTELOG"."CALL"."MESSAGE" IS 'The initial status message for the background application when the type for this call is os4690background. NULL if the type is not os4690background.';

ALTER TABLE "FTELOG"."CALL" 
	ADD CONSTRAINT "CALL_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."CALL_REQUEST"
------------------------------------------------

CREATE TABLE "FTELOG"."CALL_REQUEST"  (
		  "ID" CHAR(48) NOT NULL , 
		  "CALL_ID" BIGINT NOT NULL , 
		  "ACTION_TIME" TIMESTAMP NOT NULL , 
		  "AGENT" CHAR(29) NOT NULL , 
		  "AGENT_QM" CHAR(48) NOT NULL , 
		  "ARCHITECTURE" CHAR(32) NOT NULL , 
		  "OS_NAME" CHAR(64) NOT NULL , 
		  "OS_VERSION" VARCHAR(256) NOT NULL , 
		  "ORIGINATOR_HOST" VARCHAR(1004) NOT NULL , 
		  "ORIGINATOR_USER" VARCHAR(256) NOT NULL , 
		  "ORIGINATOR_MQ_USER" CHAR(12) NOT NULL , 
		  "JOB_NAME" VARCHAR(256) , 
		  "RESULTCODE" INTEGER , 
		  "RESULTTEXT" VARCHAR(2000) )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."CALL_REQUEST" IS 'The vehicle for a command call that is not part of a file transfer.';

ALTER TABLE "FTELOG"."CALL_REQUEST" 
	ADD CONSTRAINT "CALL_REQUEST_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."TRANSFER"
------------------------------------------------

CREATE TABLE "FTELOG"."TRANSFER"  (
		  "TRANSFER_ID" CHAR(48) NOT NULL , 
		  "JOB_NAME" VARCHAR(256) , 
		  "SCHEDULE_ID" BIGINT , 
		  "START_ID" BIGINT , 
		  "COMPLETE_ID" BIGINT , 
		  "RESULTCODE" INTEGER , 
		  "RESULTTEXT" VARCHAR(2000),
		  "BYTES_TRANSFERRED" BIGINT,
		  "STATUS" CHAR(20),
		  "RELATED_TRANSFER_ID" CHAR(48))   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."TRANSFER" IS 'A single transfer of one or more files';

COMMENT ON COLUMN "FTELOG"."TRANSFER"."TRANSFER_ID" IS 'The hexadecimal ID for the transfer';
COMMENT ON COLUMN "FTELOG"."TRANSFER"."STATUS" IS 'The status of a transfer (started, success, partial success, failure, cancelled)';
COMMENT ON COLUMN "FTELOG"."TRANSFER"."RELATED_TRANSFER_ID" IS 'A previous transfer related to this specific transfer e.g. A Web Gateway download transfer will refer to the upload transfer for the file that is downloaded.';

ALTER TABLE "FTELOG"."TRANSFER" 
	ADD CONSTRAINT "TRANSFER_ID_KEY" PRIMARY KEY
		("TRANSFER_ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."CALL_RESULT"
------------------------------------------------

CREATE TABLE "FTELOG"."CALL_RESULT"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "CALL_ID" BIGINT NOT NULL , 
		  "SEQUENCE" INTEGER NOT NULL , 
		  "OUTCOME" CHAR(16) NOT NULL , 
		  "RETURN_CODE" INTEGER , 
		  "TIME" TIMESTAMP NOT NULL , 
		  "STDOUT" CLOB(10485760) LOGGED COMPACT , 
		  "STDERR" CLOB(10485760) LOGGED COMPACT , 
		  "ERROR" VARCHAR(2000) )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."CALL_RESULT" IS 'The detailed result of calling a command. A call may have multiple results if retries were enabled.';

ALTER TABLE "FTELOG"."CALL_RESULT" 
	ADD CONSTRAINT "CALL_RESULT_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."MONITOR_METADATA"
------------------------------------------------

CREATE TABLE "FTELOG"."MONITOR_METADATA"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "ACTION_ID" BIGINT NOT NULL , 
		  "PHASE" CHAR(16) NOT NULL , 
		  "KEY" VARCHAR(256) NOT NULL , 
		  "VALUE" VARCHAR(2000) )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."MONITOR_METADATA" IS 'Items of metadata associated with a resource monitor';

COMMENT ON COLUMN "FTELOG"."MONITOR_METADATA"."ACTION_ID" IS 'The monitor_action with which the metadata is associated';
COMMENT ON COLUMN "FTELOG"."MONITOR_METADATA"."KEY" IS 'The name of the metadata item';
COMMENT ON COLUMN "FTELOG"."MONITOR_METADATA"."PHASE" IS 'Whether this metadata item represents the originally-submitted data or the updated version after variable substitution';
COMMENT ON COLUMN "FTELOG"."MONITOR_METADATA"."VALUE" IS 'The value of the metadata item.';

ALTER TABLE "FTELOG"."MONITOR_METADATA" 
	ADD CONSTRAINT "MON_METADATA_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."MONITOR_EXIT_RESULT"
------------------------------------------------

CREATE TABLE "FTELOG"."MONITOR_EXIT_RESULT"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "ACTION_ID" BIGINT NOT NULL , 
		  "EXIT_NAME" VARCHAR(256) NOT NULL , 
		  "RESULTCODE" CHAR(20) NOT NULL , 
		  "RESULTTEXT" VARCHAR(2000) )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."MONITOR_EXIT_RESULT" IS 'The result of running a resource monitor exit';

COMMENT ON COLUMN "FTELOG"."MONITOR_EXIT_RESULT"."ACTION_ID" IS 'The monitor action with which the result is associated';
COMMENT ON COLUMN "FTELOG"."MONITOR_EXIT_RESULT"."EXIT_NAME" IS 'The name of the exit that produced this result';
COMMENT ON COLUMN "FTELOG"."MONITOR_EXIT_RESULT"."RESULTCODE" IS 'The value that the Exit returned, either cancel or proceed.';
COMMENT ON COLUMN "FTELOG"."MONITOR_EXIT_RESULT"."RESULTTEXT" IS 'The text output from the exit, if provided';

ALTER TABLE "FTELOG"."MONITOR_EXIT_RESULT" 
	ADD CONSTRAINT "MON_EXIT_RESULT_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."MONITOR"
------------------------------------------------

CREATE TABLE "FTELOG"."MONITOR"  (
		  "ID" CHAR(48) NOT NULL , 
		  "NAME" VARCHAR(256) NOT NULL , 
		  "AGENT" CHAR(29) NOT NULL , 
		  "QMGR" CHAR(48) NOT NULL )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."MONITOR" IS 'Resource monitors that trigger FTE operations based on external conditions';

COMMENT ON COLUMN "FTELOG"."MONITOR"."AGENT" IS 'The agent on which the monitor runs';
COMMENT ON COLUMN "FTELOG"."MONITOR"."ID" IS 'The hexadecimal ID of the monitor';
COMMENT ON COLUMN "FTELOG"."MONITOR"."NAME" IS 'The name of the monitor';
COMMENT ON COLUMN "FTELOG"."MONITOR"."QMGR" IS 'The queue manager of the agent where the monitor runs';

ALTER TABLE "FTELOG"."MONITOR" 
	ADD CONSTRAINT "MONITOR_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."MONITOR_ACTION"
------------------------------------------------

CREATE TABLE "FTELOG"."MONITOR_ACTION"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "ACTION" CHAR(32) NOT NULL , 
		  "MONITOR" CHAR(48) , 
		  "TIME" TIMESTAMP NOT NULL , 
		  "ORIGINATOR_HOST" VARCHAR(1004) , 
		  "ORIGINATOR_USER" VARCHAR(256) , 
		  "ORIGINATOR_MQ_USER" CHAR(12) , 
		  "ORIGINAL_XML_REQUEST" VARCHAR(2000) , 
		  "UPDATED_XML_REQUEST" VARCHAR(2000) , 
		  "JOB_NAME" VARCHAR(256) )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."MONITOR_ACTION" IS 'Each row represents an action (creation, triggering, etc) occurring in respect of a monitor';

COMMENT ON COLUMN "FTELOG"."MONITOR_ACTION"."ACTION" IS 'The type of action that took place';
COMMENT ON COLUMN "FTELOG"."MONITOR_ACTION"."JOB_NAME" IS 'The name of the submitted job, where applicable.';
COMMENT ON COLUMN "FTELOG"."MONITOR_ACTION"."MONITOR" IS 'The monitor on which this action occurred. May be null if the action failed because it was requested for a monitor that does not exist.';
COMMENT ON COLUMN "FTELOG"."MONITOR_ACTION"."ORIGINAL_XML_REQUEST" IS 'If this was a create or triggersatisfied action, the xml request that should be initiated when the monitor is triggered.';
COMMENT ON COLUMN "FTELOG"."MONITOR_ACTION"."ORIGINATOR_HOST" IS 'The machine from which the request to perform the action was submitted';
COMMENT ON COLUMN "FTELOG"."MONITOR_ACTION"."ORIGINATOR_MQ_USER" IS 'The userid contained in the MQ message that initiated the action';
COMMENT ON COLUMN "FTELOG"."MONITOR_ACTION"."ORIGINATOR_USER" IS 'The username that submitted the request to perform the action';
COMMENT ON COLUMN "FTELOG"."MONITOR_ACTION"."TIME" IS 'The time at which the action occurred';
COMMENT ON COLUMN "FTELOG"."MONITOR_ACTION"."UPDATED_XML_REQUEST" IS 'If the action is triggerSatisfied, the XML request that was actually initiated. This might vary from the originally-requested one due to variable substitution.';

ALTER TABLE "FTELOG"."MONITOR_ACTION" 
	ADD CONSTRAINT "MONITOR_ACTION_ID" PRIMARY KEY
		("ID");
		

------------------------------------------------
-- DDL Statements for table "FTELOG"."AUTH_EVENT"
------------------------------------------------

CREATE TABLE "FTELOG"."AUTH_EVENT"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "ACTION" CHAR(32) NOT NULL , 
		  "COMMAND_ID" CHAR(48) NOT NULL , 
		  "TIME" TIMESTAMP NOT NULL ,
		  "ORIGINATOR_MQ_USER" CHAR(12) NOT NULL , 
		  "AUTHORITY" CHAR(64) NOT NULL ,
		  "ORIGINAL_XML_REQUEST" VARCHAR(2000) , 
		  "RESULTCODE" SMALLINT NOT NULL ,
		  "RESULT_TEXT" VARCHAR(2000)) 
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."AUTH_EVENT" IS 'Each row represents an authority-related event, typically the rejection of a request due to insufficient privileges.';

COMMENT ON COLUMN "FTELOG"."AUTH_EVENT"."ACTION" IS 'The type of event that took place';
COMMENT ON COLUMN "FTELOG"."AUTH_EVENT"."COMMAND_ID" IS 'The MQ message ID of the original message that triggered the event. In the case of a transfer request, this will also be the transfer ID.';
COMMENT ON COLUMN "FTELOG"."AUTH_EVENT"."TIME" IS 'The time at which the event occurred';
COMMENT ON COLUMN "FTELOG"."AUTH_EVENT"."ORIGINATOR_MQ_USER" IS 'The MQ user ID of the command message, against which the authority check was performed.';
COMMENT ON COLUMN "FTELOG"."AUTH_EVENT"."AUTHORITY" IS 'The authority that was required for the requested action.';
COMMENT ON COLUMN "FTELOG"."AUTH_EVENT"."ORIGINAL_XML_REQUEST" IS 'The payload of the command message, indicating precisely what action was refused.';
COMMENT ON COLUMN "FTELOG"."AUTH_EVENT"."RESULTCODE" IS 'The numeric code identifying the result';
COMMENT ON COLUMN "FTELOG"."AUTH_EVENT"."RESULT_TEXT" IS 'A text message explaining the authority event.';

ALTER TABLE "FTELOG"."AUTH_EVENT" 
	ADD CONSTRAINT "AUTH_EVENT_ID" PRIMARY KEY
		("ID");

		
------------------------------------------------
-- DDL Statements for table "FTELOG"."TRANSFER_STATS"
------------------------------------------------
 
CREATE TABLE "FTELOG"."TRANSFER_STATS"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "TRANSFER_ID" CHAR(48) NOT NULL , 
		  "START_TIME" TIMESTAMP, 
		  "RETRY_COUNT" INTEGER NOT NULL, 
		  "FILE_FAILURES" INTEGER NOT NULL, 
		  "FILE_WARNINGS" INTEGER NOT NULL ) 
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."TRANSFER_STATS" IS 'Each row represents a set of statistics generated at the end of a transfer.';

COMMENT ON COLUMN "FTELOG"."TRANSFER_STATS"."TRANSFER_ID" IS 'The transfer to which the stats refer.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_STATS"."START_TIME" IS 'Time at which the transfer actually started. In a system that is busy or has intermittent connectivity, this may be later than the time in the Started message, which represents the point at which processing began and not successful transfer of data.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_STATS"."RETRY_COUNT" IS 'The number of times that the transfer had to be retried due to load or availability issues.';

ALTER TABLE "FTELOG"."TRANSFER_STATS" 
	ADD CONSTRAINT "TRANSFER_STATS_ID" PRIMARY KEY
		("ID");
		
		
------------------------------------------------
-- DDL Statements for table "FTELOG"."FILE_SPACE_ENTRY"
------------------------------------------------

CREATE TABLE "FTELOG"."FILE_SPACE_ENTRY"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "FILE_SPACE_NAME" VARCHAR(256) NOT NULL , 
		  "TRANSFER_ITEM_ID" BIGINT NOT NULL ,
		  "ALIAS" VARCHAR(2000) ,
		  "DELETED" TIMESTAMP )   
		 IN "USERSPACE1" ; 

COMMENT ON TABLE "FTELOG"."FILE_SPACE_ENTRY" IS 'Each row represents a file that has been sent to the named file space.';

COMMENT ON COLUMN "FTELOG"."FILE_SPACE_ENTRY"."FILE_SPACE_NAME" IS 'The name of the file space this entry relates to.';
COMMENT ON COLUMN "FTELOG"."FILE_SPACE_ENTRY"."TRANSFER_ITEM_ID" IS 'The transfer item this row relates to.';
COMMENT ON COLUMN "FTELOG"."FILE_SPACE_ENTRY"."ALIAS" IS 'The alias name for this entry. Typically will be the name of the source file for the transfer';
COMMENT ON COLUMN "FTELOG"."FILE_SPACE_ENTRY"."DELETED" IS 'When set is the time the file was deleted from the file space. Otherwise it is null.';

ALTER TABLE "FTELOG"."FILE_SPACE_ENTRY" 
	ADD CONSTRAINT "FILE_SPACE_ENTRYID" PRIMARY KEY
		("ID");

		
------------------------------------------------
-- DDL Statements for table "FTELOG"."TRANSFER_EXIT"
------------------------------------------------		
		
CREATE TABLE "FTELOG"."TRANSFER_EXIT"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "EXIT_NAME" VARCHAR(256) NOT NULL , 
		  "TRANSFER_ID" CHAR(48) NOT NULL ,
		  "TYPE" CHAR(20) NOT NULL,
		  "STATUS" CHAR(20),
		  "SUPPLEMENT" VARCHAR(2048) )  
		 IN "USERSPACE1" ; 		

COMMENT ON TABLE "FTELOG"."TRANSFER_EXIT" IS 'Each row represents a transfer exit which was executed for the transfer.';		 

COMMENT ON COLUMN "FTELOG"."TRANSFER_EXIT" . "EXIT_NAME" IS 'The name of the exit.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EXIT" . "TRANSFER_ID" IS 'The completed or cancelled transfer that this exit applies to.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EXIT" . "TYPE" IS 'The type of Exit, either source or destination and start or end.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EXIT" . "STATUS" IS 'The value that the Exit returned, either cancel or proceed.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_EXIT" . "SUPPLEMENT" IS 'Any extra output that the Exit produced';

ALTER TABLE "FTELOG"."TRANSFER_EXIT" 
	ADD CONSTRAINT "TRANSFER_EXIT_ID" PRIMARY KEY
		("ID");

		
------------------------------------------------
-- DDL Statements for table "FTELOG"."TRANSFER_CD_NODE"
------------------------------------------------		
		
CREATE TABLE "FTELOG"."TRANSFER_CD_NODE"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "PNODE" CHAR(16) NOT NULL,
		  "SNODE" CHAR(16) NOT NULL,
		  "BRIDGE_IS_PNODE" CHAR(1) NOT NULL,
		  CONSTRAINT ISBOOL CHECK(BRIDGE_IS_PNODE IN ('Y','N')))  
		 IN "USERSPACE1" ; 		

COMMENT ON TABLE "FTELOG"."TRANSFER_CD_NODE" IS 'Each row represents a pairing of PNODE and SNODE used when transferring to or from a Connect:Direct bridge agent.';		 

COMMENT ON COLUMN "FTELOG"."TRANSFER_CD_NODE" . "PNODE" IS 'The name of the PNODE.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_CD_NODE" . "SNODE" IS 'The name of the SNODE.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_CD_NODE" . "BRIDGE_IS_PNODE" IS 'Whether the Connect:Direct bridge agents node matches the PNODE or SNODE in this pairing. Possible values are Y or N.';

ALTER TABLE "FTELOG"."TRANSFER_CD_NODE" 
	ADD CONSTRAINT "TRANSFER_CD_NODE_ID" PRIMARY KEY
		("ID");

		
------------------------------------------------
-- DDL Statements for table "FTELOG"."TRANSFER_CORRELATOR"
------------------------------------------------		
		
CREATE TABLE "FTELOG"."TRANSFER_CORRELATOR"  (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
		  "CORRELATION_STRING" VARCHAR(256) NOT NULL,
		  "CORRELATION_NUMBER" INT NOT NULL,
		  "CORRELATION_BOOLEAN" CHAR(1) NOT NULL,
		  CONSTRAINT ISBOOL CHECK(CORRELATION_BOOLEAN IN ('Y','N')))  
		 IN "USERSPACE1" ; 		

COMMENT ON TABLE "FTELOG"."TRANSFER_CORRELATOR" IS 'Each row represents a correlation string, number and boolean value associated with a transfer item.';		 

COMMENT ON COLUMN "FTELOG"."TRANSFER_CORRELATOR" . "CORRELATION_STRING" IS 'A string correlation value.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_CORRELATOR" . "CORRELATION_NUMBER" IS 'A number correlation value.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_CORRELATOR" . "CORRELATION_BOOLEAN" IS 'A boolean correlation value. Possible values are Y or N.';

ALTER TABLE "FTELOG"."TRANSFER_CORRELATOR" 
	ADD CONSTRAINT "TRANSFER_CORRELATOR_ID" PRIMARY KEY
		("ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."TRANSACTION_LOG"
------------------------------------------------		
		
CREATE TABLE "FTELOG"."TRANSACTION_LOG" (
          "MESSAGE_ID" CHAR(48) NOT NULL)
         IN "USERSPACE1";
         
COMMENT ON TABLE "FTELOG"."TRANSACTION_LOG" IS 'Each row represents the message ID of a log message that has been successfully processed.';

COMMENT ON COLUMN "FTELOG"."TRANSACTION_LOG"."MESSAGE_ID" IS 'The message ID successfully processed log message.';         
		
ALTER TABLE "FTELOG"."TRANSACTION_LOG" 
	ADD CONSTRAINT "TRANSACTION_LOG_ID" PRIMARY KEY
		("MESSAGE_ID");


------------------------------------------------
-- DDL Statements for table "FTELOG"."TRANSFER_ITEM_ATTRIBUTES"
------------------------------------------------		
		
CREATE TABLE "FTELOG"."TRANSFER_ITEM_ATTRIBUTES" (
		  "ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +0  
		    INCREMENT BY +1  
		    MINVALUE +0  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    NO CACHE  
		    NO ORDER ) , 
          "TRANSFER_ITEM_ID" BIGINT NOT NULL,
          "ATTRIBUTE_NAME" VARCHAR(256) NOT NULL,
          "ATTRIBUTE_VALUE" VARCHAR(256))
         IN "USERSPACE1";
         
COMMENT ON TABLE "FTELOG"."TRANSFER_ITEM_ATTRIBUTES" IS 'Each row represents an attribute name/value pair associated with a row in the TRANSFER_ITEM table.';

COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM_ATTRIBUTES"."TRANSFER_ITEM_ID" IS 'The TRANSFER_ITEM row associated with this attribute name/value pair.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM_ATTRIBUTES"."ATTRIBUTE_NAME" IS 'The name of the attribute.';
COMMENT ON COLUMN "FTELOG"."TRANSFER_ITEM_ATTRIBUTES"."ATTRIBUTE_VALUE" IS 'The value of the attribute, if any.';
		
ALTER TABLE "FTELOG"."TRANSFER_ITEM_ATTRIBUTES" 
	ADD CONSTRAINT "TRANSFER_ITEM_ATTRIBUTES_ID" PRIMARY KEY
		("ID");
		
		
------------------------------------------------
-- DDL Statements for foreign keys on Tables
------------------------------------------------

-- DDL Statements for foreign keys on Table "FTELOG"."TRANSFER_STATS"

ALTER TABLE "FTELOG"."TRANSFER_STATS" 
	ADD CONSTRAINT "STATS_TRANSFER_ID" FOREIGN KEY
		("TRANSFER_ID")
	REFERENCES "FTELOG"."TRANSFER"
		("TRANSFER_ID")
	ON DELETE RESTRICT
	ON UPDATE RESTRICT
	ENFORCED
	ENABLE QUERY OPTIMIZATION;

-- DDL Statements for foreign keys on Table "FTELOG"."TRANSFER_ITEM"

ALTER TABLE "FTELOG"."TRANSFER_ITEM" 
	ADD CONSTRAINT "VALID_TRANSFER_ID" FOREIGN KEY
		("TRANSFER_ID")
	REFERENCES "FTELOG"."TRANSFER"
		("TRANSFER_ID")
	ON DELETE RESTRICT
	ON UPDATE RESTRICT
	ENFORCED
	ENABLE QUERY OPTIMIZATION;

ALTER TABLE "FTELOG"."TRANSFER_ITEM" 
	ADD CONSTRAINT "VALID_SOURCE_CORRELATOR_ID" FOREIGN KEY
		("SOURCE_CORRELATOR_ID")
	REFERENCES "FTELOG"."TRANSFER_CORRELATOR"
		("ID")
	ON DELETE RESTRICT
	ON UPDATE RESTRICT
	ENFORCED
	ENABLE QUERY OPTIMIZATION;

ALTER TABLE "FTELOG"."TRANSFER_ITEM" 
	ADD CONSTRAINT "VALID_DESTINATION_CORRELATOR_ID" FOREIGN KEY
		("DESTINATION_CORRELATOR_ID")
	REFERENCES "FTELOG"."TRANSFER_CORRELATOR"
		("ID")
	ON DELETE RESTRICT
	ON UPDATE RESTRICT
	ENFORCED
	ENABLE QUERY OPTIMIZATION;

-- DDL Statements for foreign keys on Table "FTELOG"."SCHEDULE_ITEM"

ALTER TABLE "FTELOG"."SCHEDULE_ITEM" 
	ADD CONSTRAINT "ITEM_IN_SCHEDSPEC" FOREIGN KEY
		("SCHEDULE_SPEC_ID")
	REFERENCES "FTELOG"."SCHEDULE_SPEC"
		("ID")
	ON DELETE CASCADE
	ON UPDATE RESTRICT
	ENFORCED
	ENABLE QUERY OPTIMIZATION;

-- DDL Statements for foreign keys on Table "FTELOG"."SCHEDULE"

ALTER TABLE "FTELOG"."SCHEDULE" 
	ADD CONSTRAINT "ACTION_IN_SCHEDULE" FOREIGN KEY
		("LATEST_ACTION")
	REFERENCES "FTELOG"."SCHEDULE_ACTION"
		("ID")
	ON DELETE RESTRICT
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION;

-- DDL Statements for foreign keys on Table "FTELOG"."TRIGGER_CONDITION"

ALTER TABLE "FTELOG"."TRIGGER_CONDITION" 
	ADD CONSTRAINT "COND_IN_EVENT" FOREIGN KEY
		("TRANSFER_EVENT_ID")
	REFERENCES "FTELOG"."TRANSFER_EVENT"
		("ID")
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION;

-- DDL Statements for foreign keys on Table "FTELOG"."CALL_ARGUMENT"

ALTER TABLE "FTELOG"."CALL_ARGUMENT" 
	ADD CONSTRAINT "ARGUMENT_IN_CALL" FOREIGN KEY
		("CALL_ID")
	REFERENCES "FTELOG"."CALL"
		("ID")
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION;

-- DDL Statements for foreign keys on Table "FTELOG"."TRANSFER_CALLS"

ALTER TABLE "FTELOG"."TRANSFER_CALLS" 
	ADD CONSTRAINT "CALL_IN_TRANSFER" FOREIGN KEY
		("TRANSFER_ID")
	REFERENCES "FTELOG"."TRANSFER"
		("TRANSFER_ID")
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION;

-- DDL Statements for foreign keys on Table "FTELOG"."MONITOR_METADATA"

ALTER TABLE "FTELOG"."MONITOR_METADATA" 
	ADD CONSTRAINT "MONMETA_IN_ACTION" FOREIGN KEY
		("ACTION_ID")
	REFERENCES "FTELOG"."MONITOR_ACTION"
		("ID")
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION;

-- DDL Statements for foreign keys on Table "FTELOG"."MONITOR_EXIT_RESULT"

ALTER TABLE "FTELOG"."MONITOR_EXIT_RESULT" 
	ADD CONSTRAINT "EXITRSLT_IN_ACTION" FOREIGN KEY
		("ACTION_ID")
	REFERENCES "FTELOG"."MONITOR_ACTION"
		("ID")
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION;

-- DDL Statements for foreign keys on Table "FTELOG"."MONITOR_ACTION"

ALTER TABLE "FTELOG"."MONITOR_ACTION" 
	ADD CONSTRAINT "ACTION_IN_MONITOR" FOREIGN KEY
		("MONITOR")
	REFERENCES "FTELOG"."MONITOR"
		("ID")
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION;

	
-- DDL Statements for foreign keys on Table "FTELOG"."FILE_SPACE_ENTRY"

ALTER TABLE "FTELOG"."FILE_SPACE_ENTRY" 
	ADD CONSTRAINT "VALID_TFER_ITEM_ID" FOREIGN KEY
		("TRANSFER_ITEM_ID")
	REFERENCES "FTELOG"."TRANSFER_ITEM"
		("ID")
	ON DELETE RESTRICT
	ON UPDATE RESTRICT
	ENFORCED
	ENABLE QUERY OPTIMIZATION;
	
-- DDL Statements for foreign keys on Table "FTELOG"."TRANSFER_EXIT"

ALTER TABLE "FTELOG"."TRANSFER_EXIT" 
	ADD CONSTRAINT "VALID_TRANSFER_ID" FOREIGN KEY
		("TRANSFER_ID")
	REFERENCES "FTELOG"."TRANSFER"
		("TRANSFER_ID")
	ON DELETE RESTRICT
	ON UPDATE RESTRICT
	ENFORCED
	ENABLE QUERY OPTIMIZATION;	

-- DDL Statements for foreign keys on Table "FTELOG"."TRANSFER_EVENT"

ALTER TABLE "FTELOG"."TRANSFER_EVENT" 
	ADD CONSTRAINT "VALID_SOURCE_CD_NODE_ID" FOREIGN KEY
		("SOURCE_CD_NODE_ID")
	REFERENCES "FTELOG"."TRANSFER_CD_NODE"
		("ID")
	ON DELETE RESTRICT
	ON UPDATE RESTRICT
	ENFORCED
	ENABLE QUERY OPTIMIZATION;	

ALTER TABLE "FTELOG"."TRANSFER_EVENT" 
	ADD CONSTRAINT "VALID_DESTINATION_CD_NODE_ID" FOREIGN KEY
		("DESTINATION_CD_NODE_ID")
	REFERENCES "FTELOG"."TRANSFER_CD_NODE"
		("ID")
	ON DELETE RESTRICT
	ON UPDATE RESTRICT
	ENFORCED
	ENABLE QUERY OPTIMIZATION;	

-- DDL Statements for foreign keys on Table "FTELOG"."TRANSFER_ITEM_ATTRIBUTES"

ALTER TABLE "FTELOG"."TRANSFER_ITEM_ATTRIBUTES" 
	ADD CONSTRAINT "VALID_TRANSFER_ITEM_ID" FOREIGN KEY
		("TRANSFER_ITEM_ID")
	REFERENCES "FTELOG"."TRANSFER_ITEM"
		("ID")
	ON DELETE RESTRICT
	ON UPDATE RESTRICT
	ENFORCED
	ENABLE QUERY OPTIMIZATION;	

	
----------------------------
-- DDL Statements for Views
----------------------------

Create view FTEVIEW.BASIC_TRANSFER_DETAILS as ( select substr(job_name,
1, 16) as "Job Name", transfer.transfer_id as "Transfer Id", transfer.resultcode
as "Overall Result", substr(transfer.resulttext, 1, 80) as "Overall Result Text",
transfer_start.action_time as "Start Time", transfer_end.action_time as
"End Time", transfer_start.source_agent as "From", transfer_start.destination_agent
as "To", substr(transfer_start.originator_host, 1, 20) as "Submitted From",
substr(transfer_start.originator_user, 1, 12) as "Submitted By", substr(source_filename,
1, 32) as "Source File", substr(destination_filename, 1, 32) as "Destination File",
transfer_item.resultcode as "File Result", substr(transfer_item.result_text,
1, 80) as "File Result Message" from ftelog.transfer transfer, ftelog.transfer_event
transfer_start, ftelog.transfer_event transfer_end, ftelog.transfer_item
transfer_item where transfer_start.id = transfer.start_id and transfer_end.id
= transfer.complete_id and transfer_item.transfer_id = transfer.transfer_id
);
	
COMMIT WORK;