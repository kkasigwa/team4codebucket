/* @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=samples/c/xatm/oraswit0.c */
/******************************************************************************/
/*                                                                            */
/* Module name: oraswit.c                                                     */
/*                                                                            */
/* Description: MQ XA switch program for Oracle                               */
/*                                                                            */
/*  <copyright                                                                */
/*  notice="lm-source-program"                                                */
/*  pids="5724-H72,"                                                          */
/*  years="1998,2016"                                                         */
/*  crc="3423970931" >                                                        */
/*  Licensed Materials - Property of IBM                                      */
/*                                                                            */
/*  5724-H72,                                                                 */
/*                                                                            */
/*  (C) Copyright IBM Corp. 1998, 2016 All Rights Reserved.                   */
/*                                                                            */
/*  US Government Users Restricted Rights - Use, duplication or               */
/*  disclosure restricted by GSA ADP Schedule Contract with                   */
/*  IBM Corp.                                                                 */
/*  </copyright>                                                              */
/*                                                                            */
/******************************************************************************/

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/

#include <cmqc.h>                                /* MQ header                 */
#include "xa.h"                                  /* MQ supplied XA header     */

/******************************************************************************/
/* External data declarations                                                 */
/******************************************************************************/

extern struct xa_switch_t xaosw;

/******************************************************************************/
/*                                                                            */
/* Function name:  MQStart                                                    */
/*                                                                            */
/* Description: The queue manager calls this function to access the XA switch */
/*              of Oracle                                                     */
/*                                                                            */
/******************************************************************************/
/*                                                                            */
/* Input Parameters:  None                                                    */
/*                                                                            */
/* Output Parameters: None                                                    */
/*                                                                            */
/* Returns:           Pointer to Oracle XA switch                             */
/*                                                                            */
/******************************************************************************/
struct xa_switch_t * MQENTRY MQStart(void)
{
   return(&xaosw);
}

/******************************************************************************/
/* End of oraswit.c                                                           */
/******************************************************************************/
