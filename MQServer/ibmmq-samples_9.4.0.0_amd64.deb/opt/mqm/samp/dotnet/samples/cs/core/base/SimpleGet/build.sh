echo Building SimpleGet
dotnet build SimpleGet.csproj