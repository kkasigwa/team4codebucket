// SCCSID "@(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=MQJavaSamples/jms/requestReply/Responder.java"
/*
 *   <copyright
 *   notice="lm-source-program"
 *   pids="5724-H72,5655-R36,5655-L82,5724-L26,"
 *   years="2024"
 *   crc="351956101" >
 *   Licensed Materials - Property of IBM
 *
 *   5724-H72,5655-R36,5655-L82,5724-L26,
 *
 *   (C) Copyright IBM Corp. 2024 All Rights Reserved.
 *
 *   US Government Users Restricted Rights - Use, duplication or
 *   disclosure restricted by GSA ADP Schedule Contract with
 *   IBM Corp.
 *   </copyright>
 */

package requestReply;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Session;

import com.ibm.msg.client.jms.JmsConnectionFactory;
import com.ibm.msg.client.jms.JmsFactoryFactory;
import com.ibm.msg.client.wmq.WMQConstants;

/**
 * A simple application that listens on a destination for messages and then replies to the
 * message's replyTo destination. The application is written to operate in conjunction with the
 * SimpleRequestor sample.
 *
 * Application makes use of fixed literals, any customisations will require re-compilation of this
 * source file. Application assumes that the named queue is empty prior to a run.
 *
 * NOTE: This is a sample application, demonstrating basic principles of Request/Reply processing.
 *
 */
public class Responder {

  private int status;

  private Connection connection = null;
  private Session session = null;
  private Destination requestQueue = null;
  private MessageConsumer consumer = null;
  private RespondingMessageListener listener = null;

  /**
   * @param args ignored
   */
  public static void main(String[] args) {

    Responder theResponder = new Responder();
    theResponder.runResponder();

    return;
  }

  private Responder() {

    try {

      // Create a connection factory
      JmsFactoryFactory ff = JmsFactoryFactory.getInstance(WMQConstants.WMQ_PROVIDER);
      JmsConnectionFactory cf = ff.createConnectionFactory();

      // Set the properties
      cf.setStringProperty(WMQConstants.WMQ_HOST_NAME, "localhost");
      cf.setIntProperty(WMQConstants.WMQ_PORT, 1414);
      cf.setStringProperty(WMQConstants.WMQ_CHANNEL, "SYSTEM.DEF.SVRCONN"); // Not recommended - use an application specific channel
      cf.setIntProperty(WMQConstants.WMQ_CONNECTION_MODE, WMQConstants.WMQ_CM_CLIENT);

      // Create JMS objects
      connection = cf.createConnection();
      session = connection.createSession(true, Session.SESSION_TRANSACTED);
      requestQueue = session.createQueue("queue:///Q1");
      consumer = session.createConsumer(requestQueue);

      // Set up the consumer to listen for messages and respond.
      listener = new RespondingMessageListener();
      consumer.setMessageListener(listener);
    }
    catch (JMSException jmsex) {
      recordFailure(jmsex);
    }
  }

  private void runResponder() {

    try {
      // Start the connection
      connection.start();

      // Wait for the processing to finish
      while (!listener.processedLastRequest) {
        try {
          synchronized (listener) {
            listener.wait();
          }
        }
        catch (InterruptedException ie) {
          // We can ignore this, as the processedLastRequest field is the important thing
        }
      }

    }
    catch (

    JMSException jmsex) {
      recordFailure(jmsex);
    }
    finally {
      if (consumer != null) {
        try {
          consumer.close();
        }
        catch (JMSException jmsex) {
          System.out.println("Consumer could not be closed.");
          recordFailure(jmsex);
        }
      }

      if (session != null) {
        try {
          session.close();
        }
        catch (JMSException jmsex) {
          System.out.println("Session could not be closed.");
          recordFailure(jmsex);
        }
      }

      if (connection != null) {
        try {
          connection.close();
        }
        catch (JMSException jmsex) {
          System.out.println("Connection could not be closed.");
          recordFailure(jmsex);
        }
      }
    }
    System.exit(status);
    return;

  }

  /**
   * Process a JMSException and any associated inner exceptions.
   *
   * @param jmsex
   */
  private void processJMSException(JMSException jmsex) {
    System.out.println(jmsex);
    Throwable innerException = jmsex.getLinkedException();
    if (innerException != null) {
      System.out.println("Inner exception(s):");
    }
    while (innerException != null) {
      System.out.println(innerException);
      innerException = innerException.getCause();
    }
    return;
  }

  /**
   * Record this run as failure.
   *
   * @param ex
   */
  private void recordFailure(Exception ex) {
    if (ex != null) {
      ex.printStackTrace();

      if (ex instanceof JMSException) {
        processJMSException((JMSException) ex);
      }
      else {
        System.out.println(ex);
      }
    }
    System.out.println("FAILURE");
    status = -1;
    return;
  }

  /**
   * Message Listener to process requests
   */
  private class RespondingMessageListener implements MessageListener {

    private volatile boolean processedLastRequest;
    private MessageProducer producer;

    public RespondingMessageListener() throws JMSException {
      producer = session.createProducer(null);
    }

    @Override
    public void onMessage(Message requestMessage) {

      try {
        System.out.println("\nReceived message:\n" + requestMessage);
        session.commit(); // Confirm we got the message

        if (requestMessage.getBooleanProperty("APP_LASTREQUEST")) {
          // Notification from the requestor that it's finished
          // Allow this process to exit
          processedLastRequest = true;
          synchronized (this) {
            notify();
          }
        }
        else {
          // Genuine request, so send a response
          Destination replyTo = requestMessage.getJMSReplyTo();

          if (replyTo == null) {
            // Can't reply - just complain...
            System.out.println("No ReplyTo destination defined");
          }
          else {
            long uniqueNumber = System.currentTimeMillis() % 1000;
            Message replyMessage = session.createTextMessage("SimpleResponder: another lucky number " + uniqueNumber);

            // Set reply message correlation id to the request message id
            // to allow the requestor to relate replies to requests
            replyMessage.setJMSCorrelationID(requestMessage.getJMSMessageID());

            long timeToLive = requestMessage.getLongProperty("APP_TTL");
            producer.setTimeToLive(timeToLive); // response time to live matches request time to live
            producer.send(replyTo, replyMessage);
            session.commit(); // commit the send, so that the requestor can see the result

          }
        }
      }
      catch (JMSException e) {
        recordFailure(e);
      }
      return;
    }
  }

}
