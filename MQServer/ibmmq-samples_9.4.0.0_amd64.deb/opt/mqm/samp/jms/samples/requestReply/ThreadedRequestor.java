// SCCSID "@(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=MQJavaSamples/jms/requestReply/ThreadedRequestor.java"
/*
 *   <copyright
 *   notice="lm-source-program"
 *   pids="5724-H72,5655-R36,5655-L82,5724-L26,"
 *   years="2024"
 *   crc="351956101" >
 *   Licensed Materials - Property of IBM
 *
 *   5724-H72,5655-R36,5655-L82,5724-L26,
 *
 *   (C) Copyright IBM Corp. 2024 All Rights Reserved.
 *
 *   US Government Users Restricted Rights - Use, duplication or
 *   disclosure restricted by GSA ADP Schedule Contract with
 *   IBM Corp.
 *   </copyright>
 */

package requestReply;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import com.ibm.msg.client.jms.JmsConnectionFactory;
import com.ibm.msg.client.jms.JmsFactoryFactory;
import com.ibm.msg.client.wmq.WMQConstants;

/**
 * A simple application that uses a requestor to send a request message and then wait for, and
 * receive, the reply. Note: It is assumed that some other application will process the request
 * message and send the reply message, identifying replies by setting their correlation id to
 * match the request's message id. See the corresponding Responder class for a simple example.
 *
 * This sample uses asynchronous consume to handle the replies, so uses a Collection to track
 * requests which haven't received replies. A scheduled task manages this Collection to deal
 * with retrying requests which have not received replies in a "reasonable" time, and discarding
 * requests after a maximum number of retries.
 *
 * The application makes use of fixed literals, any customisations will require re-compilation of this
 * source file.
 *
 * The application assumes that the named queue is empty prior to a run.
 *
 * NOTE: This is a sample application, demonstrating basic principles of Request/Reply processing.
 *       Naturally it's nothing like "production-ready"...
 */
public class ThreadedRequestor {

  // How many request/reply pairs we plan to process
  private static final int MAX_REQUESTS = 10;

  // How many retries do we allow for?
  private static final int MAX_RETRIES = 3;

  // Time To Live value for the messages (both request and reply) - 1 second
  private static final long TTL = 1000;

  private Connection connection = null;
  private Session producingSession = null;
  private Session consumingSession = null;
  private Destination tempDestination = null;
  private MessageProducer producer = null;
  private MessageConsumer consumer = null;

  private Map<String, Message> outstandingRequests = new HashMap<>();

  private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

  /**
   * Main method
   *
   * @param args
   */
  public static void main(String[] args) {

    new ThreadedRequestor().runToCompletion();
  }

  private ThreadedRequestor() {
    try {
      // Create a connection factory
      JmsFactoryFactory ff = JmsFactoryFactory.getInstance(WMQConstants.WMQ_PROVIDER);
      JmsConnectionFactory cf = ff.createConnectionFactory();

      // Set the properties
      cf.setStringProperty(WMQConstants.WMQ_HOST_NAME, "localhost");
      cf.setIntProperty(WMQConstants.WMQ_PORT, 1414);
      cf.setStringProperty(WMQConstants.WMQ_CHANNEL, "SYSTEM.DEF.SVRCONN"); // Not recommended - use an application specific channel
      cf.setIntProperty(WMQConstants.WMQ_CONNECTION_MODE, WMQConstants.WMQ_CM_CLIENT);

      // Create JMS objects
      connection = cf.createConnection();

      // Somewhere to send requests, and a producer to send them
      producingSession = connection.createSession(true, Session.SESSION_TRANSACTED);
      Destination destination = producingSession.createQueue("queue:///Q1");
      producer = producingSession.createProducer(destination);
      producer.setTimeToLive(TTL);

      // Somewhere to receive replies, and a consumer to receive them
      consumingSession = connection.createSession(true, Session.SESSION_TRANSACTED);
      tempDestination = consumingSession.createTemporaryQueue();
      consumer = consumingSession.createConsumer(tempDestination);
      consumer.setMessageListener(new CleaningListener());

      // Handle retrying and cleaning the outstandingRequests
      RequestCleaner requestCleaner = new RequestCleaner();
      scheduler.scheduleAtFixedRate(requestCleaner, 10, 10, TimeUnit.SECONDS);
    }
    catch (JMSException jmsex) {
      recordFailure(jmsex);
    }

  }

  private void runToCompletion() {
    try {
      // Start the connection
      connection.start();

      for (int i = 0; i < MAX_REQUESTS; i++) {
        Message message = prepareRequest();

        sendAndStoreMessage(message);

        try {
          Thread.sleep(20_000);
        }
        catch (InterruptedException ie) {
          // ignore it for now
        }
      }

      // Tell the responder that we've finished
      TextMessage message = producingSession.createTextMessage();

      // This marks the last request
      message.setBooleanProperty("APP_LASTREQUEST", true);

      // Send the request
      producer.send(message);
      producingSession.commit();
      System.out.println("Sent closedown message:\n" + message);

      recordSuccess();
      scheduler.shutdown();
    }
    catch (

    JMSException jmsex) {
      recordFailure(jmsex);
    }
  }

  private void sendAndStoreMessage(Message message) throws JMSException {
    producer.send(message);
    synchronized (outstandingRequests) {
      outstandingRequests.put(message.getJMSMessageID(), message);
    }
    producingSession.commit();
    System.out.println("Sent request message:\n" + message);
  }

  private Message prepareRequest() throws JMSException {
    long uniqueNumber = System.currentTimeMillis() % 1000;
    TextMessage message = producingSession
        .createTextMessage("ThreadedRequestor: Your lucky number today is " + uniqueNumber);

    // Set the JMSReplyTo
    message.setJMSReplyTo(tempDestination);

    // Not the last request
    message.setBooleanProperty("APP_LASTREQUEST", false);

    // Tell the responder about our TTL
    message.setLongProperty("APP_TTL", TTL);

    // Track retries
    message.setIntProperty("APP_RETRIES", 0);
    return message;
  }

  /**
   * Process a JMSException and any associated inner exceptions.
   *
   * @param jmsex
   */
  private void processJMSException(JMSException jmsex) {
    System.out.println(jmsex);
    Throwable innerException = jmsex.getLinkedException();
    if (innerException != null) {
      System.out.println("Inner exception(s):");
    }
    while (innerException != null) {
      System.out.println(innerException);
      innerException = innerException.getCause();
    }
    return;
  }

  /**
   * Record this run as successful.
   */
  private void recordSuccess() {
    System.out.println("SUCCESS");
    return;
  }

  /**
   * Record this run as failure.
   *
   * @param ex
   */
  private void recordFailure(Exception ex) {
    if (ex != null) {
      if (ex instanceof JMSException) {
        processJMSException((JMSException) ex);
      }
      else {
        System.out.println(ex);
      }
    }
    System.out.println("FAILURE");
    System.exit(-1);
  }

  private class CleaningListener implements MessageListener {

    @Override
    public void onMessage(Message receivedMessage) {
      try {
        consumingSession.commit();

        System.out.println("\nReceived response:\n" + receivedMessage);

        synchronized (outstandingRequests) {
          if (outstandingRequests.remove(receivedMessage.getJMSCorrelationID()) == null) {
            System.out.println("Unexpected response!");
          }
        }
      }
      catch (JMSException e) {
        // Best efforts for now - probably should handle better
      }
    }

  }

  private class RequestCleaner implements Runnable {

    private long timeoutInterval = 5 * TTL; // allow for Time To Live on request and reply, plus "thinking time"

    @Override
    public void run() {
      System.out.println("Starting a cleaning cycle");
      List<String> killList = new ArrayList<>();
      try {
        long now = System.currentTimeMillis();
        long latestTimeout = now - timeoutInterval;
        synchronized (outstandingRequests) {
          for (Map.Entry<String, Message> currentEntry : outstandingRequests.entrySet()) {
            Message currentMessage = currentEntry.getValue();
            String currentCorrelationId = currentEntry.getKey();
            if (currentMessage.getJMSTimestamp() < latestTimeout) {
              // Remove this, whether it's requeued or not, as the requeue will generate a fresh id
              killList.add(currentCorrelationId);
              int currentRetries = currentMessage.getIntProperty("APP_RETRIES");
              if (currentRetries < MAX_RETRIES) {
                currentMessage.setIntProperty("APP_RETRIES", currentRetries + 1);
                sendAndStoreMessage(currentMessage);
              }
            }
          }
          // Remove the expired entries
          for (String correlationId : killList) {
            outstandingRequests.remove(correlationId);
          }
        }
      }
      catch (JMSException e) {
        // Best efforts for now - probably should handle better
      }

    }

  }

}
