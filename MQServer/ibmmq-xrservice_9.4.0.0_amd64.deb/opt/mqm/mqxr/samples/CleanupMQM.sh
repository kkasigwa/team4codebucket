#!/bin/sh
# -----------------------------------------------------------------
# IBM MQ MQXR Cleanup Utility - Run script
# Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.mq.mqxr.listener/listenerSamplesSource/mqxr/CleanupMQM.sh  
#
# <copyright notice="copyright-lm-source-program"
#            pids="5724-H72"
#            years="1993,2015"
#            crc="3462584852" >
#
# Licensed Materials - Property of IBM
#
# 5724-H72
#
# (C) Copyright IBM Corp. 1993, 2015
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#
# </copyright>
# -----------------------------------------------------------------

endmqm -i MQXR_SAMPLE_QM
dltmqm MQXR_SAMPLE_QM
