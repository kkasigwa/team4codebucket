#!/bin/sh
# -----------------------------------------------------------------
# IBM MQ MQXR Create Queue Manager Utility - Run script
# Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.mq.mqxr.listener/listenerSamplesSource/mqxr/SampleMQM.sh  
#
# <copyright notice="copyright-lm-source-program"
#            pids="5724-H72"
#            years="1993,2015"
#            crc="3462584852" >
#
# Licensed Materials - Property of IBM
#
# 5724-H72
#
# (C) Copyright IBM Corp. 1993, 2015
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#
# </copyright>
# -----------------------------------------------------------------

#This script creates an MQTT-enabled Queue manager to allow quick testing.

#Get the name of the Queue Manager
QMGR=${1-MQXR_SAMPLE_QM}

#Get the Port number
PORT=${2-1883}

#Find the current directory
SAMPLEDIR="`dirname \"$0\"`"

crtmqm $QMGR
strmqm $QMGR
   
echo "DEFINE QLOCAL('SYSTEM.MQTT.TRANSMIT.QUEUE') USAGE(XMITQ) MAXDEPTH(100000)" | runmqsc $QMGR
echo "ALTER QMGR DEFXMITQ('SYSTEM.MQTT.TRANSMIT.QUEUE')" | runmqsc $QMGR

# Allow user nobody to send messages to clients attached to the MQTT Listener.
# Note: Allowing the user nobody to do something in MQ, allows all users to do it!
setmqaut -m $QMGR -t q -n SYSTEM.MQTT.TRANSMIT.QUEUE -p nobody -all +put

# Allow user nobody to publish and subscribe on any topic.
# Note: Allowing the user nobody to do something in MQ, allows all users to do it!
setmqaut -m $QMGR -t topic -n SYSTEM.BASE.TOPIC -p nobody -all +pub +sub

#Install the service into the QMgr
cat $SAMPLEDIR/installMQXRService_unix.mqsc | runmqsc $QMGR

#Start the service
echo "START SERVICE(SYSTEM.MQXR.SERVICE)" | runmqsc $QMGR

#Create and start a channel
echo "DEFINE CHANNEL('PlainText') CHLTYPE(MQTT) PORT($PORT) MCAUSER('nobody')" | runmqsc $QMGR
