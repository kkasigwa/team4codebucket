/*
 * 
 * Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.exitroutines.api/samples/protocolBridge/SampleCredentialExit.java
 * 
 * <copyright 
 * notice="lm-source-program" 
 * pids="5724-H72,5655-MF9"
 * years="2010,2016" 
 * crc="3912865343" > 
 * Licensed Materials - Property of IBM  
 *    
 * 5724-H72,5655-R36,5655-L82,5724-L26 
 *    
 * (C) Copyright IBM Corp. 2010, 2016 All Rights Reserved.  
 *    
 * US Government Users Restricted Rights - Use, duplication or  
 * disclosure restricted by GSA ADP Schedule Contract with  
 * IBM Corp.  
 * </copyright>
 * 
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import com.ibm.wmqfte.exitroutine.api.CredentialExitResult;
import com.ibm.wmqfte.exitroutine.api.CredentialExitResultCode;
import com.ibm.wmqfte.exitroutine.api.CredentialPassword;
import com.ibm.wmqfte.exitroutine.api.CredentialUserId;
import com.ibm.wmqfte.exitroutine.api.Credentials;
import com.ibm.wmqfte.exitroutine.api.ProtocolBridgeCredentialExit;

/**
 * A sample protocol bridge credential exit. This exit reads a properties file
 * that maps IBM MQ user ids to corresponding protocol server user id and
 * passwords.
 * <p>
 * The format of each entry in the properties file is '
 * <code>mqUserId=serverUserId,serverPassword</code>'
 * <p>
 * The location of the properties file is taken from the protocol bridge agent
 * property <code>protocolBridgeCredentialConfiguration</code>.
 * <p>
 * To install the sample exit:
 * <ol>
 * <li>Compile the class and export to a jar file.
 * <li>Place the jar file in the <code>exits</code> subdirectory of the agent data directory
 * of the protocol bridge agent on which the exit is to be installed.
 * <li>In the <code>agent.properties</code> file of the protocol bridge agent
 * set the <code>protocolBridgeCredentialExitClasses</code> to
 * <code>SampleCredentialExit</code>.
 * <li>Create a properties file that contains the <code>mqUserId</code> to
 * <code>serverUserId</code> and <code>serverPassword</code> mappings applicable to the
 * agent.
 * <li>In the <code>agent.properties</code> file of the protocol bridge agent
 * set the <code>protocolBridgeCredentialConfiguration</code> property to the
 * absolute path name of this properties file.
 * <li>To activate the changes stop and restart the protocol bridge agent.
 * </ol>
 * <p>
 * For further information on protocol bridge credential exits refer to the
 * IBM MQ Managed File Transfer documentation online at:
 * <p>
 * {@link http://publib.boulder.ibm.com/infocenter/wmqfte/v7r0/}
 */
public class SampleCredentialExit implements ProtocolBridgeCredentialExit {

	/** A <@code Map> that holds the MQ user id to serverUserId and serverPassword mappings */
	final private Map<String, Credentials> credentialsMap = new HashMap<String, Credentials>();
	
	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.ProtocolBridgeCredentialExit#initialize(java.util.Map)
	 */
	public synchronized boolean initialize(final Map<String, String> bridgeProperties) {
		// Flag to indicate whether the exit has been successfully initialized or not
		boolean initialisationResult = true;
		
		// Get the path of the mq user id mapping properties file
		final String propertiesFilePath = bridgeProperties.get("protocolBridgeCredentialConfiguration");
		if (propertiesFilePath == null || propertiesFilePath.length() == 0) {
			// The properties file path has not been specified. Output an error and return false
			System.err.println("Error initializing SampleCredentialExit."); 
			System.err.println("The location of the mqUserID mapping properties file has not been specified in the protocolBridgeCredentialConfiguration property");
			initialisationResult = false;
		}
		
		if (initialisationResult) {
			// The Properties object that holds mq user id to serverUserId and serverPassword
			// mappings from the properties file
			final Properties mappingProperties = new Properties();
			
			// Open and load the properties from the properties file
			final File propertiesFile = new File (propertiesFilePath);
			FileInputStream inputStream = null;
			try {
				// Create a file input stream to the file
				inputStream = new FileInputStream(propertiesFile);
				
				// Load the properties from the file
				mappingProperties.load(inputStream);
			}
			catch (final FileNotFoundException ex) {
				System.err.println("Error initializing SampleCredentialExit."); 
				System.err.println("Unable to find the mqUserId mapping properties file: " + propertiesFilePath);
				initialisationResult = false;
			}
			catch (final IOException ex) {
				System.err.println("Error initializing SampleCredentialExit."); 
				System.err.println("Error loading the properties from the mqUserId mapping properties file: " + propertiesFilePath);
				initialisationResult = false;
			}
			finally {
				// Close the inputStream
				if (inputStream != null) {
					try {
						inputStream.close();
					}
					catch (final IOException ex) {
						System.err.println("Error initializing SampleCredentialExit."); 
						System.err.println("Error closing the mqUserId mapping properties file: " + propertiesFilePath);
						initialisationResult = false;
					}
				}
			}
			
			if (initialisationResult) {
				// Populate the map of mqUserId to server credentials from the properties
				final Enumeration<?> propertyNames = mappingProperties.propertyNames(); 
				while (propertyNames.hasMoreElements()) {
					final Object name = propertyNames.nextElement();
					if (name instanceof String ) {
						final String mqUserId = ((String)name).trim(); 
						// Get the value and split into serverUserId and serverPassword
						final String value = mappingProperties.getProperty(mqUserId);
						final StringTokenizer valueTokenizer = new StringTokenizer(value, ",");
						String serverUserId = "";
						String serverPassword = "";
						if (valueTokenizer.hasMoreTokens()) {
							serverUserId = valueTokenizer.nextToken().trim();
						}
						if (valueTokenizer.hasMoreTokens()) {
							serverPassword = valueTokenizer.nextToken().trim();
						}
						// Create a Credential object from the serverUserId and serverPassword
						final Credentials credentials = new Credentials(new CredentialUserId(serverUserId), 
								                                        new CredentialPassword(serverPassword));
						// Insert the credentials into the map
						credentialsMap.put(mqUserId, credentials);
					}
				}			
			}
		}
		
		return initialisationResult;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.ProtocolBridgeCredentialExit#mapMQUserId(java.lang.String)
	 */
	public synchronized CredentialExitResult mapMQUserId(final String mqUserId) {
		CredentialExitResult result = null;
		// Attempt to get the server credentials for the given mq user id
		final Credentials credentials = credentialsMap.get(mqUserId.trim());
		if ( credentials == null) {
			// No entry has been found so return no mapping found with no credentials
			result = new CredentialExitResult(CredentialExitResultCode.NO_MAPPING_FOUND, null);
		}
		else {
			// Some credentials have been found so return success to the user along with the credentials
			result = new CredentialExitResult(CredentialExitResultCode.USER_SUCCESSFULLY_MAPPED, credentials);
		}	
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibm.wmqfte.exitroutine.api.ProtocolBridgeCredentialExit#shutdown(java.util.Map)
	 */
	public void shutdown(final Map<String, String> bridgeProperties) {
		// Nothing to do in this method because there are no resources that need to be released
	}

}
