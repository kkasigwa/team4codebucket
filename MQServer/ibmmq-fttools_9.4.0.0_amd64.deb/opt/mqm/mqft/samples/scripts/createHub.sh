#!/bin/sh

# -------------------------------------------------------------------------------------------------------
#
# @start_non_restricted_prolog@
# Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.common/samples/scripts/unix/createHub.sh
# ============================================================================
# <copyright
# notice="lm-source-program"
# pids="5724-H72"
# years="2015,2019"
# crc="3374478728" >
# Licensed Materials - Property of IBM
#
# 5724-H72
#
# (C) Copyright IBM Corp. 2015, 2019  All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
# </copyright>
# ============================================================================
# @end_prolog@
#
#
# Sample script provided "as-is" to create  a file transfer 'hub'
# in a simple hub and spoke file transfer topology.
#
# Example: createHub.sh hubQmgr=hubQM hubPort=1414
#
# -------------------------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------------------------
#
# First, the error handling and output routines are defined.
#
# -------------------------------------------------------------------------------------------------------

fail() {

	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+ "
	  echo "+ Attempting cleanup of queue manager $hubQmgr..."
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""

	./endmqm -i $hubQmgr
	./dltmqm $hubQmgr
	end

end
}

end() {
	exit 0
}

success() {
	echo ""
	echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo "+"
	echo "+ HUB CREATION COMPLETE FOR QUEUE MANAGER $hubQmgr LISTENING ON PORT $hubPort "
	echo "+"
	echo "+ You are now ready to:"
	echo "+"
	echo "+ * addSpoke: add a spoke to the file transfer topology"
	# echo "+ * createLogger: create a logger at the hub"
	echo "+"
	echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo ""
}

QMGrCreateError() {
	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ Error creating queue manager $hubQmgr. Check previous error messages"
	  echo "+ and resolve the issue. "
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
fail
}

QMGrStartError() {
	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ Error starting queue manager $hubQmgr. Check previous error messages"
	  echo "+ and resolve the issue. "
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
fail
}

PossibleFTAGENTSError() {
	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ There appears to be a problem using the group \"FTAGENTS\". "
	  echo "+ Check previous error messages and resolve the issue."
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
fail
}

PossibleFTUSERSError() {
	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ There appears to be a problem using the group \"FTUSERS\". "
	  echo "+ Check previous error messages and resolve the issue."
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
fail
}

PossibleftagentError() {
	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ There appears to be a problem using the user \"ftagent\". "
	  echo "+ Check previous error messages and resolve the issue."
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
fail
}

PossibleftuserError() {
	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ There appears to be a problem using the user \"ftuser\". "
	  echo "+ Check previous error messages and resolve the issue."
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
fail
}

ChannelCreateError() {
	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ Error creating channels for queue manager $hubQmgr. Check"
	  echo "+ previous error messages and resolve the issue. "
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
fail
}

ListenerCreateError() {
	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ Error creating listener for queue manager $hubQmgr on port $hubPort. Check"
	  echo "+ previous error messages and resolve the issue. "
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
fail
}

coordinationError() {
	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ Unable to configure the coordination queue manager. Check previous "
	  echo "+ error messages and resolve the issue."
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
fail
}

commandError() {
	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ Unable to configure the command queue manager. Check previous error messages"
	  echo "+ and resolve the issue."
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
fail
}


incorrectUsage() {

	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+ Usage: createHub hubQmgr=<queue manager name> hubPort=<port number>"
	  echo "+"
	  echo "+ hubQmgr=<queue manager name>"
	  echo "+   Name of a queue manager to create"
	  echo "+ hubPort=<port number>"
	  echo "+   Unused port number to start a listener on"
	  echo "+"
	  echo "+ This is a sample script provided "as-is" to define a simple"
	  echo "+ hub and spoke model for file transfers. For full details of "
	  echo "+ the topology and security model, please read the script for"
	  echo "+ comments, and refer to the scenarios in the IBM MQ "
	  echo "+ Knowledge Center."
	  echo "+ "
	  echo "+ Pre-requisites: "
	  echo "+ "
	  echo "+ * Install IBM MQ, including all four file transfer components"
	  echo "+ * Create the groups \"FTAGENTS\" and \"FTUSERS\""
	  echo "+ * Create the user \"ftagent\" and add to the \"FTAGENTS\" group"
	  echo "+ * Create the user \"ftuser\" and add to the \"FTUSERS\" group"
	  echo "+"
	  echo "+ This script must be run from the bin directory of the MQ installation as an "
	  echo "+ MQ administrator."
	  echo "+"
	  echo "+ Example: createHub.sh hubQmgr=hubQM hubPort=1414"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""

	  end
}

# -------------------------------------------------------------------------------------------------------
#
# Process the command line parameters, with basic validation of arguments.
#
# -------------------------------------------------------------------------------------------------------

	while [ $# -gt 0 ]
	do
	    echo "Setting $1"
	    export $1
	    shift
	done

	[ -z "${hubQmgr}" ] && incorrectUsage
	[ -z "${hubPort}" ] && incorrectUsage

	if [ "$connectionMode" == "CLIENT" ]; then
	   		# We also need an agent host, hub host, and port
			[ -z "${agentIPAddress}" ] && incorrectUsage
			[ -z "${hubPort}" ] && incorrectUsage
			[ -z "${hubIPAddress}" ] && incorrectUsage
	fi


# -------------------------------------------------------------------------------------------------------
#
# First, we need to create and start the hub queue manager. You can edit this script to reuse an existing
# queue manager should you wish.
#
# -------------------------------------------------------------------------------------------------------

	echo ""
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo "+"
	echo "+ Creating hub queue manager $hubQmgr..."
	echo "+"
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo ""

	./crtmqm $hubQmgr
	if [ $? -ne 0 ]; then QMGrCreateError; fi

	echo ""
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo "+"
	echo "+ Starting hub queue manager $hubQmgr..."
	echo "+"
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo ""


	./strmqm $hubQmgr
	if [ $? -ne 0 ]; then QMGrStartError; fi


# -------------------------------------------------------------------------------------------------------
#
# To support the security model in this script, it's important to have the users and groups configured
# correctly. For brevity, we do not perform thorough validation checks of the group membership, but we do
# perform some no-op basic setmqaut commands that will immediately flag whether expected users or groups
# do not exist. If adopting your own security model, you may wish to enhance or remove the following checks.
#
# -------------------------------------------------------------------------------------------------------

	echo ""
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo "+"
	echo "+ Checking users and groups exist..."
	echo "+"
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo ""

	./setmqaut -m $hubQmgr -t qmgr -g FTUSERS -connect
	if [ $? -ne 0 ]; then PossibleFTUSERSError; fi
	./setmqaut -m $hubQmgr -t qmgr -g FTAGENTS -connect
	if [ $? -ne 0 ]; then PossibleFTAGENTSError; fi
	./setmqaut -m $hubQmgr -t qmgr -p ftagent -connect
	if [ $? -ne 0 ]; then PossibleftagentError; fi
	./setmqaut -m $hubQmgr -t qmgr -p ftuser -connect
	if [ $? -ne 0 ]; then PossibleftuserError; fi


# -------------------------------------------------------------------------------------------------------
#
# We now create the channels to accept incoming requests from any file transfer spoke we add. You can
# customise this command to suit your own needs.
#
# -------------------------------------------------------------------------------------------------------

	echo ""
    echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo "+"
	echo "+ Creating channels for hub at queue manager $hubQmgr..."
	echo "+"
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo ""


	echo "DEFINE CHANNEL(FTE.USER.SVRCONN) CHLTYPE(SVRCONN)" | ./runmqsc $hubQmgr
	if [ $? -ne 0 ]; then ChannelCreateError; fi
	echo "DEFINE CHANNEL(FTE.AGENT.SVRCONN) CHLTYPE(SVRCONN)" | ./runmqsc $hubQmgr
	if [ $? -ne 0 ]; then ChannelCreateError; fi


# -------------------------------------------------------------------------------------------------------
#
# We now create a listener to service the incoming requests. You can
# customise this command to suit your own needs.
#
# -------------------------------------------------------------------------------------------------------

	echo ""
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo "+"
	echo "+ Creating listener for hub at queue manager $hubQmgr using port $hubPort..."
	echo "+"
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo ""


	echo "DEFINE LISTENER (HUBLISTENER) TRPTYPE (TCP) CONTROL (QMGR) PORT ($hubPort)" | ./runmqsc $hubQmgr
	if [ $? -ne 0 ]; then ListenerCreateError; fi
	echo "START LISTENER(HUBLISTENER)" | ./runmqsc $hubQmgr
	if [ $? -ne 0 ]; then ListenerCreateError; fi

# -------------------------------------------------------------------------------------------------------
#
# We now set the basic object access to enable file transfer. This step relies on the earlier manual
# creation of the FTUSERS and FTAGENTS groups. You may wish to implement your own principal or group
# based access model.
#
# -------------------------------------------------------------------------------------------------------

	echo ""
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo "+"
	echo "+ Creating basic access control for topology-wide file transfer"
	echo "+"
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo ""


	./setmqaut -m $hubQmgr -t qmgr -g FTAGENTS +connect +inq +setid
	if [ $? -ne 0 ]; then PossibleFTAGENTSError; fi
	./setmqaut -m $hubQmgr -t qmgr -g FTUSERS +connect + inq
	if [ $? -ne 0 ]; then PossibleFTUSERSError; fi
	./setmqaut -m $hubQmgr -n "SYSTEM.FTE" -t q -g FTAGENTS +get +put
	if [ $? -ne 0 ]; then PossibleFTAGENTSError; fi
	./setmqaut -m $hubQmgr -n "SYSTEM.FTE" -t topic -g FTUSERS +sub
	if [ $? -ne 0 ]; then PossibleFTUSERSError; fi
	./setmqaut -m $hubQmgr -n "SYSTEM.FTE" -t topic -g FTAGENTS +pub +sub
	if [ $? -ne 0 ]; then PossibleFTAGENTSError; fi
	./setmqaut -m $hubQmgr -n "SYSTEM.DEFAULT.MODEL.QUEUE" -t q -g FTUSERS +dsp +browse +get +put
	if [ $? -ne 0 ]; then PossibleFTUSERSError; fi
	./setmqaut -m $hubQmgr -n "SYSTEM.DEFAULT.MODEL.QUEUE" -t q -g FTAGENTS +dsp +browse +get +put
	if [ $? -ne 0 ]; then PossibleFTAGENTSError; fi


# -------------------------------------------------------------------------------------------------------
#
# We now set up the file transfer resources. In this example, we use the hub queue manager to act as the
# co-ordination, command and agent queue managers. Should you wish to split these roles across different
# queue managers, you will need to understand the impact on where file transfer resources will reside, and
# hence make appropriate changes to channels and the object access model.
#
# -------------------------------------------------------------------------------------------------------

	echo ""
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo "+"
	echo "+ Creating coordination queue manager at $hubQmgr..."
	echo "+"
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo ""

	./fteSetupCoordination -coordinationQMgr $hubQmgr -f
	if [ $? -ne 0 ]; then coordinationError; fi


# ---------------------------------------------------------------------------------------------------
#
# We now need to run the created MQSC commands against the queue manager. We can programmatically
# determine where these are under the MQ data path.
#
# ---------------------------------------------------------------------------------------------------


    MQ_DATA_PATH=/var/mqm
    export fileLocation="$MQ_DATA_PATH/mqft/config/$hubQmgr/$hubQmgr.mqsc"

# Now check it exists...

	if [ ! -f $fileLocation ];
	then
		    echo "+ Cannot find MQSC file in expected location $fileLocation. Edit the script to match your own environment."
	    	coordinationError
	fi

# Run the script against the queue manager

    ./runmqsc $hubQmgr < $fileLocation
    if [ $? -ne 0 ]; then coordinationError; fi

# ---------------------------------------------------------------------------------------------------
#
# We now set the nominated queue manager as the command queue manager. Because it is local, we do not
# need to provide connection details.
#
# ---------------------------------------------------------------------------------------------------

    ./fteSetupCommands -p $hubQmgr -connectionQMgr $hubQmgr -f
    if [ $? -ne 0 ]; then commandError; fi


success
