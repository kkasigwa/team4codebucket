#!/bin/sh

# -------------------------------------------------------------------------------------------------------
#
# @start_non_restricted_prolog@
# Version: @(#) MQMBID sn=p940-L240606.DE su=_dsdH3iPhEe-M5d-9sa1WMw pn=com.ibm.wmqfte.common/samples/scripts/unix/addSpoke.sh
# ============================================================================
# <copyright
# notice="lm-source-program"
# pids="5724-H72"
# years="2015,2016"
# crc="3374478728" >
# Licensed Materials - Property of IBM  
#
# 5724-H72 
# 
# (C) Copyright IBM Corp. 2015, 2016  All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with    
# IBM Corp. 
# </copyright>
# ============================================================================
# @end_non_restricted_prolog@
#
#
#
# Sample script to add a file transfer agent 'spoke' to a simple hub-based file transfer topology. This script also includes
# basic security: spokes are authenticated based on IP addresses and access
# control is restricted to a common user across all spokes. Should you have differing
# security requirements, you can edit this script to add the features you need.
#
# Example: addSpoke.sh agentName=AGENT1 hubQmgr=hubQM connectionMode=BINDINGS
# Example: addSpoke.sh agentName=AGENT1 hubQmgr=hubQM connectionMode=CLIENT agentIPAddress=9.20.134.93  hubIPAddress=9.20.134.93 hubPort=1414
#
# -------------------------------------------------------------------------------------------------------

fail() {
end
}

end() {
	exit 0
}

success() {
	if [ "$connectionMode" == "CLIENT" ]; then
		echo ""
		echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
		echo "+"
		echo "+ SUCCESS: HUB-SIDE AGENT RESOURCE CREATION COMPLETE FOR $agentName"
		echo "+"
		echo "+ You must now run the following commands on the target agent machine:"
		echo "+"
		echo "+ * As an MQ Administrator: "
		echo "+       fteSetupCoordination -coordinationQMgr $hubQmgr -coordinationQMgrHost $hubIPAddress "
		echo "+       -coordinationQMgrPort $hubPort -coordinationQMgrChannel FTE.USER.SVRCONN -f"
		echo "+"
		echo "+          # Note: you will not need to run the MQSC scripts that are generated"
		echo "+"
		echo "+       fteSetupCommands -p $hubQmgr -connectionQMgr $hubQmgr -connectionQMgrHost $hubIPAddress "
		echo "+       -connectionQMgrPort $hubPort -connectionQMgrChannel FTE.USER.SVRCONN -f"
		echo "+"
		echo "+       fteCreateAgent -p $hubQmgr -agentName $agentName -agentQMgr $hubQmgr  -agentQMgrHost $hubIPAddress "
		echo "+       -agentQMgrPort $hubPort -agentQMgrChannel FTE.AGENT.SVRCONN -f"
		echo "+"
		echo "+          # Note: you will not need to run the MQSC scripts that are generated"
		echo "+"
		echo "+ * As the agent user \"ftagent\":"
		echo "+       fteStartAgent -p $hubQmgr $agentName "
		echo "+"
		echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
		echo ""
	else
		echo ""
		echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
		echo "+"
		echo "+ SUCCESS: AGENT CREATION COMPLETE FOR $agentName"
		echo "+ "
		echo "+ You must now run the following command:"
		echo "+"
		echo "+ * As the agent user \"ftagent\":"
		echo "+       fteStartAgent -p $hubQmgr $agentName "
		echo "+"
		echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
		end
	fi
}

CHLAUTHError() {
	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ Error creating channel authentication records for queue manager $hubQmgr. Check"
	  echo "+ previous error messages and resolve the issue. "
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
fail
}

PossibleFTAGENTSError() {
	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ There appears to be a problem with the group \"FTAGENTS\". "
	  echo "+ Check previous error messages and resolve the issue."
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
fail
}

PossibleFTUSERSError() {
	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ There appears to be a problem with the group \"FTUSERS\". "
	  echo "+ Check previous error messages and resolve the issue."
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
fail
}

agentError() {
	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ Unable to configure agent resources. Check previous error messages"
	  echo "+ Check previous error messages and resolve the issue."
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
fail
}

createAgentError() {

	  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+"
	  echo "+ Unable to create agent $agentName in $connectionMode mode. Check previous "
	  echo "+ Check previous error messages and resolve the issue."
	  echo "+"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo.
fail
}

incorrectUsage() {

  echo ""
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo "+ Usage: addSpoke agentName=<agent name> hubQmgr=<queue manager name> connectionMode=<CLIENT|BINDINGS> "
	  echo "+ [agentIPAddress=<nnn.nnn.nnn.nnn>] [hubIPAddress=<nnn.nnn.nnn.nnn>] [hubPort=<port number>]"
	  echo "+"
	  echo "+ agentName=<agent name>"
	  echo "+    Required. Administrative name for the agent"
	  echo "+ hubQmgr=<queue manager name>"
	  echo "+    Required. Name of the hub queue manager [see createHub command]. "
	  echo "+ connectionMode=<CLIENT|BINDINGS>"
	  echo "+    Required. Allowed values are CLIENT and BINDINGS."
	  echo "+ agentIPAddress=<nnn.nnn.nnn.nnn>"
	  echo "+    Required if connectionMode=CLIENT. IP address of the agent "
	  echo "+    machine in nnn.nnn.nnn.nnn format."
	  echo "+ hubIPAddress=<nnn.nnn.nnn.nnn>"
	  echo "+    Required if connectionMode=CLIENT. IP address of the hub machine "
	  echo "+    in nnn.nnn.nnn.nnn format."
	  echo "+ hubPort=<port number>"
	  echo "+    Required if connectionMode=CLIENT. Listener port on the hub machine."
	  echo "+"
	  echo "+ Pre-requisites: "
	  echo "+ "
	  echo "+ * On the hub machine:"
	  echo "+   * Create a working file transfer hub [see createHub script]"
	  echo "+ * On the agent host:"
	  echo "+   * Install of IBM MQ including Managed File Transfer Agent component"
	  echo "+   * Create the user \"ftagent\""
	  echo "+"
	  echo "+ This command must be run from an MQ administrator account from the bin directory"
	  echo "+ of the MQ installation."
	  echo "+"
	  echo "+ Example: addSpoke.sh agentName=AGENT1 hubQmgr=hubQM connectionMode=BINDINGS"
	  echo "+ Example: addSpoke.sh agentName=AGENT1 hubQmgr=hubQM connectionMode=CLIENT"
	  echo "+          agentIPAddress=9.180.167.219  hubIPAddress=9.20.134.93 hubPort=1414"
	  echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	  echo ""
	  end
}

# -------------------------------------------------------------------------------------------------------
#
# First, process command line arguments to extract variables. If we are missing any that are required, print
# the usage instructions.
#
# -------------------------------------------------------------------------------------------------------

	while [ $# -gt 0 ]
	do
	    echo "Setting $1"
	    export $1
	    shift
	done

	[ -z "${agentName}" ] && incorrectUsage
	[ -z "${connectionMode}" ] && incorrectUsage
	[ -z "${hubQmgr}" ] && incorrectUsage


	if [ "$connectionMode" == "CLIENT" ]; then
	   		# We also need an agent host, hub host, and port
			[ -z "${agentIPAddress}" ] && incorrectUsage
			[ -z "${hubPort}" ] && incorrectUsage
			[ -z "${hubIPAddress}" ] && incorrectUsage
	fi

# -------------------------------------------------------------------------------------------------------
#
# If in CLIENT mode we create a channel authentication record to allow the agent to connect to the hub
# queue manager. We shall use weak authentication based on IP address. You may wish to consider stronger
# authentication should you have concerns about IP address based authentication. For more information,
# refer to the MQ documentation.
#
# -------------------------------------------------------------------------------------------------------

	if [ "$connectionMode" == "CLIENT" ]; then

		echo ""
		echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
		echo "+"
		echo "+ Creating CHLAUTH records for host $agentIPAddress..."
		echo "+"
		echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
		echo ""
		echo "SET CHLAUTH('FTE.USER.SVRCONN') TYPE(ADDRESSMAP) ADDRESS('$agentIPAddress') USERSRC(MAP) MCAUSER('ftuser') DESCR('File transfer user rule at $agentName') ACTION(REPLACE)" | ./runmqsc $hubQmgr
		if [ $? -ne 0 ]; then CHLAUTHError; fi
		echo "SET CHLAUTH('FTE.AGENT.SVRCONN') TYPE(ADDRESSMAP) ADDRESS('$agentIPAddress') USERSRC(MAP) MCAUSER('ftagent') DESCR('File transfer agent rule at $agentName') ACTION(REPLACE)" | ./runmqsc $hubQmgr
		if [ $? -ne 0 ]; then CHLAUTHError; fi
	fi


# -------------------------------------------------------------------------------------------------------
#
# We now set the basic object access to enable file transfer. This step relies on the earlier manual
# creation of the FTUSERS and FTAGENTS groups. You may wish to implement your own principal or group
# based access model - for example, if you wish to use a different user per agent.
#
# -------------------------------------------------------------------------------------------------------

	echo ""
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo "+"
	echo "+ Creating basic access control for the agent"
	echo "+"
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo ""


	./setmqaut -m $hubQmgr -n "SYSTEM.FTE.COMMAND.$agentName" -t q -g FTUSERS +put
	if [ $? -ne 0 ]; then PossibleFTUSERSError; fi
	./setmqaut -m $hubQmgr -n "SYSTEM.FTE.COMMAND.$agentName" -t q -g FTAGENTS +setid +get +put
	if [ $? -ne 0 ]; then PossibleFTAGENTSError; fi
	./setmqaut -m $hubQmgr -n "SYSTEM.FTE.DATA.$agentName" -t q -g FTAGENTS +get +put
	if [ $? -ne 0 ]; then PossibleFTAGENTSError; fi
	./setmqaut -m $hubQmgr -n "SYSTEM.FTE.EVENT.$agentName" -t q -g FTAGENTS +get +put
	if [ $? -ne 0 ]; then PossibleFTAGENTSError; fi
	./setmqaut -m $hubQmgr -n "SYSTEM.FTE.REPLY.$agentName" -t q -g FTAGENTS +get +put
	if [ $? -ne 0 ]; then PossibleFTAGENTSError; fi
	./setmqaut -m $hubQmgr -n "SYSTEM.FTE.STATE.$agentName" -t q -g FTAGENTS +get +put +inq
	if [ $? -ne 0 ]; then PossibleFTAGENTSError; fi

# ---------------------------------------------------------------------------------------------------
#
# We now create the agent resources. A script will be generated when we run the fteCreateAgent command
# later against the agent installation, but for convenience we shall create the resources in advance.
#
# ---------------------------------------------------------------------------------------------------

    echo ""
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo "+"
	echo "+ Create the agent resources..."
	echo "+"
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo ""


    echo "DEFINE QLOCAL(SYSTEM.FTE.COMMAND.$agentName) DEFPRTY(0) DEFSOPT(SHARED) GET(ENABLED) MAXDEPTH(5000) MAXMSGL(4194304) MSGDLVSQ(PRIORITY) PUT(ENABLED) RETINTVL(999999999) SHARE NOTRIGGER USAGE(NORMAL) REPLACE" | ./runmqsc $hubQmgr
    if [ $? -ne 0 ]; then agentError; fi
    echo "DEFINE QLOCAL(SYSTEM.FTE.DATA.$agentName)    DEFPRTY(0) DEFSOPT(SHARED) GET(ENABLED) MAXDEPTH(5000) MAXMSGL(4194304) MSGDLVSQ(PRIORITY) PUT(ENABLED) RETINTVL(999999999) SHARE NOTRIGGER USAGE(NORMAL) REPLACE" | ./runmqsc $hubQmgr
    if [ $? -ne 0 ]; then agentError; fi
	echo "DEFINE QLOCAL(SYSTEM.FTE.REPLY.$agentName)   DEFPRTY(0) DEFSOPT(SHARED) GET(ENABLED) MAXDEPTH(5000) MAXMSGL(4194304) MSGDLVSQ(PRIORITY) PUT(ENABLED) RETINTVL(999999999) SHARE NOTRIGGER USAGE(NORMAL) REPLACE" | ./runmqsc $hubQmgr
	if [ $? -ne 0 ]; then agentError; fi
	echo "DEFINE QLOCAL(SYSTEM.FTE.STATE.$agentName)   DEFPRTY(0) DEFSOPT(SHARED) GET(ENABLED) MAXDEPTH(5000) MAXMSGL(4194304) MSGDLVSQ(PRIORITY) PUT(ENABLED) RETINTVL(999999999) SHARE NOTRIGGER USAGE(NORMAL) REPLACE" | ./runmqsc $hubQmgr
	if [ $? -ne 0 ]; then agentError; fi
	echo "DEFINE QLOCAL(SYSTEM.FTE.EVENT.$agentName)   DEFPRTY(0) DEFSOPT(SHARED) GET(ENABLED) MAXDEPTH(5000) MAXMSGL(4194304) MSGDLVSQ(PRIORITY) PUT(ENABLED) RETINTVL(999999999) SHARE NOTRIGGER USAGE(NORMAL) REPLACE" | ./runmqsc $hubQmgr
	if [ $? -ne 0 ]; then agentError; fi
	echo "DEFINE QLOCAL(SYSTEM.FTE.AUTHAGT1.$agentName) DEFPRTY(0) DEFSOPT(SHARED) GET(ENABLED) MAXDEPTH(0) MAXMSGL(0) MSGDLVSQ(PRIORITY) PUT(ENABLED) RETINTVL(999999999) SHARE NOTRIGGER USAGE(NORMAL) REPLACE" | ./runmqsc $hubQmgr
	if [ $? -ne 0 ]; then agentError; fi
	echo "DEFINE QLOCAL(SYSTEM.FTE.AUTHTRN1.$agentName) DEFPRTY(0) DEFSOPT(SHARED) GET(ENABLED) MAXDEPTH(0) MAXMSGL(0) MSGDLVSQ(PRIORITY) PUT(ENABLED) RETINTVL(999999999) SHARE NOTRIGGER USAGE(NORMAL) REPLACE" | ./runmqsc $hubQmgr
	if [ $? -ne 0 ]; then agentError; fi
	echo "DEFINE QLOCAL(SYSTEM.FTE.AUTHOPS1.$agentName) DEFPRTY(0) DEFSOPT(SHARED) GET(ENABLED) MAXDEPTH(0) MAXMSGL(0) MSGDLVSQ(PRIORITY) PUT(ENABLED) RETINTVL(999999999) SHARE NOTRIGGER USAGE(NORMAL) REPLACE" | ./runmqsc $hubQmgr
	if [ $? -ne 0 ]; then agentError; fi
	echo "DEFINE QLOCAL(SYSTEM.FTE.AUTHSCH1.$agentName) DEFPRTY(0) DEFSOPT(SHARED) GET(ENABLED) MAXDEPTH(0) MAXMSGL(0) MSGDLVSQ(PRIORITY) PUT(ENABLED) RETINTVL(999999999) SHARE NOTRIGGER USAGE(NORMAL) REPLACE" | ./runmqsc $hubQmgr
	if [ $? -ne 0 ]; then agentError; fi
	echo "DEFINE QLOCAL(SYSTEM.FTE.AUTHMON1.$agentName) DEFPRTY(0) DEFSOPT(SHARED) GET(ENABLED) MAXDEPTH(0) MAXMSGL(0) MSGDLVSQ(PRIORITY) PUT(ENABLED) RETINTVL(999999999) SHARE NOTRIGGER USAGE(NORMAL) REPLACE" | ./runmqsc $hubQmgr
	if [ $? -ne 0 ]; then agentError; fi
	echo "DEFINE QLOCAL(SYSTEM.FTE.AUTHADM1.$agentName) DEFPRTY(0) DEFSOPT(SHARED) GET(ENABLED) MAXDEPTH(0) MAXMSGL(0) MSGDLVSQ(PRIORITY) PUT(ENABLED) RETINTVL(999999999) SHARE NOTRIGGER USAGE(NORMAL) REPLACE" | ./runmqsc $hubQmgr
	if [ $? -ne 0 ]; then agentError; fi


# ---------------------------------------------------------------------------------------------------
#
# If we are in bindings mode, we can go ahead and create the agent immediately, as we're on the correct
# machine.
#
# ---------------------------------------------------------------------------------------------------

	if [ "$connectionMode" == "BINDINGS" ]; then

	    echo ""
		echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
		echo "+"
		echo "+ Creating agent $agentName"
		echo "+"
		echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
		echo ""

		./fteCreateAgent -p $hubQmgr -agentName $agentName -agentQMgr $hubQmgr -f
		if [ $? -ne 0 ]; then createAgentError; fi
	fi

	success

